#!/bin/sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}")" && pwd)"
export LD_LIBRARY_PATH="/usr/local/ssl/lib"
$DIR/acestreamengine --lib-path "$DIR" "$@"
