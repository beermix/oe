#!/bin/bash

#
# lsPatches.sh - generate list of patches for subsequent download.
#
# See notes in getPatches.sh for more details information on
# file formats and usage.
#
# Exit Codes:
#   0 - Success
#   1 - Success, but no changes since last run
#   2 - Error
#
BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

_lock_build_repo

MYPATCHES=${BUILD_RESOURCES}/patches
GITHUBAPI="https://api.github.com/repos"

PY_BASE='
import sys, json
data=[]
for line in sys.stdin: data.append(line)
jdata = json.loads("".join(data))
obj = jdata["parent"] if "parent" in jdata else jdata
print("%s:%s" % (obj["name"], obj["default_branch"]))
'

PY_COMMITS='
import sys, json, re, codecs

def get_perma_link(batch, alt_last=""):
  perma_link = batch.get("permalink_url", "")

  if perma_link != "":
    # Expand sha refs on permalink
    perma_firstsha = batch["base_commit"]["sha"]
    perma_lastsha = batch["commits"][-1]["sha"] if len(batch["commits"]) != 0 else perma_firstsha
    perma_link = perma_link.replace(perma_firstsha[0:7], "@@firstsha@@", 1)
    perma_link = perma_link.replace(perma_lastsha[0:7], "@@lastsha@@", 1)
    if alt_last != "":
      perma_lastsha = alt_last
    perma_link = perma_link.replace("@@firstsha@@", perma_firstsha)
    perma_link = perma_link.replace("@@lastsha@@", perma_lastsha)

  return perma_link

# Return number of commits in comparison, and url of "next batch"
def analyse_batch(batch):
  ahead_by = batch.get("ahead_by", 0)
  api_url = batch.get("url", "")

  if len(batch.get("commits", [])) > 0:
    perma_link = get_perma_link(batch, batch["commits"][0]["sha"])
  else:
    perma_link = get_perma_link(batch)

  # Use expanded branch:sha refs from permalink_url, but with api_url, as "next url"
  api_rpos = api_url.rfind("/")
  perma_rpos = perma_link.rfind("/")
  if api_rpos != -1 and perma_rpos != -1:
    next_url = perma_link.replace(perma_link[:perma_rpos], api_url[:api_rpos])
  else:
    next_url = perma_link

  sys.stdout.write("%d %s\n" % (ahead_by, next_url))

def get_merge_list(alldata):
  mergelist = []
  shalist = {}

  for batch in alldata:
    # Create simple list of merge items
    # Create hashed list of each commit, linking to its parent, and flag if its a merge commit or not
    for item in batch.get("commits", batch):
      if "commit" not in item: continue
      if len(item["parents"]) > 1:
        mergelist.append(item)
        shalist[item["sha"]] = {"ismerge": True, "mparent": None, "parent": item["parents"][0]["sha"]}
      else:
        shalist[item["sha"]] =  {"ismerge": False, "mparent": None, "parent": item["parents"][0]["sha"]}

  # For each merge item, determine members of each merge
  # Update hashed list with sha of each merge item as the mparent entry
  for merge in mergelist:
    mergeitems = []
    mergesha = merge["sha"]
    firstsha = merge["parents"][0]["sha"]
    lastsha = merge["parents"][1]["sha"]
    while lastsha is not None and lastsha != firstsha:
      shaitem = shalist.get(lastsha, None)
      if shaitem is None: break
      if shaitem["ismerge"]: break
      mergeitems.append(lastsha)
      lastsha = shaitem["parent"]
    for mergeitem in mergeitems:
      shaitem = shalist.get(mergeitem, None)
      shaitem["mparent"] = mergesha

  return shalist

def process_commits(alldata):
  cdate = ""
  lines = []
  sha_history = {}
  perma_link = ""

  if "message" in alldata[0]:
    raise Exception('nodata')

  merge_list = get_merge_list(alldata)

  for batch in alldata:
    perma_link = get_perma_link(batch)

    for item in batch.get("commits", batch):
      if "commit" not in item: continue

      sha = item["sha"]
      # Eliminate duplicates, usually at batch boundaries
      if sha in sha_history: continue
      sha_history[sha] = True

      commit = item["commit"]
      cdate = commit["committer"]["date"]
      msg = commit["message"].split("\n")[0]

      line = "%s/%s  %s" % (root, sha, msg)
      if package: line = "!%s %s" % (package, line)

      merge_item = merge_list.get(sha, None)

      if merge_item is None:
        lines.append("%s" % line)
      elif merge_item["ismerge"]:
        if merge_code == "N":
          lines.append("#%s" % line)
        else:
          lines.append("%s" % line)
      elif merge_item["mparent"] is None or merge_code != "M":
        lines.append("%s" % line)

  if lines:
    if perma_link != "":
      sys.stdout.write("#permalink: %s\n" % perma_link)
    sys.stdout.write("%s\n" % "\n".join(lines))
    sys.stdout.write("#Last commit date: %s\n" % cdate)

if sys.version_info >= (3, 1):
  sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
  sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
else:
  sys.stdout = codecs.getwriter("utf-8")(sys.stdout)
  sys.stderr = codecs.getwriter("utf-8")(sys.stderr)

root = sys.argv[1:][0]
package = sys.argv[1:][1]
input_filename = sys.argv[1:][2]
merge_code = sys.argv[1:][3] #Y,N,M (M: output only merge commits, and commits that are not part of a merge item)
runmode = sys.argv[1:][4] # output all commits, or analyse a single batch

infile = open(input_filename, "rb")
data = infile.read()
infile.close()

alldata = json.loads(data)
try:
  # Analyse a single batch, extracing commit count and first sha
  # in case we need to request an earlier batch
  if runmode == "analyse":
    analyse_batch(alldata)
  elif runmode == "commits":
    process_commits(alldata)
except:
  sys.stderr.write("%s: Not a valid owner/repository/branch, branch deleted or invalid comparison\n" % root[:-7])
'

rewrite_url4api()
{
  local url="${1}" newurl="${1}"
  local fields=(${url//\// })

  if [ "${fields[1]}" == "github.com" ]; then
    fields[1]="api.github.com"
    [ "${fields[4]}" == "pull" ] && fields[4]="pulls"
    [ "${fields[4]}" == "commit" ] && fields[4]="commits"
    newurl="${fields[0]}//${fields[1]}/repos/${fields[2]}/${fields[3]}/${fields[4]}/${fields[5]%\.patch}"
  elif [ "${fields[1]}" == "patch-diff.githubusercontent.com" ]; then
    fields[1]="api.github.com"
    [ "${fields[5]}" == "pull" ] && fields[5]="pulls"
    [ "${fields[5]}" == "commit" ] && fields[5]="commits"
    newurl="${fields[0]}//${fields[1]}/repos/${fields[3]}/${fields[4]}/${fields[5]}/${fields[6]%\.patch}"
  fi

  echo "${newurl}"
}
webrequest()
{
  local url="${1}" header="${2}"
  local result=0
  local mycurl mycurl_redacted

  mycurl="curl -sfL --connect-timeout 30 --retry 6"

  [ -n "${header}" ] && mycurl+=" -H \"${header}\""

  [ -n "${CURL_INSECURE}" ] && mycurl+=" --insecure"

  mycurl_redacted="${mycurl}"

  if [[ ${url} =~ https://api.github.com/.* ]]; then
    mycurl_redacted+=" ${AUTHENTICATION_REDACTED}"
    mycurl+=" ${AUTHENTICATION}"
  fi

  mycurl_redacted+=" --url \"${url}\""
  mycurl+=" --url \"${url}\""

  [ ${VERBOSE} == Y ] && echo "DEBUG: ${mycurl_redacted}" >&2

  eval "${mycurl}" || result=1

  [ ${VERBOSE} == Y ] && echo "DEBUG: status is $?, result is ${result}" >&2
  return ${result}
}

getkernelsha()
{
  local owner="${1}" repo="${2}" branch="${3}" url

  url="${GITHUBAPI}/${owner}/${repo}/commits?sha=${branch}&path=Makefile"

  PY_LINUX='
import sys, json
data=[]
for line in sys.stdin: data.append(line)
jdata = json.loads("".join(data))
if "message" not in jdata:
  for item in jdata:
    sha = item["sha"]
    msg = item["commit"]["message"].split("\n")[0]
    if msg[:6] == "Linux ":
      print("%s/%s" % (sha, msg))
      break
'  
  webrequest "${url}" | python -c "${PY_LINUX}"
}

# Github limits comparisons to a maximum of 250 commits, so repeatedly query
# github.com in order to obtain all commits in the comparison
getallcommits()
{
  local url="${1}"
  local tmpfile=$(gettmpdirp)/responsedata
  local analyse=()

  rm -f ${tmpfile}.all

  while [ : ]; do
    rm -f ${tmpfile}.batch
    webrequest "${url}" > ${tmpfile}.batch
    if [ ! -f "${tmpfile}.batch" -o ! -s "${tmpfile}.batch" ] ; then
      echoerr "No response from github.com"
      return 1
    fi

    analyse=($(python -c "${PY_COMMITS}" "${OWNER}/${REPO}/commit" "${PACKAGE}" ${tmpfile}.batch ${INCLUDE_MERGES} analyse))
    [ ${VERBOSE} == Y ] && echo "DEBUG: Analysis (commits, next_url): ${analyse[@]}" >&2

    if [ -f ${tmpfile}.all ]; then
      echo "$(cat ${tmpfile}.batch)," > ${tmpfile}.tmp
      cat ${tmpfile}.all >> ${tmpfile}.tmp
      mv ${tmpfile}.tmp ${tmpfile}.all
    else
      mv ${tmpfile}.batch ${tmpfile}.all
    fi
    [ ${analyse[0]} -gt 250 ] && url="${analyse[1]}~1" || break
  done
  echo "["
  cat ${tmpfile}.all
  echo "]"

  rm -f ${tmpfile}.*

  return 0
}

iffwdprmerged()
{
  local line="$1"
  local fields pkg sha usha lsha url tokens token
  
  [ -z "${line}" ] && return 1
  [[ ${line} =~ ^# ]] && return 1

  fields=(${line})
  if [ "${fields[0]:0:1}" == "!" ]; then
    pkg="${fields[0]:1}"
    sha="${fields[1]}"
  else
    sha="${fields[0]}"
  fi

  #Always include urls prefixed with + (yes, this is a hack).
  #Normally we will automatically ignore merged pull requests for repositories
  #we mkpkg, however if there's a need to include an extra pull request then
  #prefix the url with + (eg. +https//github.com/blah)
  [ "${sha:0:1}" == "+" ] && return 1

  #Always include reverted pull requests
  [ "${sha:0:1}" == "-" ] && return 1

  tokens="${sha%\!*}"
  sha="${sha#*\!}"
  [ "${tokens}" == "${sha}" ] && tokens=

  # always apply patch regardless of upstream merge state
  for token in ${tokens//,/ }; do
    [ "${token}" == "ignoremergestatus" ] && return 1
  done

  usha="${sha^^}"
  lsha="${sha,,}"

  if [[ "${usha}" =~ ^PR[0-9]*$ ]]; then
    url="https://github.com/xbmc/xbmc/pull/${sha:2}"
  elif [[ "${usha}" =~ ^OEPR[0-9]*$ ]]; then
    url="${BUILD_REPO_GITHUB}/pull/${sha:4}"
  elif [[ "${lsha}" =~ ^.*/pull/[0-9]*$ ]]; then
    [[ "${sha}" =~ ^http ]] && url="${sha}" || url="https://github.com/${sha}"
  fi

  [ -z "${url}" ] && return 1

  if [ -z "${pkg}" ]; then
    fields=(${url//\// })
    pkg="${fields[3]}"
  fi

  [ "${pkg}" == "xbmc" ] && pkg="${OE_KODI_VER}"
  [ "${pkg}" == "service.libreelec.settings" ] && pkg="LibreELEC-settings"
  [ "${pkg}" == "librtmp" ] && pkg="rtmpdump"

  # If we are packaging the latest version of this repository then we don't want merged pull requests!
#  if findindelimitedlist_key2 "${pkg}" "=" "${BUILD_ENV_REPOS} ${BUILD_ENV_ADDON_REPOS}" && \
#     ! findindelimitedlist_key2 "${pkg}" "=" "${BUILD_ENV_STOCK_REPOS}"; then
  if [ "$(get_branch_for_package "${pkg}" "${BUILD_ENV_REPOS} ${BUILD_ENV_ADDON_REPOS}" "${BUILD_ENV_BRANCHES} ${BUILD_ENV_ADDON_BRANCHES}")" == "${BUILD_DEF_BRANCH}" ]; then
    if ! findindelimitedlist_key2 "${pkg}" "=" "${BUILD_ENV_STOCK_REPOS}"; then
      # If the pull request is merged return fail as we don't want it
      if webrequest "$(rewrite_url4api "${url}")/merge" "Accept: application/vnd.github.v3.patch" >/dev/null; then
        echo "IGNORING MERGED PULL REQUEST: \"${line}\"" >&2
        return 0
      fi
    fi
  fi

  return 1
}

echoerr()
{
  progress
  echo "$@" >&2
}

progress()
{
  return 0 # Do nothing, for now
  [ -n "${PROGRESSLAST}" ] && echo -en "$(echo "${PROGRESSLAST}" | sed 's/./ /g')\r" >&2
  [ -n "${1}" ] && echo -en "${1}\r" >&2
  export PROGRESSLAST="${1}"
  sync
}

SPINNERCOUNT=0
SPINNER='|/-\|/-\'
spinner()
{
  SPINNERCOUNT=$((SPINNERCOUNT+1))
  local spinchar=${SPINNER:SPINNERCOUNT%${#SPINNER}:1}
  spinchar="${spinchar}"
  progress "Processing: ${spinchar//\\/\\\\}"
}

usage()
{
  cat <<EOF
Usage: $(basename $0) [-g path] [-o owner] [-r repo] [-b branch] [-c base_branch] [-p package]
                    [-I filename] [-O filename] [-C|-A patchcode] [-i] [-m | -M] [-t] [-u] [-K] [-q|-v]

$(basename $0) options:
   -b   Local/remote repo branch (default is master)
   -c   Revision (branch, tag, sha etc.) against which to compare local/remote repo when selecting commits
   -g   Path to local git repository
   -i   Read details from template file (otherwise process repo based on command line args)
   -m   Include merges (default: no)
   -M   Include only merges and commits not part of a merge
   -o   Remote repo owner
   -p   Name of package to which commits should be applied (default: same as repository name, -r/-g)
   -r   Remote repo name (default is: xbmc)
   -t   Include tracked files when processing a local git repo
   -u   Include untracked files when processing a local git repo
   -K   Ignore kernel mismatch with package version
   -I   Name of input template filename (default is ipatches.dat)
   -O   Name of output patches filename (default is patches.dat)
   -C   Patchcode(s) when filtering commits/imports
   -A   Additional patchcode(s) to be used when filtering commits/imports
   -q   Quiet, less output
   -v   Debug output
   -h   This message
EOF
}

OWNER=
REPO=
BRANCH=master
BASE_BRANCH=
AUTHOR=
MINSHA=
MAXSHA=
COMP=Y
IPATCHES=N
DISPLAY=N
QUIET=N
PACKAGE=
INCLUDE_MERGES=N
GIT=
UNTRACKED=N
TRACKED=N
INFILE=${BUILD_PKG_CONTROL}
OUTFILE=
PATCHCODE=
PADDCODE=
GOT_BRANCH=N
VERBOSE=N
IGNOREKERNVER=N

while getopts ":hiqvutmMKa:s:f:g:o:r:b:c:p:C:A:I:O:" opt; do
  case ${opt} in
    m) INCLUDE_MERGES=Y;;
    M) INCLUDE_MERGES=M;;
    a) AUTHOR=${OPTARG};;
    g) GIT=${OPTARG};;
    u) UNTRACKED=Y;;
    t) TRACKED=Y;;
    o) OWNER=${OPTARG};;
    r) REPO=${OPTARG};;
    b) GOT_BRANCH=Y; BRANCH=${OPTARG};;
    c) BASE_BRANCH=${OPTARG};;
    s) COMP=N; MAXSHA=${OPTARG};;
    f) COMP=N; MINSHA=${OPTARG};;
    p) PACKAGE=${OPTARG};;
    i) IPATCHES=Y;;
    K) IGNOREKERNVER=Y;;
    I) INFILE=$(readlink -f ${OPTARG});;
    O) OUTFILE=$(readlink -f ${OPTARG});;
    C) PATCHCODE="${PATCHCODE}${OPTARG} ";;
    A) PADDCODE="${PADDCODE}${OPTARG} ";;
    q) QUIET=Y;;
    v) VERBOSE=Y;;
    h)  usage && exit 0;;
    \?) usage && die 2 "ERROR: Unknown argument [-${OPTARG}]";;
  esac
done

[ -f "${INFILE}" ]    || die 2 "ERROR: Control file [${INFILE}] not found"

[ -n "${GIT}" -a -z "${REPO}" ] && REPO="$(basename ${GIT%.git})"
[ -z "${GIT}" -a -z "${REPO}" ] && REPO="xbmc"

# Use default package if package not specified
[ -z "${PACKAGE}" ] && PACKAGE="${REPO}"

# Fix legacy xbmc -> kodi
[ "${PACKAGE}" == "xbmc" ] && PACKAGE="${OE_KODI_VER}"

# Use filter from profile if available
[ -z "${PATCHCODE}" ] && PATCHCODE="${BUILD_PKG_FILTERS}" || PATCHCODE="${PATCHCODE::-1}"
[ -n "${PADDCODE}" ] && PATCHCODE="${PATCHCODE} ${PADDCODE::-1}"

KERNELVER="$(getoepkgoption linux PKG_VERSION)"

# Generate patches.dat from an input template (eg. ipatches.dat)
if [ ${IPATCHES} == Y ]; then
  if [ -z "${OUTFILE}" ]; then
    [ -n "${PROFILE}" ] && OUT="$(gettmpdirp)/patches.dat" || OUT="${BUILD_PKG_PATCHES}"
  else
    OUT="${OUTFILE}"
  fi
  TMP=${OUT}.tmp
  WRK=${OUT}.wrk
  SED=${OUT}.sed
  SELF="$(readlink -f $0)"

  [ ${VERBOSE} == Y ] && otherargs+="-v "
  [ ${IGNOREKERNVER} == Y ] && otherargs+="-K "

  [ ! -f ${INFILE} ] && die 2 "ERROR: Unable to read patch template file \"${INFILE}\" - aborting"

  touch ${OUT}

  echo "Using patch template:  ${INFILE}"

  rm -fr ${TMP} ${WRK}

  # Patch codes can be specified with as "-C p1 -C p2" or "-C p1,p2" (or both).
  # Prefix code with + to append to default, eg. "-C +p1".
  # Codes with embedded plus signs (eg. "newclock4+art") are NOT supported.
  DEFPATCHCODE="$(awk -F= '/^DEFPATCHCODE/ {print $2}' ${INFILE})"
  [ -z "${PATCHCODE}" ] && PATCHCODE="${DEFPATCHCODE}"
  [ -n "${DEFPATCHCODE}" -a "${PATCHCODE//+/}" != "${PATCHCODE}" ] && PATCHCODE="${DEFPATCHCODE} ${PATCHCODE}"
  PATCHCODE="$(echo "${PATCHCODE}" | sed 's/ *$//g;s/^ *//g;s/\+//g')"
  PATCHCODES=(${PATCHCODE//,/ })
  PATCHCODE="${PATCHCODES[@]}"
  PATCHCODE="${PATCHCODE// /, }"
  echo "Selecting patches for: ${PATCHCODE:-(Not specified)}"

  rm -f ${SED}
  while read -r line; do
    if [ "${line:0:1}" == "=" ]; then
      pcode="$(echo "${line}" | awk '{ print $1 }')"
      if findinlist "${pcode:1}" "${PATCHCODES[@]}"; then
        line="$(echo "${line}" | sed "s/^${pcode}[ \t]*//")"
      else
        line="#${line}"
      fi
    fi
    echo "$line" >> ${SED}
  done <<< "$(cat ${INFILE})"
  sed -i "s/^DEFPATCHCODE *= *.*/#PATCHCODE=${PATCHCODE}/" ${SED}

  # Iterate over input and process imports
  NEEDBLANK=N
  while read -r line; do
    spinner

    TOKENS=(${line})

    #Remove any leading whitespace
    line="$(echo "${line}" | sed -e 's/^[ \t]*//')"

    line="$(echo "${line}" | sed "s/@@KERNELVER@@/${KERNELVER}/g")"

    # "import" anything beginning with a . or /
#    if [ "X${line:0:1}" == "X." -o "X${line:0:1}" == "X/" -o "X${line:0:7}" == "Ximport " ]; then
    if [ "X${line:0:7}" == "Ximport " ]; then
      # Separate repeating imports by a blank line (only for improved readability)
      [ ${NEEDBLANK} != NO ] && echo >> ${TMP}
      line="${line//import /${SELF} }"
      ${line%%#*} -q ${otherargs} > ${TMP}.0 || exit
      sed "s�^\(#Last commit date: .*\)$�\\1 [${line}]�" ${TMP}.0 >> ${TMP}
      rm -f ${TMP}.0
      OLDCOMMITDATE="$(${TGREP} -E "#Last commit date: .* \[${line}\]" ${OUT} | tail -1)"
      NEWCOMMITDATE="$(${TGREP} -E "#Last commit date: .* \[${line}\]" ${TMP} | tail -1)"
      [ "${OLDCOMMITDATE}" != "${NEWCOMMITDATE}" ] && echo "New commits: $(echo "${NEWCOMMITDATE}"|awk '{print $4}'), ${line}" >>${WRK}
      NEEDBLANK=YES
    else
      # Treat everything else as plain text
      [ ${NEEDBLANK} == YES -a -n "${line}" ] && echo >> ${TMP}
      iffwdprmerged "${line}" && line="#MERGED ${line}" #ignore merged pull requests
      echo "${line}" >> ${TMP}
      [ -n "${line}" ] && NEEDBLANK=IMPORTONLY || NEEDBLANK=NO
    fi
  done < ${SED}
  progress

  AWK_STRIP='BEGIN {ignore=0}; /^#permalink:/ {ignore=1}; !ignore {print $0}; /^#Last commit date:/ {ignore=0}'
  MD5_OLD="$(cat "${OUT}" | awk "${AWK_STRIP}" | ${TGREP} -vE "^#|^[ ]*$" | md5sum | awk '{print $1}')"
  MD5_NEW="$(cat "${TMP}" | awk "${AWK_STRIP}" | ${TGREP} -vE "^#|^[ ]*$" | md5sum | awk '{print $1}')"
  [ "${MD5_OLD}" != "${MD5_NEW}" ] && echo "New commits: New/changed patches or PRs" >> ${WRK}

  mv ${TMP} ${OUT}

  if [ ${QUIET} == N ]; then
    cat ${OUT}
    echo "------------------------------------------" >&2
  fi

  # Stash control files for this profile
  if [ -n "${PROFILE}" ]; then
    cp "${INFILE}" "$(gettmpdirp)/ipatches.dat"
    cp "${BUILD_PKG_BWLIST}" "$(gettmpdirp)/blacklist.dat"
  fi

  # Copy most recent patches.dat to BUILD_PKG_PATCHES if using a profile and specific output file not specified
  # This is purely for convenience
  if [ -z "${OUTFILE}" -a -n "${PROFILE}" ]; then
    cp "${OUT}" "${BUILD_PKG_PATCHES}"
  fi

  [ -s ${WRK} ] && CHANGED=Y || CHANGED=N
  [ "${CHANGED}" == Y ] && cat ${WRK} >&2 || echo "No new commits from imports, patches or PRs"

  rm -fr ${WRK} ${SED}

  [ "${CHANGED}" == Y ] && exit 0 || exit 1
fi

#If importing commits (diffs) from a local git repo
#then manufacture a temporary patch file based on the repo path
if [ -n "${GIT}" ]; then
  progress "Processing: Local repo ${GIT}...\n"

  TMPFILE=$(mktemp)
  trap "rm -f ${TMPFILE}" EXIT

  [ ! -d "${GIT}" ] && die 2 "ERROR: Cannot find specified git repository [${GIT}]"

  cd ${GIT}

  [ -z "${BASE_BRANCH}" ] && BASE_BRANCH=master
  [ ${GOT_BRANCH} == N ]  && BRANCH="$(git branch | ${TGREP} -E "^\*" | awk '{print $2}')"

  if [ "${BASE_BRANCH}" != "${BASE_BRANCH/@@KERNELSHA@@/}" ]; then
    KERNELDETS="$(git log --grep="^Linux [0-9]\..*" --pretty=oneline --no-color Makefile| head -1)"
    KERNELSHA="${KERNELDETS%% *}"
    KERNELMSG="${KERNELDETS#* }" && KERNELMSG="${KERNELMSG/v/}"
    PKG_VERSION="$(getoepkgoption linux PKG_VERSION)"
    if [ -n "${KERNELSHA}" ]; then
      BASE_BRANCH="${BASE_BRANCH/@@KERNELSHA@@/${KERNELSHA}}"
      echoerr "Pulling ${BRANCH} commits for ${KERNELMSG} (sha: ${KERNELSHA})"
      [ ${IGNOREKERNVER} == N -a "${PKG_VERSION}" != "${KERNELMSG#* }" ] && die 2 "ERROR: ${BRANCH} version mismatch: linux package version is ${PKG_VERSION}, remote branch is ${KERNELMSG#* }"
    else
      die 2 "ERROR: Unable to determine KERNELSHA sha!!"
    fi
  fi

  if [ "${BASE_BRANCH}" != "${BASE_BRANCH/.../}" ]; then
    #Committed changes based on full user supplied comparison
    git format-patch --stdout ${BASE_BRANCH} >> ${TMPFILE}
  else
    #Committed changes based on comparison between $BASE_BRANCH (-c) and $BRANCH (-b)
    git format-patch --stdout ${BASE_BRANCH}...${BRANCH} >> ${TMPFILE}
  fi

  [ -s ${TMPFILE} ] && echo "" >> ${TMPFILE}

  #Tracked files (-t)
  [ ${TRACKED} == Y ] && git diff >> ${TMPFILE}

  #Untracked files (-u)
  if [ ${UNTRACKED} == Y ]; then
    while read -r file; do
      [ -n "${file}" ] && git diff --no-index /dev/null "${file}" >> ${TMPFILE}
    done <<< "$(git status --short | ${TGREP} "^??" | cut -b4-)"
  fi

  cd - >/dev/null

  if [ -s ${TMPFILE} ]; then
    PNAME="localgit_$(echo "${GIT}" | sed "s|[^a-zA-Z0-9]|_|g").patch"
    mv ${TMPFILE} "${MYPATCHES}/${PNAME}"
    [ -z "${PACKAGE}" ] && echo "${PNAME}" || echo "!${PACKAGE} ${PNAME}"
  else
    rm -f ${TMPFILE}
  fi

  progress

  exit 0
fi

progress "Processing: Remote repo ${OWNER}/${REPO}/${BRANCH}...\n"

# Substitute sha for @@KERNELSHA@@ of last kernel commit bump
if [ "${BASE_BRANCH}" != "${BASE_BRANCH/@@KERNELSHA@@/}" ]; then
  KERNELDETS="$(getkernelsha "${OWNER}" "${REPO}" "${BRANCH}")"
  KERNELSHA="${KERNELDETS%%/*}"
  KERNELMSG="${KERNELDETS#*/}" && KERNELMSG="${KERNELMSG/v/}"
  PKG_VERSION="$(getoepkgoption linux PKG_VERSION)"
  if [ -n "${KERNELSHA}" ]; then
    BASE_BRANCH="${BASE_BRANCH/@@KERNELSHA@@/${KERNELSHA}}"
    echoerr "Pulling ${BRANCH} commits for ${KERNELMSG} (sha: ${KERNELSHA})"
    [  ${IGNOREKERNVER} == N -a "${PKG_VERSION}" != "${KERNELMSG#* }"  ] && die 2 "ERROR: ${BRANCH} version mismatch: linux package version is ${PKG_VERSION}, remote branch is ${KERNELMSG#* }"
  else
    die 2 "ERROR: Unable to determine KERNELSHA sha!!"
  fi
fi

# Substitute sha for @@PKG_VERSION@@ from associated package.mk
# eg. import -o juhovh -r shairplay -b master -c @@PKG_VERSION@@ -p libshairplay
if [ "${BASE_BRANCH}" != "${BASE_BRANCH/@@PKG_VERSION@@/}" -a -n "${PACKAGE}" ]; then
  PACKAGE_PATH="$(cd ${BUILD_REPO_PATH}/packages && find . -name ${PACKAGE} -type d | head -1)"
  [ -n "${PACKAGE_PATH}" ] && BASE_BRANCH="${BASE_BRANCH/@@PKG_VERSION@@/$(getoepkgoption ${PACKAGE_PATH:2} PKG_VERSION)}"
fi

#/repos/:owner/:repo
URL="${GITHUBAPI}/${OWNER}/${REPO}"
RESPONSE="$(webrequest "${URL}")"
if [ -z "${RESPONSE}" ] ; then
  echoerr "No response from github.com"
  exit
fi

DEF_BASE="$(echo "${RESPONSE}" | python -c "${PY_BASE}")"

if [ ${COMP} == N ]; then
  URL="${GITHUBAPI}/${OWNER}/${REPO}/commits?per_page=100&author=${AUTHOR}&sha=${BRANCH}"
else
  if [ -z "${BASE_BRANCH}" ]; then
    URL="${GITHUBAPI}/${OWNER}/${REPO}/compare/${REPO}:master...${OWNER}:${BRANCH}"
  elif [ "${BASE_BRANCH}" != "${BASE_BRANCH/.../}" ]; then
    URL="${GITHUBAPI}/${OWNER}/${REPO}/compare/${BASE_BRANCH}"
  else
    URL="${GITHUBAPI}/${OWNER}/${REPO}/compare/${BASE_BRANCH}...${OWNER}:${BRANCH}"
  fi
fi

TMPFILE=$(mktemp)
trap "rm -f ${TMPFILE}" EXIT

getallcommits "${URL}" > ${TMPFILE} || die 2 "ERROR while requesting commits from github.com"

# Use tac (reverse of cat) to reverse order of patches (first to last -> last to first)
if [ ${COMP} == N ]; then
  python -c "${PY_COMMITS}" "${OWNER}/${REPO}/commit" "${PACKAGE}" ${TMPFILE} ${INCLUDE_MERGES} commits | ${TGREP} -B9999 "${MAXSHA}" | ${TGREP} -A9999 "${MINSHA}" | tac
else
  python -c "${PY_COMMITS}" "${OWNER}/${REPO}/commit" "${PACKAGE}" ${TMPFILE} ${INCLUDE_MERGES} commits
fi

progress
