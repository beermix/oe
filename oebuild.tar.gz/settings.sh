BIN=$(readlink -f $(dirname $0))

TCPATH=${BIN}/texturecache.py
[ ! -f ${TCPATH} -o ! -x ${TCPATH} ] && TCPATH=${BIN}/texturecache.py/texturecache.py
[ ! -f ${TCPATH} -o ! -x ${TCPATH} ] && TCPATH=$(command -v texturecache.py)

TMPFILE1=$(mktemp)
TMPFILE2=$(mktemp)
trap "rm -f ${TMPFILE1} ${TMPFILE2}" EXIT

TCBIN="${TCPATH} @checkupdate=no @logfile="

PYTHON_VALUES='
import sys, json
id = sys.argv[1:][0]
data=[]
for line in sys.stdin: data.append(line)
jdata = json.loads("".join(data))
value=" "
for item in jdata:
  if item["id"] == id:
    if item["control"]["type"] == "spinner":
      items = []
      for opt in item.get("options", []):
        items.append("%s/%s" % (opt["value"], opt["label"]))
      value="\n".join(items)
    break
print(value)
'

PYTHON_PROPERTY='
import sys, json
id = sys.argv[1:][0]
property= sys.argv[1:][1]
data=[]
for line in sys.stdin: data.append(line)
jdata = json.loads("".join(data))
value=" "
for item in jdata:
  if item["id"] == id:
    if property.find(".") == -1:
      print(item[property])
    else:
      p = property.split(".")
      print(item[p[0]][p[1]])
    break
'

translate()
{
  local labels values format cvalue
  local action="${2,,}"
  local value="${3}"

  if [ "${value,,}" == "false" -o "${value,,}" == "true" ]; then
    value="${value,,}"
    value="${value^}"
    echo ${value}
    return
  fi

  format="$(getproperty ${1} "control.format")"

  if [ "${format}" == "boolean" ]; then
    if [[ "${value}" =~ ^[[:digit:]]*$ ]]; then
      [ ${value} -eq 0 ] && echo "False" || echo "True"
    else
      [[ "${value:0:1}" =~ ^[fF]$ ]] && echo "False" || echo "True"
    fi
    return
  fi

  if type ${1} &>/dev/null; then
    labels=($(eval ${1}))
    i=0
    for a in ${labels[@]}; do i=$((i+1)); values+=($i); done
  else
    while read -r a; do values+=("${a/\/*}"); labels+=("${a#*\/}"); done <<<"$(getspinnervalues "${1}")"
    if [ ${#labels[@]} -eq 0 ]; then
      echo "${value}"
      return
    fi
  fi

  if [ "${action}" == "getvalue" ]; then
    local i=0
    for item in "${labels[@]}"; do
      [ "${item,,}" == "${value,,}" ] && break || i=$((i+1))
    done
    if [ ${i} -lt ${#values[@]} ]; then
      echo "${values[${i}]}"
      return
    else
      action="getlabelvalue"
    fi
  fi

  if [ "${action}" == "getlabel" -o "${action}" == "getlabelvalue" ]; then
    local i=0
    for item in "${values[@]}"; do
      [ "${item,,}" == "${value,,}" ] && break || i=$((i+1))
    done
    if [ ${i} -lt ${#labels[@]} ]; then
      [ "${action}" == "getlabel"      ] && echo "${labels[${i}]}"
      [ "${action}" == "getlabelvalue" ] && echo "${values[${i}]}"
    else
      echo "${value}"
    fi
  else
    echo "${value}"
  fi
}

#Query spinner values from settings. Cache results for subsequent re-use.
getspinnervalues()
{
  [ -s ${TMPFILE1} ] || ${TCBIN} getsettings >${TMPFILE1}
  if [ "$(head -1 ${TMPFILE2})" != "${1}" ]; then
    echo "${1}" > ${TMPFILE2}
    cat ${TMPFILE1} | python -c "${PYTHON_VALUES}" "${1}" >> ${TMPFILE2}
  fi
  tail -n +2 ${TMPFILE2}
}
#Get control type
getproperty()
{
  [ -s ${TMPFILE1} ] || ${TCBIN} getsettings >${TMPFILE1}
  cat ${TMPFILE1} | python -c "${PYTHON_PROPERTY}" "${1}" $2
}

applysettings()
{
  local old new value setting msg
  local tcargs

  [ -n "${SECTION}" ] && tcargs="${tcargs} @section=${SECTION}"
  [ -n "${XBMCHOST}" ] && tcargs="${tcargs} @xbmc.host=${XBMCHOST}"

  if [ $# -lt 2 ]; then
    if [ $# -lt 1 ]; then
      echo "Need settings and arguments as parameters!"
    else
      msg=
      for setting in ${1}; do
        value="$(getproperty ${setting} "value")"
        value="$(translate ${setting} getlabel "${value}")"
        msg="${msg}, ${setting} [${value}]"
      done
      echo "Need arguments for settings: ${msg:2}"
    fi
    return
  fi

  for setting in ${1}; do
    shift

    old="$(getproperty ${setting} "value")"

    ${TCBIN} ${tcargs} setsetting ${setting} "$(translate ${setting} getvalue "${1}")"

    new="$(${TCBIN} ${tcargs} getsetting ${setting})"

    printf "%-30s: %5s -> %5s\n" \
      "${setting}" \
      "$(translate ${setting} getlabel "${old}")" \
      "$(translate ${setting} getlabel "${new#*: }")"
  done
}
