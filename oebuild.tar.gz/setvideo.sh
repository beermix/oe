#!/bin/bash

source ./settings.sh

applysettings "videoplayer.useomxplayer videoplayer.usemmal" "$@"
