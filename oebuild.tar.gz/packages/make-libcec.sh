#!/bin/bash

cd $(readlink -f $(dirname $0))

./supermk.sh libcec.git ./tools/mkpkg_libcec "$1" devel/libcec/package.mk
