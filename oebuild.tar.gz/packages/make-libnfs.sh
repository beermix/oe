#!/bin/sh

cd $(readlink -f $(dirname $0))

./supermk.sh libnfs.git ./tools/mkpkg_generic=libnfs=git://github.com/sahlberg/libnfs.git "$1" network/libnfs/package.mk
