#!/bin/bash

cd $(readlink -f $(dirname $0))

./supermk.sh p8-platform.git ./tools/mkpkg_generic=p8-platform=git://github.com/Pulse-Eight/platform "$1" mediacenter/p8-platform/package.mk
