#!/bin/sh

cd $(readlink -f $(dirname $0))

./supermk.sh kodi-platform.git ./tools/mkpkg_kodi-platform "$1" mediacenter/kodi-platform/package.mk
