#!/bin/sh

cd $(readlink -f $(dirname $0))

THIS_ADDON="$(basename $0 .sh | sed 's/^make-//')"

./supermk.sh ${THIS_ADDON}.git ./tools/mkpkg_kodi_addon=${THIS_ADDON} "$1" mediacenter/kodi-binary-addons/${THIS_ADDON}/package.mk
