#!/bin/bash

cd $(readlink -f $(dirname $0))

./supermk.sh kodi-latest.git ./tools/mkpkg_kodi "$1" kodi
