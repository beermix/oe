#!/bin/bash

cd $(readlink -f $(dirname $0))

./supermk.sh kodi-theme-Estuary-next.git ./tools/mkpkg_kodi-theme-Estuary-next "$1" mediacenter/kodi-theme-Estuary/package.mk
