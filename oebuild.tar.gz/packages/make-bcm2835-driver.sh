#!/bin/bash

cd $(readlink -f $(dirname $0))

./supermk.sh bcm2835-driver.git ./tools/mkpkg_bcm2835-driver "$1" graphics/bcm2835-driver/package.mk tools/bcm2835-bootloader/package.mk
