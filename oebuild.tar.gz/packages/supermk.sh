#!/bin/bash

#
# Usage:
#   supermk.sh script gitrev package.mk [package.mk]
#
# script:     Filename of script to make one or more tarballs, ie. ./tools/mkpkg_kodi
# gitrev:     Optional gitrev to use with package, or blank if using current package version
# package.mk: Package path (relative to OpenELEC/packages), repeats one or more times
#
# package.mk can repeat any number of times, so that multiple tarballs may be transferred
# per script execution.
#
# Example:
#
#   supermk.sh ./tools/mkpkg_kodi "" mediacenter/kodi/package.mk mediacenter/kodi-theme-Confluence/package.mk
#
# which would run a script to create two tarballs, and then transfer the two tarballs to the sources
# folder using the details from each of the specified packages.
#
THISBIN=$(readlink -f $(dirname $0))
cd ${THISBIN}/..
[ -f ./functions ] && source ./functions
cd ${THISBIN}

TMP_MAKER=$(gettmpdirp mkscripts clean)/nopull-mkpkg

function pkgtransfer()
{
  local package gitrev url target file xgz dir dirtygit
  package="$1"
  gitrev="$2"
  url="$3"
  file="$4"
  sha256="$5"
  target=${6:-$package}

  xgz=${file##*.}

  dir=${BUILD_REPO_PATH}/sources/${target}

  echo "${TXCYAN}Updating package: ${dir}/${file}${TXRESET}"

  mkdir -p ${dir}

  echo "${url}" > ${dir}/${file}.url || return 1

  # Use PKG_SHA256 from the package for our new tarball in order to keep
  # scripts/get happy, otherwise it will re-download the original package.
  if [ -n "${sha256}" ]; then
    echo "${sha256}" >${dir}/${file}.sha256
  else
    sha256sum ${package}-${gitrev}.tar.${xgz} | awk '{print $1}' > ${dir}/${file}.sha256 || return 1
  fi

  mv ${package}-${gitrev}.tar.${xgz} ${dir}/${file} || return 1

  # Tag package with branch and revision details of the current repo
  echo "$(getcurrentbranch "${THISBIN}/${GIT_NAME}") $(getcurrentrev "${THISBIN}/${GIT_NAME}")" > ${dir}/${file}.repo || return 1

  # Dirty this git so that its modification timestamp is same or older than tarball
  touch ${THISBIN}/${GIT_NAME}/.git
}

[ $# -ge 4 ] || die 1 "Error, must be at least 4 arguments for supermk.sh (repo_name, script, gitrev, package.mk)"

GIT_NAME="$1"
BUILD_INFO="$2"
PK_GITREV="$3"
FIRST_PKG="$4"

# Append .git if missing or not supplied...
[[ ${GIT_NAME} =~ \.git$ ]] || GIT_NAME+=".git"

# use kodi-latest for pvr.* etc.
if [ "$FIRST_PKG" == "kodi" ]; then
  KODI_REPO="${BUILD_REPOS}/${GIT_NAME}"
else
  KODI_REPO="${BUILD_REPOS}/kodi-latest.git"
fi

PK_MAKER="${BUILD_INFO%%=*}"
[[ "${BUILD_INFO}" =~ .*=.* ]] && ADDON_NAME="${BUILD_INFO#*=}"
if [[ -n "${ADDON_NAME}" && "${ADDON_NAME}" =~ .*=.* ]]; then
  ADDON_REPO="${ADDON_NAME#*=}"
  ADDON_NAME="${ADDON_NAME%%=*}"
fi

[ -x "${PK_MAKER}" ] || die 1 "Error, cannot find make script [${PK_MAKER}]"

export SUPERMK_BUILD_REPO_PATH="${BUILD_REPO_PATH}"
export SUPERMK_NEW_BRANCH="$(getbuildbranch "${THISBIN}/${GIT_NAME}" "${GIT_NAME}" "${BUILD_ENV_BRANCHES} ${BUILD_ENV_ADDON_BRANCHES}")"
export SUPERMK_NEW_BRANCH_REV="$(getbuildbranchrevfromprofile "${THISBIN}/${GIT_NAME}" "${GIT_NAME}" "${BUILD_ENV_BRANCHES} ${BUILD_ENV_ADDON_BRANCHES}")"

# If gitrev is "nopull" or -N, then remove "git pull" from maker
if [ "${PK_GITREV,,}" == "nopull" -o "${PK_GITREV}" == "-N" ]; then
  export PK_MAKER_PULL=no
  PK_GITREV=
else
  export PK_MAKER_PULL=yes
fi

# Process remaining arguments, which should now just be one or more package.mk
while [ $# -ge 4 ]; do
  PK_PATH="${4%/package.mk}"
  PK_ADDON="$(basename "${PK_PATH}")"

  if [ -f ${BUILD_REPO_PATH}/packages/${PK_PATH}/package.mk ]; then
    PK_PACKAGE="${BUILD_REPO_PATH}/packages/${PK_PATH}/package.mk"
  else
    PK_PACKAGE="$(find ${BUILD_REPO_PATH}/packages -type f -path "*/${PK_ADDON}/package.mk" | head -1)"
  fi
  shift

  [ -f ${PK_PACKAGE} ] || die 1 "ERROR: Package ${PK_PACKAGE} not found"

  PK_NAME="$(getoepkgoption_required ${PK_PACKAGE} PKG_NAME)" || die 1 "ERROR: PKG_NAME is not known"
  PK_VERSION="$(getoepkgoption_required ${PK_PACKAGE} PKG_VERSION)" || die 1 "ERROR: PKG_VERSION is not known"
  PK_URL="$(getoepkgoption_required ${PK_PACKAGE} PKG_URL)" || die 1 "ERROR: PKG_URL is not known"
  PK_SOURCE_NAME="$(getoepkgoption ${PK_PACKAGE} PKG_SOURCE_NAME)"
  PK_SHA256="$(getoepkgoption ${PK_PACKAGE} PKG_SHA256)"

  export PK_SOURCE_DIR="$(getoepkgoption ${PK_PACKAGE} PKG_SOURCE_DIR)"

  [ -z "${PK_SOURCE_NAME}" ] && PK_SOURCE_NAME="$(basename "${PK_URL}")"

  # Make the source tarball(s)
  if [ -n "${PK_MAKER}" ]; then
    [ -z "${PK_GITREV}" ] && GITREV=${PK_VERSION} || GITREV=${PK_GITREV}

    if [ -z "${ADDON_NAME}" ]; then
      echo "Making new source tarball with ${PK_MAKER}"
      ${PK_MAKER} "${PK_URL//*./}" "${GITREV}" "${KODI_REPO}" || die 1 "Error making tarball [${PK_MAKER}]"
    else
      echo "Making new source tarball with ${PK_MAKER} for addon: ${ADDON_NAME}"
      ${PK_MAKER} "${PK_URL//*./}" "${GITREV}" "${KODI_REPO}" "${ADDON_NAME}" "${ADDON_REPO}" || die 1 "Error making tarball [${PK_MAKER}] for addon [${ADDON_NAME}]"
    fi

    # Don't make the tarball(s) more than once...
    PK_MAKER=
  fi

  # Transfer the current tarball to its source directory along with md5 and url
  pkgtransfer "${PK_NAME}" "${GITREV}" "${PK_URL}" "${PK_SOURCE_NAME}" "${PK_SHA256}" || die 1 "Error, while transferring package [${PK_NAME}]"
done

rm -f ${TMP_MAKER}
