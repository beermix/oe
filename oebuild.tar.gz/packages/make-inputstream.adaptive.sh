#!/bin/sh

cd $(readlink -f $(dirname $0))

THIS_ADDON="$(basename $0 .sh | sed 's/^make-//')"

./supermk.sh ${THIS_ADDON}.git ./tools/mkpkg_generic=${THIS_ADDON}=git@github.com:peak3d/${THIS_ADDON}.git "$1" mediacenter/kodi-binary-addons/${THIS_ADDON}/package.mk
