#!/bin/sh

cd $(readlink -f $(dirname $0))

THIS_ADDON="$(basename $0 .sh | sed 's/^make-//')"
THIS_REPO="git://github.com/tvheadend/tvheadend.git"

./supermk.sh ${THIS_ADDON}.git ./tools/mkpkg_kodi_addon=${THIS_ADDON}=${THIS_REPO} "$1" addons/unofficial-addons/addons/service/multimedia/${THIS_ADDON}/package.mk
