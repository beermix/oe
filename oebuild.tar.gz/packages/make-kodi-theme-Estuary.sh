#!/bin/bash

cd $(readlink -f $(dirname $0))

./supermk.sh kodi-latest.git ./tools/mkpkg_kodi-theme-Estuary "$1" mediacenter/kodi-theme-Estuary/package.mk
