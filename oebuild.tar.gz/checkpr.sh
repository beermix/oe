#!/bin/bash
#
# Simple script to determine if any PR referenced in ipatches.dat
# is now merged upstream (checking against the local repository and upstream
# using the github api).
#
# Merged patches found in the OE build environment should be removed via
# a "removeFile" entry in oepull.dat.
#
# For accuracy, use up-to-date local repositories (ie. run git fetch/pull or mkpkg_*)
#
# Usage: ./checkpr.sh (takes no arguments)
#
# Add additional repositories to be matched at the end.
#
BIN=$(readlink -f $(dirname $0))
[ -f "${BIN}/functions" ] && source ${BIN}/functions

OEPULL=${BUILD_ENV_CONTROL}
OEPULL_NAME="$(basename ${OEPULL})"

PROGRESS=$(mktemp)
trap "output p ""; rm -f "${PROGRESS}"" EXIT

GLOBAL_HISTORY=()

output()
{
  local type msg msgclear
  type="${1,,}"
  shift
  msg="$@"

  if [ -f "${PROGRESS}" ]; then
    msgclear="$(cat ${PROGRESS})"
    [ -n "${msgclear}" ] && echo -en "${msgclear}\r" >&2
    if [ "${type}" == "p" ]; then
      echo -en "${msg}\r" >&2
      echo "${msg//?/ }" >${PROGRESS}
    else
      echo -e "${msg}"
    fi
  else
    [ "${type}" == "p" ] && echo -e "${msg}" >&2 || echo -e "${msg}"
  fi
}
progress()
{
  output "p" "$*"
}
message()
{
  output "m" "$*"
}

getownerrepo()
{
  local repo_name="${1}" repo_path="${2}" url

  [ -d "${repo_path}/.git" ] || return 1

  url="$(cd "${repo_path}" && git config --get remote.origin.url)"
  url="${url#*github.com/}"
  url="${url#*github.com:}"
  url="${url%.git}"
  echo $url
}

# Return list of latest merged PRs - this is limited to latest 250 PRs
# Would need to loop (paginate) for more, which will be slower... hmmm.
getRemoteMerged()
{
  local repo_name="$1" owner_repo="$2" sha="$3" url PY_PROG

  PY_PROG='
import sys, json
data = []
for line in sys.stdin: data.append(line)
jdata = json.loads("".join(data))
lines = []
for item in jdata.get("commits", jdata):
  commit = item["commit"]
  sha = item["sha"]
  msg = commit["message"].split("\n")[0]
  if msg.lower().startswith("merge"):
    lines.append("%s %s" % (sha, msg))
if lines:
  sys.stdout.write("%s\n" % "\n".join(lines))
'
  progress "[${repo_name}] Processing merged pull requests..."

  url="https://api.github.com/repos/${owner_repo}/compare/${sha}...master"
  curl -sL ${AUTHENTICATION} --connect-timeout 30 "${url}" | python -c "${PY_PROG}"
}

getRemoteClosed()
{
  local repo_name="$1" owner_repo="$2" flag="$3" url PY_PROG merged

  [ "${repo_name}" == "*" ] && return 0

  PY_PROG='
import sys, json
merged = sys.argv[1:][0]
data = []
for line in sys.stdin: data.append(line)
jdata = json.loads("".join(data))
lines = []
for item in jdata:
  if merged == "Y":
    if item["merged_at"] is not None:
      lines.append("%s" % item["number"])
  else:
    if item["merged_at"] is None:
      lines.append("%s" % item["number"])
if lines:
  sys.stdout.write("%s\n" % "\n".join(lines))
'
  [ "${flag}" == "Y" ] && merged="merged" || merged="unmerged"
  progress "[${repo_name}] Processing closed (${merged}) pull requests..."

  url="https://api.github.com/repos/${owner_repo}/pulls?state=closed&sort=updated&direction=desc"
  curl -sL ${AUTHENTICATION} --connect-timeout 30 "${url}" | python -c "${PY_PROG}" "${flag}"
}

getGitMerges()
{
  local reponame="$(git remote show origin -n | grep --binary-files=text "Fetch URL:" | sed -E 's#^.*/(.*)$#\1#' | sed 's#.git$##')"
  local since

  progress "[${1}] Processing git repo..."

  [ "${reponame}" == "LibreELEC.tv" ] && since="--since=13-Mar-2016"

  git log --pretty=oneline --no-color --merges ${since} | cut -b42- | ${TGREP} -E '^Merge [pP]' | sed 's/^Merge [^0-9]*\([0-9]*\).*/\1/'
}

getAllMerges()
{
  local repo_name="$1" dir="$2" owner_repo="$3" owd

  [ "${repo_name}" == "*" ] && return 0

  owd="${PWD}"
  cd ${dir}
  getRemoteMerged "${repo_name}" "${owner_repo}" "$(git rev-parse HEAD)" | cut -b42- | ${TGREP} -E '^Merge [pP]' | sed 's/^Merge [^0-9]*\([0-9]*\).*/\1/'
  getRemoteClosed "${repo_name}" "${owner_repo}" "Y"
  getGitMerges "${repo_name}"
  cd "${owd}"
}

rewrite_url4api()
{
  local url="${1}" newurl="${1}"
  local fields=(${url//\// })

  if [ "${fields[1]}" == "github.com" ]; then
    fields[1]="api.github.com"
    [ "${fields[4]}" == "pull" ] && fields[4]="pulls"
    [ "${fields[4]}" == "commit" ] && fields[4]="commits"
    newurl="${fields[0]}//${fields[1]}/repos/${fields[2]}/${fields[3]}/${fields[4]}/${fields[5]%\.patch}"
  elif [ "${fields[1]}" == "patch-diff.githubusercontent.com" ]; then
    fields[1]="api.github.com"
    [ "${fields[5]}" == "pull" ] && fields[5]="pulls"
    [ "${fields[5]}" == "commit" ] && fields[5]="commits"
    newurl="${fields[0]}//${fields[1]}/repos/${fields[3]}/${fields[4]}/${fields[5]}/${fields[6]%\.patch}"
  fi

  echo "${newurl}"
}

getRemoteClosed_Single()
{
  local url="${1}"
  local pullreq status merged

  [ "x${url:0:1}" == "x-" ] && url="${url:1}"

  [[ ${url} =~ ^https://github.com/.*/pull/.*$ ]] || return 1

  pullreq="$(curl -sfL ${AUTHENTICATION} --connect-timeout 30 --retry 6 "$(rewrite_url4api "${url}")" -o-)"
  status="$(echo "${pullreq}" | ${TGREP} -m1 '^[ ]*"state": ".*",$' | awk '{ print $2 }')"
  status="${status:1:-2}"

  [ -n "$(echo "${pullreq}" | ${TGREP} -m1 '^[ ]*"merged_at": "[0-9TZ:-]*",$')" ] && merged=Y || merged=N

#echo "STATUS: [${status}], MERGED: [${merged}], url [$(rewrite_url4api "${url}")]" >&2
  [ "${status}" == "closed" -a "${merged}" == "N" ] && return 0 || return 1
}

getRemoteMerged_Single()
{
  local url="${1}"

  [ "x${url:0:1}" == "x-" ] && url="${url:1}"

  [[ ${url} =~ ^https://github.com/.*/pull/.*$ ]] || return 1

  curl -sfL ${AUTHENTICATION} --connect-timeout 30 --retry 6 -H "Accept: application/vnd.github.v3.patch" "$(rewrite_url4api "${url}")/merge"
  return $?
}

extractLocalPRs()
{
  local repo_name="$1" owner_repo="$2" pr_prefix="$3" line url ufields clast slast cutfield filter package fpmsg

  progress "[${repo_name}] Extracting local PRs..."

  while read -r line; do
    [ -z "${line}" -o "x${line:0:1}" == "x#" ] && continue

    fields=(${line})
    filter=
    package=
    cutfield=2
    if [ "${fields[0]:0:1}" == "=" ]; then
      if [ "${LOCAL_PKG_FILTERS}" != "*" ]; then
        findinlist "${fields[0]:1}" "${LOCAL_PKG_FILTERS}" || continue
      fi
      filter="${fields[0]}"
      fields=(${fields[@]/${fields[0]}})
      cutfield=$((cutfield + 1))
    fi

    if [ "${fields[0]:0:1}" == "!" ]; then
      [ "${fields[0]}" != "!${repo_name}" ] && continue
      package="${fields[0]:1}"
      fields=(${fields[@]/${fields[0]}})
      cutfield=$((cutfield + 1))
    fi

    [ "${fields[0]}" == "import" ] && continue

    url="${fields[0]#*\!}"
    ufields=(${url//\// })
    clast=$((${#ufields[@]} - 1))
    slast="${ufields[${clast}]}"

    [ -z "${package}" ] && [[ ${url} =~ ^.*/pull/[0-9]*$ ]] && package="${ufields[$((${#ufields[@]} - 3))]}"
    [ -z "${package}" ] && package="kodi"

    if [ "${repo_name}" == "*" ]; then
      in_global_history "${package}" && continue
    else
      [ "${package,,}" != "${repo_name,,}" ] && continue
    fi

    fpmsg=
    [ -n "${filter}" ] && fpmsg="${fpmsg}${filter}, "
    [ -n "${package}" ] && fpmsg="${fpmsg}${package}, "
    [ -n "${fpmsg}" ] && fpmsg=" (${fpmsg%, })"

    if [ "${repo_name}" == "*" ]; then
      echo "${url} $(echo "${line}" | cut -d' ' -f${cutfield}-)${fpmsg}"
    elif [[ "${slast}" =~ ^[0-9]*$ ]]; then
      echo "${slast} $(echo "${line}" | cut -d' ' -f${cutfield}-)${fpmsg}"
    elif [[ "${slast}" =~ ^${pr_prefix}[0-9]*$ ]]; then
      echo "${slast} $(echo "${line}" | cut -d' ' -f${cutfield}-)${fpmsg}"
    fi
  done <<< "$(cat ${BUILD_PKG_CONTROL})"
}

in_global_history()
{
  local r
  for r in ${GLOBAL_HISTORY[@]}; do
    [ "${r}" == "${1,,}" ] && return 0
  done
  return 1
}

add_global_history()
{
  if [ "${1}" != "*" ]; then
    in_global_history "${1}" || GLOBAL_HISTORY+=("${1,,}")
  fi
  return 0
}

getremovefiles()
{
  local line fields filter

  while read -r line; do
    [ -z "${line}" ] && continue
    fields=(${line})
    filter=
    if [ "${fields[0]:0:1}" == "=" ]; then
      if [ "${LOCAL_ENV_FILTERS}" != "*" ]; then
        findinlist "${fields[0]:1}" "${LOCAL_ENV_FILTERS}" || continue
      fi
      fields=(${fields[@]/${fields[0]}})
    fi
    case "${fields[0],,}" in
      remove)     echo "${fields[1]}";;
      removefile) echo "${fields[1]}";;
    esac
  done <<< "$(${TGREP} -v "^#" ${OEPULL} | tr -d '\r')"
}

extractUpstreamPRs()
{
  local repo_name="$1" root="$2" folder="$3" pr_prefix="$4" f pr owd
  local removedfiles=($(getremovefiles))

  progress "[${repo_name}] Extracting upstream PRs..."

  owd="${PWD}"
  cd ${root}/${folder}

  while read -r f; do
    pr="$(echo "${f}" | sed "s/.*-\(${pr_prefix}[0-9]*\)\.patch/\1/")"
    if [ "${pr}" != "${f}" ]; then
      findinlist "${folder}/${f}" "${removedfiles[@]}" || echo "${pr}  ${folder}/${f}"
    fi
  done <<< "$(ls -1 *.patch)"

  cd "${owd}"
}

extractbuildpr()
{
  local line fields filter cutfield url pr
  while read -r line; do
    [ -z "${line}" ] && continue
    fields=(${line})
    filter=
    cutfield=2
    if [ "${fields[0]:0:1}" == "=" ]; then
      if [ "${LOCAL_ENV_FILTERS}" != "*" ]; then
        findinlist "${fields[0]:1}" "${LOCAL_ENV_FILTERS}" || continue
      fi
      fields=(${fields[@]/${fields[0]}})
      cutfield=$((cutfield + 1))
    fi
    url=
    case "${fields[0],,}" in
      forwardpatch)   url="${fields[1]}";;
      reversepatch)   url="${fields[1]}";;
    esac
    if [ -n "${url}" ]; then
#      pr="$(echo "${url}" | sed 's~^${BUILD_TYPE_GITHUB}/pull/~~')"
      pr="$(echo "${url}" | sed 's~^https://.*/pull/~~')"
      [ "${pr}" != "${url}" ] && echo "${pr} ${line}"
    fi
  done <<< "$(${TGREP} -v "^#" ${OEPULL} | tr -d '\r')"
}

validateFilters()
{
  local line count fields filters invalid filter
  local count
  local validfilters

  validfilters=($(_getValidFilters "BUILD_ENV_FILTERS" "LOCAL_ENV_FILTERS"))

  count=0
  while read -r line; do
    count=$((count + 1))
    [ -z "${line}" -o "x${line:0:1}" == "x#" ] && continue

    fields=(${line})
    [ "${fields[0]:0:1}" == "=" ] && filters="${fields[0]:1}" || continue

    invalid=($(_validateFilter "${filters}" "${validfilters[@]}"))
    [ ${#invalid[@]} -eq 0 ] && continue

    for filter in ${invalid[@]}; do
      echo "${OEPULL}:${count} - WARNING: Filter [$filter] is not an available filter in profiles.dat, check spelling!"
    done
  done <<< "$(cat ${OEPULL} | tr -d '\r')"

  validfilters=($(_getValidFilters "BUILD_PKG_FILTERS" "LOCAL_PKG_FILTERS"))

  count=0
  while read -r line; do
    count=$((count + 1))
    [ -z "${line}" -o "x${line:0:1}" == "x#" ] && continue

    fields=(${line})
    [ "${fields[0]:0:1}" == "=" ] && filters="${fields[0]:1}" || continue

    invalid=($(_validateFilter "${filters}" "${validfilters[@]}"))
    [ ${#invalid[@]} -eq 0 ] && continue

    for filter in ${invalid[@]}; do
      echo "${BUILD_PKG_CONTROL}:${count} - WARNING: Filter [$filter] is not an available filter in profiles.dat, check spelling!"
    done
  done <<< "$(cat ${BUILD_PKG_CONTROL} | tr -d '\r')"

  count=0
  while read -r line; do
    count=$((count + 1))
    [ -z "${line}" -o "x${line:0:1}" == "x#" ] && continue

    fields=(${line})
    [ "${fields[0]:0:1}" == "\$" ] && filters="${fields[0]:1}"
    [ "${fields[0]:0:1}" == "=" ] && filters="${fields[0]:1}" || continue

    invalid=($(_validateFilter "${filters}" "${validfilters[@]}"))
    [ ${#invalid[@]} -eq 0 ] && continue

    for filter in ${invalid[@]}; do
      echo "${BUILD_PKG_BWLIST}:${count} - WARNING: Filter [$filter] is not an available filter in profiles.dat, check spelling!"
    done
  done <<< "$(cat ${BUILD_PKG_BWLIST} | tr -d '\r')"
}

_getValidFilters()
{
  local token="${1}" otoken="${2}"
  local line fields filter
  local validfilters=()

  validfilters+=(${!otoken})

  while read -r line; do
    [ -z "${line}" ] && continue
    fields=(${line})
    for filter in ${fields[@]}; do
      containsElement "${filter}" "${validfilters[@]}" || validfilters+=(${filter})
    done
  done <<< "$(${TGREP} "^${token}=" ${BIN}/profiles.dat | awk -F= '{print $2}')"

  echo "${validfilters[@]}"
}

_validateFilter()
{
  local filters="$1" validfilters=(${@:2})
  local fields filter
  local errfilters=()

  fields=(${filters//,/ })
  for filter in ${fields[@]}; do
    [ "${filter:0:1}" == "!" ] && filter="${filter:1}"
    containsElement "${filter}" "${validfilters[@]}" || errfilters+=("${filter}")
  done

  [ ${#errfilters[@]} != 0 ] && echo "${errfilters[@]}"
}

containsElement()
{
  local e
  for e in "${@:2}"; do [[ "$e" == "$1" ]] && return 0; done
  return 1
}

checkMatches()
{
  local line repo_name repo_path pr_prefix alt_repo_root alt_repo_fldr owner_repo pr count prlist msg cutfirst=N
  local cbranch wbranch

  repo_name="$1"
  repo_path="$(readlink -f ${BIN}/${2})"
  pr_prefix="$3"
  alt_repo_root="$4"
  alt_repo_fldr="$5"

  [ -z "${repo_path}" ] && repo_path="${2}"

  # Might be an absolute path...
  [ -d "${repo_path}" ] || repo_path="${2}"

  if [ ! -d "${repo_path}" ]; then
#    message "Not checking ${repo_name}, repo path is not valid (${repo_path})"
    return 1
  fi

  cbranch="$(getcurrentbranch "${repo_path}")"
  wbranch="$(getbuildbranch "${repo_path}" "${repo_name}")"
#  if [ "${cbranch}" != "${wbranch}" ]; then
#    echo "WARNING: Repo [$(basename ${repo_path})] is on branch [${cbranch}] when branch [${wbranch}] is required - skipping"
#    return 1
#  fi

  owner_repo="$(getownerrepo "${repo_name}" "${repo_path}")" || die 1 "ERROR: Unable to determine owner/repo for ${repo_name}"

  if [ "${pr_prefix}" == "oepull.dat" ]; then
    pr_prefix=
    cutfirst=Y
    prlist="$(extractbuildpr | sort -k1n)"
    msg_merge="The following pull requests are already merged in ${repo_name} - remove from ${OEPULL_NAME}:"
    msg_close="The following pull requests are closed in ${repo_name} - remove from ${OEPULL_NAME}:"
  elif [ -z "${alt_repo_root}" ]; then
    prlist="$(extractLocalPRs "${repo_name}" "${owner_repo}" "${pr_prefix}")"
    msg_merge="The following pull requests are already merged in ${repo_name} - remove from ${BUILD_PKG_CONTROL}:"
    msg_close="The following pull requests are closed in ${repo_name} - remove from ${BUILD_PKG_CONTROL}:"
  else
    prlist="$(extractUpstreamPRs "${repo_name}" "${alt_repo_root}" "${alt_repo_fldr}" "${pr_prefix}" | sort -k1n)"
    msg_merge="The following pull requests are already merged in ${repo_name}, but also present in ${alt_repo_root} - add \"removeFile *\" to ${OEPULL_NAME}:"
    msg_close="The following pull requests are closed in ${repo_name}, but also present in ${alt_repo_root} - add \"removeFile *\" to ${OEPULL_NAME}:"
  fi

  if [ -n "${prlist}" ]; then
    mergelist="$(getAllMerges "${repo_name}" "${repo_path}" "${owner_repo}" | sort -k1n -u)"
    closelist="$(getRemoteClosed "${repo_name}" "${owner_repo}" "N" | sort -k1n)"

    count=0
    while read -r line; do
      pr="$(echo "${line}" | awk '{ print $1 }' | sed "s/^${pr_prefix}//")"
      if echo "${mergelist}" | ${TGREP} --silent -E "^${pr}$" || getRemoteMerged_Single "${pr}"; then
        [ ${count} -eq 0 ] && message "\n${msg_merge}"
        [ ${cutfirst} == Y ] && line="$(echo "${line}" | cut -d' ' -f2-)"
        message "  ${line}"
        count=$((count+1))
      fi
    done <<< "$(echo "${prlist}" | sort -k1n)"

    count=0
    while read -r line; do
      pr="$(echo "${line}" | awk '{ print $1 }' | sed "s/^${pr_prefix}//")"
      if echo "${closelist}" | ${TGREP} --silent -E "^${pr}$" || getRemoteClosed_Single "${pr}"; then
        [ ${count} -eq 0 ] && message "\n${msg_close}"
        [ ${cutfirst} == Y ] && line="$(echo "${line}" | cut -d' ' -f2-)"
        message "  ${line}"
        count=$((count+1))
      fi
    done <<< "$(echo "${prlist}" | sort -k1n)"
  fi

  add_global_history "${repo_name}"
  
  return 0
}

checkBlacklist()
{
  local line fields shafield text package patches
  local lines count=0

  while read -r line; do
    [ -z "${line}" -o "x${line:0:1}" == "x#" ] && continue

    fields=(${line})
    shafield=0

    [ "${fields[0]:0:2}" == "+=" -o "${fields[0]:0:2}" == "$=" ] && fields[0]="${fields[0]:1}"

    if [ "${fields[0]:0:1}" == "=" ]; then
      if [ "${LOCAL_PKG_FILTERS}" != "*" ]; then
        findinlist "${fields[0]:1}" "${LOCAL_PKG_FILTERS}" || continue
      fi
      shafield=$((shafield + 1))
    fi

    package="kodi"
    if [ "${fields[${shafield}]:0:1}" == "!" ]; then
      package="${fields[${shafield}]:1}"
      shafield=$((shafield + 1))
    fi

    text="$(trim "${line/*${fields[${shafield}]}}")"
    [ -z "${text}" ] && continue

    [ -n "${patches}" ] && patches="${patches}\n"
    patches="${patches}${package}#ANCHOR#${text}#ANCHOR#"
  done < "${BUILD_PKG_PATCHES}"

  while read -r line; do
    count=$((count + 1))
    [ -z "${line}" -o "x${line:0:1}" == "x#" ] && continue

    fields=(${line})
    shafield=0

    [ "${fields[0]:0:2}" == "+=" -o "${fields[0]:0:2}" == "$=" ] && fields[0]="${fields[0]:1}"

    if [ "${fields[0]:0:1}" == "=" ]; then
      if [ "${LOCAL_PKG_FILTERS}" != "*" ]; then
        findinlist "${fields[0]:1}" "${LOCAL_PKG_FILTERS}" || continue
      fi
      shafield=$((shafield + 1))
    fi

    package="kodi"
    if [ "${fields[${shafield}]:0:1}" == "!" ]; then
      package="${fields[${shafield}]:1}"
      shafield=$((shafield + 1))
    fi

    text="$(trim "${line/*${fields[${shafield}]}}")"
    [ -z "${text}" ] && continue

    echo -e "${patches}" | ${TGREP} -F "${package}#ANCHOR#${text}#ANCHOR#" >/dev/null || lines="${lines}\n$(printf "%04d" $count): ${line}"
  done < "${BUILD_PKG_BWLIST}"

  [ -n "${lines}" ] && message "\nThe following lines are no longer required in ${BUILD_PKG_BWLIST}:${lines}"
}

usage()
{
  cat <<EOF
Usage: $(basename $0) [-v] [-l] [-b | -B] [-C|-A patchcode] [-h]
$(basename $0) options:
    -v  Validate filter codes
    -l  Use local patches.dat file - default is to user per-profile file (if it exists)
    -b  Check blacklists too
    -B  Check ONLY blacklists
    -C  Patchcode(s) when filtering commits/imports
    -A  Additional patchcode(s) to be used when filtering commits/imports
    -h  This message
EOF
}

PATCHCODE=
PADDCODE=
VALIDATE=N
USELOCALPATCHES=N
BLACKLIST=N

while getopts ":vlbBC:A:" opt; do
  GOTOPTS=Y
  case ${opt} in
    v) VALIDATE=Y;;
    l) USELOCALPATCHES=Y;;
    b) BLACKLIST=Y;; # normal + blacklist
    B) BLACKLIST=X;; # blacklist only
    C) PATCHCODE="${PATCHCODE}${OPTARG} ";;
    A) PADDCODE="${PADDCODE}${OPTARG} ";;
    h) usage && exit 0;;
    ?) usage && die 1 "ERROR: Unknown argument [${OPTARG}]"
  esac  
done

if [ -n "${PATCHCODE}" ]; then
  LOCAL_ENV_FILTERS="${PATCHCODE::-1}"
  LOCAL_PKG_FILTERS="${PATCHCODE::-1}"
else
  LOCAL_ENV_FILTERS="${BUILD_ENV_FILTERS}"
  LOCAL_PKG_FILTERS="${BUILD_PKG_FILTERS}"
fi
if [ -n "${PADDCODE}" ]; then
  LOCAL_ENV_FILTERS="${LOCAL_ENV_FILTERS} ${PADDCODE::-1}"
  LOCAL_PKG_FILTERS="${LOCAL_PKG_FILTERS} ${PADDCODE::-1}"
fi

if [ "${USELOCALPATCHES}" == "N" ]; then
  profile_patches="$(gettmpdirp)/patches.dat"
  [ -f ${profile_patches} ] && BUILD_PKG_PATCHES=${profile_patches}
fi

[ ${VALIDATE} == Y ] && validateFilters

if [ ${BLACKLIST} != X ]; then
  checkMatches "${BUILD_TYPE_PNAME}" ${BUILD_REPO_PATH}              "oepull.dat"
  checkMatches "${BUILD_TYPE_PNAME}" ${BUILD_REPO_PATH}              "OEPR"
  checkMatches "Kodi"                ${BUILD_REPOS}/kodi-latest.git  "PR"
  checkMatches "Kodi"                ${BUILD_REPOS}/kodi-latest.git  "PR"          ${BUILD_REPO_PATH} packages/mediacenter/kodi/patches
  checkMatches "libcec"              ${BUILD_REPOS}/libcec.git
  checkMatches "libnfs"              ${BUILD_REPOS}/libnfs.git
  checkMatches "${BUILD_TYPE_PNAME}-settings"   ${BUILD_REPOS}/${BUILD_TYPE_PNAME}-settings.git

  checkMatches "*"                   ${BUILD_REPO_PATH}
fi

[ ${BLACKLIST} != N ] && checkBlacklist
