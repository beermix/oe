#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function
import os
import sys
import codecs
import re

class MyConfig():
  def __init__(self, filename, debug=False):
    sections = {}

    self.RE_VARIABLE = re.compile("\${+[a-zA-z0-9_]+}+")
    self.RE_ARG_WITH_BRACES = re.compile("\${([0-9]+)}")
    self.RE_ARG_WITHOUT_BRACES = re.compile("\$([0-9]+)")

    if self._sourcefile(True, filename, sections, "defaults", debug):
      self.Sections = sections
    else:
      sys.exit(1)

  def sections(self):
    return self.Sections.keys()

  def getItems(self, name):
    for key, value, op in self.Sections.get(name)[0]:
      yield key, value, op

  def getErrors(self, name):
    return self.Sections.get(name)[1]

  def getprofile(self, name=""):
    settings = []
    self._getprofile("defaults", settings, {}, optional=True, primary=False)
    self._getprofile(name, settings, {}, optional=False, primary=True)

    #Automatically load profile settings of the first autobuild profile
    isautobuild = False
    first_autobuild_profile = None
    for k, v in settings:
      if k == "AUTOBUILD_PROFILES" and v:
        # If we have a value, and the first profile of the current value
        # is not a substitution, then ignore this value and continue with
        # our current value
        if v.startswith("$") and first_autobuild_profile is not None:
          continue
        for p in v.split(" "):
          if p in self.sections():
            first_autobuild_profile = p
            break
      elif k == "AUTOBUILD_PARALLEL" and v.lower() == "yes":
        isautobuild = True

    if isautobuild and first_autobuild_profile is None and os.environ.get("AUTOBUILD_PROFILES") is not None:
      for p in os.environ["AUTOBUILD_PROFILES"].replace(",", " ").split(" "):
        if p in self.sections():
          first_autobuild_profile = p
          break

    if isautobuild and first_autobuild_profile is not None:
      self._getprofile(first_autobuild_profile, settings, {}, optional=False, primary=False)

    return settings

  # Example: replace=BUILD_PKG_FILTERS,rpi-.*,rpi-4.2.y
  # would replace rpi-4.*.y with rpi-4.2.y in BUILD_PKG_FILTERS
  def _replace(self, settings, token):
    tokens = token.split(",")
    if len(tokens) == 3:
      (name, pattern, value) = (tokens[0], tokens[1], tokens[2])
    elif len(tokens) == 2:
      (name, pattern, value) = (tokens[0], tokens[1], "")
    else:
      (name, pattern, value) = (tokens[0], "", "")

    if name and pattern:
      i = 0
      for k, v in settings:
        if k == name:
          words = []
          for word in settings[i][1].split(" "):
            word = re.sub(pattern, value, word)
            if word: words.append(word)
          settings[i] = (settings[i][0], " ".join(words))
        i += 1

    return

  # Append (add), subtract (sub) or replace (set) current value with new value
  def _handleop(self, settings, key, value, op):
    if op == "set":
      newvalue = value
    else:
      newvalue = ""
      for k, v in settings:
        if k == key:
          newvalue= v

      if op == "ifnull":
        if newvalue == "":
          newvalue = value
      elif op == "add":
        newvalue = "%s %s" % (newvalue.strip(), value.strip())
      elif op == "sub":
        words = []
        for word in newvalue.split(" "):
          if re.match(value, word) is None:
            words.append(word)
        newvalue = " ".join(words)
      else:
        newvalue = value

    return newvalue.strip()

  # Expand values, rather than leaving it up to the shell
  # This allows earlier replacement, which is otherwise
  # impossible with late expansion by the shell.
  def _expand(self, settings, key, value, op):
    if value.find("$") == -1:
      return self._handleop(settings, key, value, op)

    newvalue = value
    replacement = []

    # Iterate over expandable items, creating a list of
    # replacements (last is first)
    for variable in self.RE_VARIABLE.finditer(value):
      token = variable.group(0)
      var = token[1:]
      var = var[1:] if var.startswith("{") else var
      var = var[:-1] if var.endswith("}") else var

      if var != "BIN": #Always expand BIN late
        replace = None

        for k, v in settings:
          if k == var:
            replace = (variable.start(0), variable.end(0), v)

        if replace is None:
          if var == "PROFILE":
            replace = (variable.start(0), variable.end(0), profile)
          elif var.startswith("BUILD"):
            replace = (variable.start(0), variable.end(0), "")

        if replace:
          replacement.insert(0, replace)

    # Process replacement list, in right-to-left order
    for replace in replacement:
      newvalue = "%s%s%s" % (newvalue[:replace[0]], replace[2], newvalue[replace[1]:])

    return self._handleop(settings, key, newvalue, op)

  def _getprofile(self, name, settings, profilehist, optional=False, primary=True):
    if name in profilehist:
      printerr("ERROR: Profile \"%s\" is being recursively extended - profile load aborted" % name)
      sys.exit(1)

    if name not in self.sections():
      if optional: return
      printerr("ERROR: Profile \"%s\" is not valid" % name)
      sys.exit(1)

    profilehist[name] = True
    if optional and not primary:
      action = "init"
    elif not optional and primary:
      action = "actual"
    else:
      action = "extend"
    settings.append(("#%s [%s]" % (name, action), None))

    if self.getErrors(name) != []:
      printerr("\n".join(self.getErrors(name)))
      sys.exit(1)

    for key, value, op in self.getItems(name):
      # Allow one profile to be based on another profile
      if key == "base":
        if value.lower() == "yes" and primary == True:
          printerr("ERROR: Profile \"%s\" is marked as a base profile, and should not be used directly" % name)
          sys.exit(1)
      elif key == "extends":
        self._getprofile(value, settings, profilehist, optional=False, primary=False)
      elif key == "override":
        pass
      elif key == "replace":
        self._replace(settings, value)
      else:
        settings.append((key, self._expand(settings, key, value, op)))

  def _expandshellvars(self, value):
    result = ""
    for var in re.split("(\$\{?[A-Z]*}?)", value):
      if var.startswith("$"):
        var=var[1:]
        var = var[1:] if var.startswith("{") else var
        var = var[:-1] if var.endswith("}") else var
        var = os.environ.get(var)

      result += var

    return result

  def _sourcefile(self, mustexist, filename, sections, name="default", debug=False):
    efilename = self._expandshellvars(filename)
    if os.path.exists(efilename) == False:
      if mustexist:
        printerr("ERROR: Profile file not found %s [%s]" % (efilename, filename))
        return not mustexist

    with codecs.open(efilename, "rb", encoding="utf-8") as inputfile:
      data = inputfile.read().replace("\r","").split("\n")

    # expand template group
    data = self._expandTemplates(data)

    (items, errors) = sections.get(name, ([], []))
    override = (name in sections)

    for line in data:
      if debug: print(line)
      line = line.strip()
      if line == "": continue
      if line.startswith("#"): continue
      if line.startswith("[") and line.endswith("]"):
        if items or errors:
          if name in sections and override == False:
            printerr("ERROR: Repeated section [%s] in %s. Add override=yes if trying to change an existing profile of the same name." % (name, filename))
            return False
          sections[name] = (items, errors)

        name = line[1:-1]
        (items, errors) = sections.get(name, ([], []))
        override = False
      else:
        isdirective = False

        pos = line.find("=")
        if pos == -1:
          pos = line.find(" ")
          isdirective = True

        key = line[0:pos].replace(" ","").strip()
        value = line[pos + 1:].strip()

        if isdirective:
          op = "dir"
        else:
          if key.endswith("+"):
            op = "add"
            key = key[:-1]
          elif key.endswith("-"):
            op = "sub"
            key = key[:-1]
          elif key.endswith("?"):
            op = "ifnull"
            key = key[:-1]
          elif key == "override" and value.lower() == "yes":
            override = True
            continue
          else:
            op = "set"

        if key == "source":
          if name in sections and override == False:
            printerr("ERROR: Repeated section [%s] in %s. Add override=yes if trying to change an existing profile of the same name." % (name, filename))
            return False

          beingadded = name in sections
          sections[name] = (items, errors)

          if self._sourcefile(False, value, sections, name, debug) == False:
            errors.append("ERROR: Profile file not found or contains errors %s" % value)
            return False

          (items, errors) = sections.get(name, ([], []))
          override = not beingadded
        else:
          items.append((key, value, op))

    if items or errors:
      if name in sections and override == False:
        printerr("ERROR: Repeated section [%s] in %s. Add override=yes if trying to change an existing profile of the same name." % (name, filename))
        return False
      sections[name] = (items, errors)

    return True

  def _expandTemplates(self, data):
    newdata = []
    templates = []
    intemplate = False
    offset = 0
    count = 0

    newprofiles = []

    for line in data:
      count += 1
      if line.startswith("[") and line.endswith("]"):
        if templates != []:
          newdata = self._insert_profiles(offset, templates, newdata)
          templates = []
        if line.lower() == "[templates]":
          offset = count
          intemplate = True
        else:
          intemplate = False

      if intemplate:
        if not (line.startswith("[") and line.endswith("]")):
          templates.append(line)
        newdata.append("#%s" % line)
      else:
        newdata.append(line)

    if templates != []:
      newdata = self._insert_profiles(offset, templates, newdata)

    return newdata

  def _insert_profiles(self, offset, templates, data):
    overshoot = -1

    for i, e in reversed(list(enumerate(templates))):
      overshoot += 1
      if not (e.startswith("#") or e == ""):
        break

    if overshoot > 0:
      data = data[0:-overshoot]
      excess = templates[-overshoot:]
      templates = templates[0:-overshoot]
    else:
      excess = []

    data.append("")
    data.append("##### START of generated profiles - do not edit #####")
    data.extend(self._generate_profiles(offset, templates))
    if data[-1] == "": data = data[:-1]
    data.append("##### END of generated profiles - do not edit #####")
    data.extend(excess)

    return data

  def _generate_profiles(self, offset, templates):
    profiles = []

    cmdwasprev = False

    select = ""
    name = ""
    cmdlist = []
    count = 0

    for line in templates:
      count += 1
      line = line.strip()
      if line == "": continue
      if line.startswith("#"): continue

      pos = line.find("=")
      if pos == -1:
        key = ""
      else:
        key = line[0:pos].replace(" ","")
        value = line[pos + 1:]

      if key == "cmd":
        if select and name:
          cmdlist.append(value)
        else:
          printerr("ERROR: Invalid template syntax - profile load aborted [%s] - select and name not set, line #%d" % (line, (offset + count)))
          sys.exit(1)
      else:
        if cmdlist != [] and name:
          profiles.append({"select": select, "name": name, "cmd": cmdlist})
          cmdlist = []
          name = ""

        if key == "select":
          select = value
        elif key == "name":
          name = value
        else:
          printerr("ERROR: Invalid template syntax - profile load aborted [%s], line #%d" % (line, (offset + count)))
          sys.exit(1)

    if cmdlist != [] and name:
      profiles.append({"select": select, "name": name, "cmd": cmdlist})

    for profile in profiles:
      for data in self._generate_one_profile(profile):
        yield data

  def _generate_one_profile(self, profile):
    list = profile.get("select", "")
    name = profile.get("name", "")
    cmds = profile.get("cmd", [])

    profiles = []
    parenth = False
    word = ""
    for c in list:
      word = word + c
      if c == "(":
        parenth = True
      elif c == ")":
        parenth = False
        profiles.append(self._splitwordargs(word.strip()))
        word = ""
      elif c == " ":
        if not parenth:
          if word.strip() != "":
            profiles.append(self._splitwordargs(word.strip()))
          word = ""

    if word != "":
      profiles.append(self._splitwordargs(word.strip()))

    lines = []
    for profile in profiles:
      lines.append("[%s]" % self._subwordargs(name, profile["args"]))
      for cmd in cmds:
        lines.append("%s" % self._subwordargs(cmd, profile["args"]))
      lines.append("")

    return lines

  def _splitwordargs(self, word):
    items = word.replace("(", " ").replace(")", " ").replace(",", " ").strip().split(" ")
    return {"profile": items[0], "args": items}

  def _subwordargs(self, word, args):
    while True:
      arg = self.RE_ARG_WITH_BRACES.search(word)
      if arg is None:
        arg = self.RE_ARG_WITHOUT_BRACES.search(word)
        if arg is None: break
      index = int(arg.groups()[0])
      if index > len(args):
        printerr("ERROR: invalid argument [%d] for [%s]" % (index, word))
        sys.exit(1)
      word = word[:arg.start(0)] + args[index] + word[arg.end(0):]
    return word

def printerr(msg):
  print(msg, file=sys.stderr, end="\n")
  sys.stderr.flush()
def isoption(key):
  return key.startswith("OPTION_")
def isexport(key):
  return key.startswith("EXPORT_")
def translate(key, value):
  if isoption(key):
    return "%s=\"%s\"" % (key[7:], value)
  elif isexport(key):
    return "export %s=\"%s\"" % (key[7:], value)
  else:
    return "%s=\"%s\"" % (key, value)

if len(sys.argv) == 1:
  printerr("Usage: parseprofile.py <profiles.dat> [profile] [OPTIONS|SETTINGS]")
  sys.exit(1)

filename = sys.argv[1]

# Dump the raw data after any expansions/substitutions
if len(sys.argv) == 2:
  config = MyConfig(filename, debug=True)
  sys.exit(0)

profile  = sys.argv[2]

wantoptions = (sys.argv[3].upper() == "OPTIONS") if len(sys.argv) == 4 else False

settings = MyConfig(filename, debug=False).getprofile(profile)

for key, value in settings:
  if key.startswith("#"):
    print(key)
  elif (isoption(key) == wantoptions):
    print(translate(key, value))
  elif (isexport(key) == wantoptions):
    print(translate(key, value))

if (wantoptions == False):
  keyhist={}
  for key, value in settings:
    if (isoption(key) == False and isexport(key) == False and key not in keyhist and not key.startswith("#")):
      keyhist[key] = True
      print("_profilekeys[\"%s\"]=1" % key)
