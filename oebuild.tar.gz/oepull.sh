#!/bin/bash

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

_lock_build_repo

CONTROL=${BUILD_ENV_CONTROL}
PATCHES=${BUILD_RESOURCES}/build
PATCHES_PRIV=${BUILD_RESOURCES}/private
PCACHE=${BIN}/.pcache
CLEAN_PACKAGES=
USEGITAPPLY=N
REMOVEFILE_ERR=

IGNORE_FILES="^.. target$|^.. .ccache"

cd ${BUILD_REPO_PATH}

# Run an arbitrary command
runCommand()
{
  local cmd
  cmd="$(preprocessarg "${1}")"
  echo "${TXCYAN}Executing command: [${cmd}]${TXRESET}"
  # use -e to expand any embedded codes, eg. \041 for exclamation mark etc.
  eval "$(echo -e "${cmd}")" || die "ERROR: runCommand failed [${cmd}]"
}

# Restore project files if modified to avoid a merge conflict.
# This may not be a tracked file, in which case remove them.
restore_project()
{
  local status filename

  while read -r status filename; do
    [ "${filename}" == "target" ] && continue

    ignore_file "${filename}" && continue

    if [ "${status}" == "D" -o "${status}" == "M" -o "${status}" == "T" ]; then
      git checkout -- "${filename}" 2>/dev/null
    else
      rm -fr "${filename}"
    fi
  done <<< "$(git status --short --untracked-files=all --porcelain | ${TGREP} -vE "${IGNORE_FILES}")"
}

# Restore a deleted tracked file
restorefile()
{
  [ -z "${1}" ] && return

  ignore_file "${1}" && return

  echo "Restoring: ${1}"
  git checkout -- "${1}" || die 1 "git error: Unable to restore deleted file [${1}]"
  cleanpackage "${1}"
  return 0
}

# Remove only the specified file or directory. Log a warning if missing.
removefile()
{
  local filename="${1}" isoptional="${2:-N}" force="${3:-N}" errmsg

  [ -z "${1}" ] && return

  #Expand any embedded parameters, eg. ${PROJECT}
  filename="$(preprocessarg "${filename}")"

  # Ignore file if in ignore file, unless we're force removing these files
  if [ "${force}" == "N" ]; then
    ignore_file "${filename}" && return
  fi

  if [ -d "${filename}" ]; then
    echo "Removing : ${filename}"
    rm -fr "${filename}"
    cleanpackage "${filename}"
  elif [ -f "${filename}" ]; then
    echo "Removing : ${filename}"
    rm -f "${filename}"
    cleanpackage "${filename}"
  elif [ "${isoptional}" != "Y" ]; then
    errmsg="Removing : ${filename} ${TXYELLOW}** Does not exist, no longer required in ${CONTROL}? **${TXRESET}"
    echo "${errmsg}"
    REMOVEFILE_ERR="${REMOVEFILE_ERR}\n${errmsg}"
  fi
}

downloadFile()
{
  local url="${1}" filename="${2}" try result authentication error

  if [[ "${url,,}" =~ ^http.*github.com/ ]] || \
     [[ "${url,,}" =~ ^http.*githubusercontent.com/ ]]; then
    authentication="${AUTHENTICATION}"
  fi

  echo "${TXCYAN}Downloading File: ${url} => ${filename}${TXRESET}"
  mkdir -p "$(dirname ${filename})"

  webrequest "${url}" "${filename}" "${authentication}" "Y"
}

# Download a file, with optional github authentication
webrequest()
{
  local url="${1}" filename="${2:--}" authentication="${3}" isfatal22="${4:-Y}" result=0 error
  local redacted attempt=0 retries=30 waitsecs=1
  local insecure
  
  [ -n "${CURL_INSECURE}" ] && insecure="--insecure "

  [ "${REDACTPW}" != "N" ] && redacted="${authentication/:*/:<redacted>}" || redacted="${authentication}"

  # Getting strange error 1 (CURLE_UNSUPPORTED_PROTOCOL) and 35 (CURLE_SSL_CONNECT_ERROR) errors - retry several times
  # If error is 22 but no filename, then not fatal as we're just testing merge/unmerge status
  while [ ${attempt} -lt ${retries} ]; do
    attempt=$((attempt + 1))
    if [ ${attempt} -gt 1 ]; then
      echo "${error} - retrying curl request in ${waitsecs} seconds..." >&2
      sleep ${waitsecs}
    fi

    [ "${VERBOSE}" == "Y" ] && echo "DEBUG: curl -sfL -S ${insecure}${redacted} --connect-timeout 30 --retry 6 \"${url}\" -o \"${filename}\"" >&2
    error="$(curl -sfL -S ${insecure}${authentication} --connect-timeout 30 --retry 6 "${url}" -o "${filename}" 2>&1)" && return 0 || result=$?
    [ "${VERBOSE}" == "Y" ] && echo "DEBUG: ${error}" >&2

    [ ${result} -eq 22 -a "${isfatal22}" == "N" ] && return ${result}
    [ ${result} -eq 22 -a "${isfatal22}" == "Y" ] && break
  done
  die 1 "\nERROR ${error} (url: ${url})"
}

# If file or directory is present in milhouse.ignore then ignore the file/directory
ignore_file()
{
  if [ -f ${BUILD_REPO_PATH}/milhouse.ignore ]; then
    [ "${1}" == "milhouse.ignore" ] && return 0
    ${TGREP} -E "^${1}$" ${BUILD_REPO_PATH}/milhouse.ignore >/dev/null && return 0
    [ ! -d "${1}" ] && ${TGREP} -E "^$(dirname "${1}")$" ${BUILD_REPO_PATH}/milhouse.ignore >/dev/null && return 0
  fi

  return 1
}

# Delete a file from a directory, logging deletion if it is a tracked file (not interested in
# untracked files as there are usually too many).
# Also delete any untracked directories prior to removal of file.
# Do nothing if file or directory found in milhouse.ignore file - useful to prevent new project
# directories from being wiped out.
delete_dir_file()
{
  [ -z "${1}" ] && return
  [[ ${1} =~ ^.ccache ]] && return

  delete_untracked_dirs "${1}"

  ignore_file "${1}" && return

  if [ -f "${1}" ]; then
    git ls-files --error-unmatch "${1}" &>/dev/null && echo "Deleting : ${1}"
    rm -fr "${1}"
  fi
  cleanpackage "${1}"
}

# Delete untracked directory for a file, and continue deleting all untracked parent directories.
delete_untracked_dirs()
{
  local parent="${1}"

  while [ : ]; do
    ignore_file "${parent}" && return

    parent="$(dirname ${parent})"
    [ ! -d "${parent}" ] && break

    git ls-files --error-unmatch "${parent}" &>/dev/null && break
    echo "Deleting : ${parent}"
    rm -fr "${parent}"
  done
}

# For any modified/restored/deleted file in a package, clean that package...
cleanpackage()
{
  local array filepath dirs len root class subclass parent grandparent filename package p1 p2 path

  [ -z "$1" ] && return

  # Remove any leading ./
  [ "${1:0:2}" == "./" ] && filepath="${1:2}" || filepath="${1}"

  # Split path into array of directories
  dirs=(${filepath//\// })
  len=$((${#dirs[@]} - 1))
  root="${dirs[0]}"
  class="${dirs[1]}"
  subclass="${dirs[2]}"

  [ ${len} -ge 1 ] && parent="${dirs[$((len - 1))]}"
  [ ${len} -ge 2 ] && grandparent="${dirs[$((len - 2))]}"
  filename="${dirs[${len}]}"
  package=

  [ "${class}" == "virtual" ] && return

  if [ "${root}" == "packages" -a "${filename}" == "package.mk" ]; then
    package="${parent}"
  elif [ "${root}" == "packages" -a "${parent}" == "patches" ]; then
    package="${grandparent}"
  elif [ "${root}" == "projects" -a "${grandparent}" == "patches" ]; then
    package="${parent}"
  elif [ "${class}" == "linux" -o "${parent}" == "linux" ]; then
    package="linux"
  elif [ "${subclass}" == "devices" -a "${root}" == "projects" ]; then
    if [ ${len} -gt 4 ]; then
      package="${parent}"
    else
      package=""
    fi
  elif [ "${root}" == "projects" -a ${len} -gt 3 ]; then
    [ "${subclass}" == "filesystem" ] && package="" || package="${parent}"
  elif [ "${root}" == "packages" ]; then
    package=
    p1=${len}
    while [ ${p1} -gt 0 ]; do
      p2=0
      path=
      while [ ${p2} -lt ${p1} ]; do
        path+="${dirs[${p2}]}/"
        p2=$((p2 + 1))
      done
      if [ -f ${path}/package.mk ]; then
        package=$(basename ${path})
        break
      fi
      p1=$((p1 - 1))
    done
    [ -z "${package}" ] && package="${dirs[2]}"
    [ "${package}" == "patches" ] && package="${class}"
  fi

  addtaintedpackage "${package}"
}

addtaintedpackage()
{
  local package="${1}"
  if [ -n "${package}" ]; then
    for item in ${CLEAN_PACKAGES}; do
      [ "${item}" == "${package}" ] && return
    done
    CLEAN_PACKAGES="${CLEAN_PACKAGES} ${package}"
  fi
}

packageclean()
{
  local profile result=0

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    # Reload profile, re-initialising any project-based options
    loadconfig reload >/dev/null
    _packageclean --sync
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} N _packageclean_for_this_oe_path "${BUILD_REPO_PATH}" || die 1
    done
    loadconfig reload
  fi
  return ${result}
}

_packageclean_for_this_oe_path()
{
  [ "${BUILD_REPO_PATH}" == "${1}" ] && _packageclean --sync || true
}

_packageclean()
{
  local deferred_file="$(gettmpdir)/deferred_clean.dat"

  rm -f ${deferred_file}

  [ -n "$1" ] && addtaintedpackage "$1"
  if [ "${OPT_DEFERRED_CLEAN}" == "Y" ]; then
    echo "${CLEAN_PACKAGES}" >${deferred_file}
  elif [ -n "${CLEAN_PACKAGES}" -a -x ${BIN}/clean.sh ]; then
    ${BIN}/clean.sh ${CLEAN_PACKAGES}
    echo
  fi
  CLEAN_PACKAGES=
}

getpatchfile()
{
  local filename="${1}" cachename fqname action url apiurl fields merge_unmerge
  local authentication isgithub=N pull_compare=

  FQNPATCH=

  [ -d ${PCACHE} ] || mkdir ${PCACHE}

  rm -f ${TMPCACHE}

  if [ -n "$(echo "${filename}" | ${TGREP} "^http")" ]; then
    fields=(${filename//\// })

    # If it's a github url (patch-diff.githubusercontent.com, githubusercontent.com or github.com but not a gist)...
    if [ "${fields[1]/github/}" != "${fields[1]}" -a "${fields[1]}" != "gist.githubusercontent.com" ]; then
      isgithub=Y
      [ -n "$(echo "${filename}" | ${TGREP} -E "/pull/[0-9]*$")" ] && action="pull request" || action="commit"
    else
      action="patch"
    fi

    cachename="${PCACHE}/oepull#$(echo "${filename}" | sed 's/[^a-zA-Z0-9]/_/g')"

    if [ -s "${cachename}" ]; then
      echo "${TXCYAN}Using cached ${action}: ${filename}${TXRESET}"
    else
      # Append ".patch" to github urls, if required
      if [ "${isgithub}" == "Y" ]; then
        authentication="${AUTHENTICATION}"
        if [ "${fields[1]}" == "raw.githubusercontent.com" ]; then
          url="${filename}"
          pullcompare="commit"
          [[ ${fields[4]} =~ ^[0-9a-f]{40}$ ]] || cachename="${TMPCACHE}" # Only cache versioned raw content
        elif [ "${fields[1]}" == "gist.githubusercontent.com" ]; then
          url="${filename}"
          action="patch"
        elif [ "${fields[2]}" == "raw" ]; then
          url="${filename%.patch}.patch"
          apiurl="https://api.github.com/repos/${fields[3]}/${fields[4]}/${fields[5]}s/${fields[6]%.patch}"
          pullcompare="${fields[5]}"
        elif [ "${fields[1]}" == "github.com" -a "${fields[4]}" == "pull"  -a "${fields[6]}" == "commits" ]; then
          # specific commit in a pull request, eg. https://github.com/LibreELEC/LibreELEC.tv/pull/449/commits/f40d475a01b17b257ecca1450dc27bf76bde3385
          url="${fields[0]}//${fields[1]}/${fields[2]}/${fields[3]}/commit/${fields[7]%.patch}.patch"
          pullcompare="commit"
        else
          url="${filename%.patch}.patch"
          apiurl="https://api.github.com/repos/${fields[2]}/${fields[3]}/${fields[4]}s/${fields[5]%.patch}"
          pullcompare="${fields[4]}"
        fi

        # Unmerged pull requests should not be cached as the commits may change from one build to the next
        if [ "${pullcompare}" == "pull" ]; then
          webrequest "${apiurl}/merge" "" "${authentication}" "N" && merge_unmerge="merged " || cachename="${TMPCACHE}" merge_unmerge="unmerged "
        elif [ "${pullcompare}" == "compare" ]; then
          action="comparison"
          cachename="${TMPCACHE}" # Do not cache comparisons
        fi
      # Convert formatted pastebin.com url to raw
      elif [ "${fields[1]}" == "pastebin.com" -a "${fields[2]//raw.php\?i=/}" == "${fields[2]}" ]; then
        url="${fields[1]}/raw.php?i=${fields[2]}"
      else
        url="${filename}"
      fi
      echo -n "${TXCYAN}Downloading ${merge_unmerge}${action}: ${url}... ${TXRESET}"
      webrequest "${url}" "${cachename}" "${authentication}" "Y"
      if [ $? -ne 0 -o ! -f "${cachename}" -o -n "$(${TGREP} '{"error":"Not Found"}' "${cachename}" 2>/dev/null)" ]; then
        echo "${TXRED}FAILED!${TXRESET}"
        rm -f "${cachename}"
        die 1 "Unable to download ${action}: ${url}"
      else
        echo "[OK]"
        ${TGREP} -qE '^GIT binary patch$' ${cachename} && echo -en "\n\n" >> ${cachename} || echo -en "\n" >> ${cachename}
      fi
    fi
    FQNPATCH="${filename}"
  else
    cachename="${filename}"
    [ -s "${cachename}" ] || cachename="${PATCHES_PRIV}/${filename}"
    [ -s "${cachename}" ] || cachename="${PATCHES}/${filename}"
    [ -s "${cachename}" ] || cachename="${cachename}.patch"
    if [ ! -s "${cachename}" ]; then
      echo "${TXYELLOW}Warning: Patch file not found - ignoring: ${cachename}${TXRESET}"
      return 1
    fi
    FQNPATCH="${cachename}"
  fi

  cp "${cachename}" "${PATCH}"

  return 0
}

revertPatch()
{
  local patch="${1}"
  local reverse offset pos

  reverse="$(interdiff "${patch}" /dev/null)"
  [ -n "${reverse}" ] || return 1

  echo "${reverse}" >${patch}

  # Reverse the order in which the patches appear within the file, so that they "undo"
  # any changes correctly
  rm -f "${patch}.tmp"
  pos=$(cat "${patch}" | wc -c)
  while read -r offset; do
    dd if="${patch}" bs=1 skip=${offset} count=$((pos - offset)) 2>/dev/null >>"${patch}.tmp"
    pos=${offset}
  done <<< "$(${TGREP} -bu "^reverted:$" "${patch}" | cut -d: -f1 | tac)"
  mv "${patch}.tmp" "${patch}"
}

# Save original files in an archived form if they don't already exist
applypatch()
{
  local isrevert="$1" patch="$2" fqnpatch="$3" filename="${4}" description="${5}"
  local msg del_ab="a" mod_ab="b" reverse isbinary=N ischmod=N isrename=N defchmod=0 allchmod=0
  local mailsplitdir numsplit

  [ -n "${description}" ] && description=" (${description})"

  if [ -n "${filename}" ]; then
    if [ "${isrevert}" == "N" ]; then
      echo "Installing patch: ${TXCYAN}${fqnpatch} => ${filename}${description}...${TXRESET}"
    else
      echo "Installing reverted patch: ${TXCYAN}${fqnpatch} => ${filename}${description}...${TXRESET}"
    fi
  elif [ "${isrevert}" == "Y" ]; then
    echo "Reverting patch: ${TXCYAN}${FQNPATCH}${description}...${TXRESET}"
  else
    echo "Applying patch: ${TXCYAN}${fqnpatch}${description}...${TXRESET}"
  fi

  if ${TGREP} -qE '^GIT binary patch$' ${patch}; then
    echo "${TXCYAN}** Binary patch detected **${TXRESET}"
    isbinary=Y
  fi

  # Switch to git apply if we're setting a file mode other than the default 644
  allchmod="$(${TGREP} -E '^^new file mode [0-9]*$' ${patch} | wc -l)"
  if [ ${allchmod} -ne 0 ]; then
    defchmod="$(${TGREP} -E '^^new file mode 100644$' ${patch} | wc -l)"
    if [ ${defchmod} -ne ${allchmod} ]; then
      echo "${TXCYAN}** File mode patch detected **${TXRESET}"
      ischmod=Y
    fi
  fi

  # Switch to git apply if we're renaming a file
  if ${TGREP} -qE '^rename from|rename to' ${patch}; then
    echo "${TXCYAN}** File rename patch detected - using mailsplit **${TXRESET}"
    isrename=Y
  fi

  if [ "${isrevert}" == "Y" ]; then
    [ ${isbinary} == Y ] && warn "${TXRED}WARNING: Unable to revert binary patches - binary patches will be missing! (${fqnpatch})${TXRESET}"
    revertPatch "${patch}" || die 1 "Patch reversion failed (${fqnpatch})"
    msg="REVERTED "
    del_ab="b"
    mod_ab="a"
  fi

  # If we've got a filename, just copy the patch rather than apply it now
  # This is useful when applying a patch that must be processed before existing
  # patches
  if [ -n "${filename}" ]; then
    mkdir -p $(dirname ${filename}) || die 1 "UNABLE TO CREATE PATCH DIRECTORY"
    cp ${patch} ${filename} || die 1 "UNABLE TO INSTALL PATCH"
  else
    # As we're actually applying a patch, clean the affected packages first
    # Clean package of any files to be deleted
    while read -r file; do
      cleanpackage ${file}
    done <<<"$(${TGREP} -B1 "^+++ /dev/null" ${patch} | ${TGREP} -E "^--- [^/ *][^/]*/" | cut -d/ -f2- | cut -d' ' -f1)"

    # Clean package of any files to be created/modified
    while read -r file; do
      cleanpackage ${file}
    done <<<"$(${TGREP} "^+++ [^/ *][^/]*/" ${patch} | cut -d/ -f2- | cut -d' ' -f1)"

    # Clean pacakge of any binary files to be created/modified
    while read -r file; do
      cleanpackage ${file}
    done <<<"$(${TGREP} -B3 "^GIT binary patch" ${patch} | awk '/^diff --git/ {print $4}' | cut -d/ -f2-)"

    if [ ${isrename} == Y ]; then
      mailsplitdir=$(mktemp -d)
      numsplit=$(git mailsplit -o${mailsplitdir} ${patch}) || die "${msg}PATCH FAILED TO MAILSPLIT (${fqnpatch})"
      echo "** Split ${filename:-${fqnpatch}} into ${numsplit} patch(es) **"
      git apply \
            -p 1 \
            --whitespace=nowarn \
            --directory=${PWD} \
            --verbose \
            --unsafe-paths \
            ${mailsplitdir}/* 2>&1 | tee ${TMPCACHE_OUT}
      rm -fr ${mailsplitdir}
      ${TGREP} -qE "^error:|^fatal:" ${TMPCACHE_OUT} && die 1 "${msg}PATCH FAILED TO APPLY AFTER MAILSPLIT (${fqnpatch})"
    elif [ ${USEGITAPPLY} == Y -o ${isbinary} == Y -o ${ischmod} == Y ]; then
      git apply \
            -p 1 \
            --whitespace=nowarn \
            --directory=${PWD} \
            --verbose \
            --unsafe-paths \
            ${patch} 2>&1 | tee ${TMPCACHE_OUT}
      ${TGREP} -qE "^error:|^fatal:" ${TMPCACHE_OUT} && die 1 "${msg}PATCH FAILED TO APPLY (${fqnpatch})"
    else
      patch --forward \
            --no-backup-if-mismatch \
            --reject-file=- \
            --batch \
            --strip=1 \
            --input=${patch} || die 1 "${msg}PATCH FAILED TO APPLY (${fqnpatch})"
    fi
  fi
  rm -f ${patch}
}

# Apply a patch file.
forwardPatch()
{
  local url="${1}" filename="${2}" description="${3}"
  url="$(preprocessarg "${url}")"
  getpatchfile "${url}" && applypatch "N" "${PATCH}" "${FQNPATCH}" "${filename}" "${description}"
  return 0
}

# Revert a patch file.
reversePatch()
{
  local url="${1}" filename="${2}" description="${3}"
  url="$(preprocessarg "${url}")"
  getpatchfile "${url}" && applypatch "Y" "${PATCH}" "${FQNPATCH}" "${filename}" "${description}"
  return 0
}

# Disable a package by setting PKG_ARCH to "None"
disablePackage()
{
  local pdir
  pdir="$(preprocessarg "${1}")"
  if [ -d "${pdir}" ]; then
    if [ -f "${pdir}/package.mk" ]; then
      cleanpackage "${pdir}/package.mk"
      sed -i 's/^PKG_ARCH=.*/PKG_ARCH="None"/' "${pdir}/package.mk"
    fi
  fi
}

enableAddon()
{
  local values="$1"
  local value
  local options_file=packages/virtual/mediacenter/package.mk

  for value in ${values//,/ }; do
    echo "${TXCYAN}Enabling Addon [${value}] in ${options_file}${TXRESET}"
    sed -i "s/^  _ADDONS_${value}=.*/  _ADDONS_${value}=yes/" "${options_file}"
  done
}

disableAddon()
{
  local values="$1"
  local value
  local options_file=packages/virtual/mediacenter/package.mk

  for value in ${values//,/ }; do
    echo "${TXCYAN}Disabling Addon [${value}] in ${options_file}${TXRESET}"
    sed -i "s/^  _ADDONS_${value}=.*/  _ADDONS_${value}=no/" "${options_file}"
  done
}


# eg. insertOption RPi,Generic ADDITIONAL_DRIVERS RTL8192DU,RTL8192EU
insertOption()
{
  local projects="$1" option="$2" values="$3"
  local project_device project device value options_file

  for project_device in ${projects//,/ }; do
    if [[ $project_device} =~ .*\..* ]]; then
      project="${project_device%.*}"
      device="${project_device#*.}"
    else
      project="${project_device}"
      device=
    fi
    for value in ${values//,/ }; do
      if [ -n "${device}" ]; then
        options_file="projects/${project}/devices/${device}/options"
        if [ -f "${options_file}" ]; then
          echo "${TXCYAN}Adding ${option} [${value}] to project/device ${project} in ${options_file}/${device}${TXRESET}"
          echo "    ${option}=\"\${${option}} ${value}\" #Add this option" >> "${options_file}"
        else
          echo "${TXCYAN}Adding ${option} [${value}] to project/device ${project}/${device} in ${options_file}: ${TXYELLOW}NOT FOUND${TXRESET}"
        fi
      else
        options_file="projects/${project}/options"
        if [ -f "${options_file}" ]; then
          echo "${TXCYAN}Adding ${option} [${value}] to project ${project} in ${options_file}${TXRESET}"
          echo "    ${option}=\"\${${option}} ${value}\" #Add this option" >> "${options_file}"
        else
          echo "${TXCYAN}Adding ${option} [${value}] to project ${project} in ${options_file}: ${TXYELLOW}NOT FOUND${TXRESET}"
        fi
      fi
    done
  done
}

# eg. removeOption RPi,Generic ADDITIONAL_DRIVERS RTL8192DU,RTL8192EU
removeOption()
{
  local projects="$1" option="$2" values="$3"
  local project_device project device value options_file

  for project_device in ${projects//,/ }; do
    if [[ $project_device} =~ .*\..* ]]; then
      project="${project_device%.*}"
      device="${project_device#*.}"
    else
      project="${project_device}"
      device=
    fi
    for value in ${values//,/ }; do
      if [ -n "${device}" ]; then
        options_file="projects/${project}/devices/${device}/options"
        if [ -f "${options_file}" ]; then
          echo "${TXCYAN}Removing ${option} [${value}] from project/device ${project}/${device} in ${options_file}${TXRESET}"
          echo "    ${option}=\" \${${option}} \"; ${option}=\"\${${option}/ ${value} / }\"; [ \${#${option}} -gt 1 ] && ${option}=\"\${${option}:1:-1}\" # Drop this option" >> "${options_file}"
        else
          echo "${TXCYAN}Removing ${option} [${value}] from project/device ${project}/${device} in ${options_file}: ${TXYELLOW}NOT FOUND${TXRESET}"
        fi
      else
        options_file="projects/${project}/options"
        if [ -f "${options_file}" ]; then
          echo "${TXCYAN}Removing ${option} [${value}] from project ${project} in ${options_file}${TXRESET}"
          echo "    ${option}=\" \${${option}} \"; ${option}=\"\${${option}/ ${value} / }\"; [ \${#${option}} -gt 1 ] && ${option}=\"\${${option}:1:-1}\" # Drop this option" >> "${options_file}"
        else
          echo "${TXCYAN}Removing ${option} [${value}] from project ${project} in ${options_file}: ${TXYELLOW}NOT FOUND${TXRESET}"
        fi
      fi
    done
  done
}

# Switch git branch if required, checkout current branch, or do nothing
switchbranchrev()
{
  local oldbranch="${CUR_BRANCH}" hasbranch="${HAS_BRANCH}" newbranch="${NEW_BRANCH}"
  local switched=1

  if [ "${hasbranch}" == "Y" ]; then
    if [ -n "${newbranch}" ]; then
      git checkout "${newbranch}" || die 1 "git checkout error: branch ${newbranch} is not valid"
    else
      git checkout || die 1 "git checkout error"
    fi
    switched=0
  fi

  resetrev

  return ${switched}
}

# Reset HEAD to specified rev, if required
resetrev()
{
  local git_name="${BUILD_TYPE_REPO_NAME}"
  local branchrev="$(getbuildbranchrevfromprofile "${BUILD_REPO_PATH}" "${git_name}" "${BUILD_ENV_BRANCHES}")"
  local curbranch="$(getcurrentbranch "${git_name}")"

  if [ -n "${branchrev}" -a "${branchrev}" != "HEAD"  ]; then
    if [ "${branchrev}" != "$(getcurrentbranch "${BUILD_REPO_PATH}")" ]; then
      printf "${TXMAGENTA}Resetting repo [%-15s], [branch=%s, rev=%s]${TXRESET}\n" "${git_name}" "${curbranch}" "$(getshortrev "${branchrev}")"
      # If it fails, do a fetch and try again
      if ! git reset --hard "${branchrev}" &>/dev/null; then
        echo "Unknown rev for repo ${git_name} - performing 'git fetch' and trying again..."
        git fetch
        git reset --hard "${branchrev}" >/dev/null || die 1 "Failure resetting repo [${git_name}], rev [${branchrev}]"
      fi
    fi
    OPT_PULL=N
  fi
  return 0
}

# Preprocess argument.
# Read the specified filename (arg) when delimited by @@/@@, returning contents of file.
# Substitute ${HOME}/${BIN} if necessary. filename must not include spaces.
preprocessarg()
{
  local arg="${1}"
  if [[ "${arg}" =~ @@.*@@ ]]; then
    arg="${arg/@@/}"
    arg="${arg%@@}"
    arg="${arg//\$\{HOME\}/${HOME}}"
    arg="${arg//\$\{BIN\}/${BIN}}"
    if [ -n "${arg}" -a -f "${arg}" ]; then
      echo "${TXCYAN}Preprocessing: ${arg}${TXRESET}" >&2
      arg="$(cat "${arg}")"
    fi
  fi
#  eval echo "${arg:-${1}}"
  echo "${arg:-${1}}"
  return 0
}

# Process the control file, applying various modifications to the build environment
processcontrolfile()
{
  local l fields txtdescription txtfield filter target linenum
  local runcommand filename url project option value

  [ -f "${CONTROL}" ] || return

  delprojectoptionsfix #Remove fix from current options file

  linenum=0
  while read -r l; do
    linenum=$((linenum + 1))
    [ -z "${l}" ] && continue
    [[ ${l} =~ ^# ]] && continue

    fields=(${l})
    filter=0
    txtfield=2
    if [ "${fields[0]:0:1}" == "=" ]; then
      findinlist "${fields[0]:1}" "${OPT_FILTER}" && fields=(${fields[@]/${fields[0]}}) || continue
      filter=1
    fi

    runcommand=
    filename=
    url=
    project=
    option=
    value=

    case "${fields[0],,}" in
      runcommand)
        runcommand="$(trim "$(echo "${l}" | cut -d' ' -f$((2 + filter))- | sed 's/^[[:space:]]*#//')")";;
      insertoption|removeoption)
        project="$(trim "$(echo "${l}" | tr -s ' ' | cut -d' ' -f$((2 + filter))- | sed 's/^[[:space:]]*#//' | cut -d' ' -f1)")"
        option="$(trim "$(echo "${l}" | tr -s ' ' | cut -d' ' -f$((2 + filter))- | sed 's/^[[:space:]]*#//' | cut -d' ' -f2)")"
        value="$(trim "$(echo "${l}" | tr -s ' ' | cut -d' ' -f$((2 + filter))- | sed 's/^[[:space:]]*#//' | cut -d' ' -f3- | sed 's/[[:space:]]*#.*//')")"
        ;;
      enableaddon|disableaddon)
        value="$(trim "$(echo "${l}" | tr -s ' ' | cut -d' ' -f$((2 + filter))- | sed 's/^[[:space:]]*#//' | cut -d' ' -f1)")"
        ;;
      *)
        url="${fields[1]}";;
    esac

    if [ ${#fields[@]} -gt 2 -a "${fields[2]:0:1}" != "#" ]; then
      filename=${fields[2]}
      txtfield=$((txtfield+1))
    fi
    txtdescription="$(trim "$(echo "${l}" | tr -s ' ' | cut -d' ' -f$((1 + filter + txtfield))- | sed 's/^[[:space:]]*#//')")"

    case "${fields[0],,}" in
      runcommand)     runCommand     "${runcommand}";;
      forwardpatch)   forwardPatch   "${url}" "${filename}" "${txtdescription}";;
      reversepatch)   reversePatch   "${url}" "${filename}" "${txtdescription}";;
      downloadfile)   downloadFile   "${url}" "${filename}";;
      disablepackage) disablePackage "${url}" "${txtdescription}";;
      insertoption)   insertOption   "${project}" "${option}" "${value}";;
      removeoption)   removeOption   "${project}" "${option}" "${value}";;
      enableaddon)    enableAddon    "${value}";;
      disableaddon)   disableAddon   "${value}";;
      remove)         removefile     "${url}" "N" "Y";;
      removefile)     removefile     "${url}" "N" "Y";;
      stop | exit)    break;;
      *)              die 1 "${TXRED}ERROR: Invalid command \"${fields[0]}\" line ${linenum} [${l}]${TXRESET}";;
    esac
  done <<< "$(cat ${CONTROL} | tr -d '\r')"
  echo

  addprojectoptionsfix #Restore fix to current options file
}

# Apply analytics service
apply_analytics()
{
  if [ "${BUILD_ANALYTICS_APPLY,,}" != "no" ]; then
    if [ -f ${PATCHES}/milhouse_analytics.sh ]; then
      # Use non-cmake patch if we make_host() is present, otherwise we're building Kodi using only cmake
      grep -q "make_host()" packages/mediacenter/${OE_KODI_VER}/package.mk && forwardPatch add_service || forwardPatch add_service_cmake
      [ -f ${BUILD_REPO_PATH}/scripts/milhouse_curl ] && chmod +755 ${BUILD_REPO_PATH}/scripts/milhouse_curl
      cp ${PATCHES}/milhouse_analytics.sh packages/mediacenter/${OE_KODI_VER}/scripts/milhouse_analytics.sh
      sed -i "s ^URL_RPI=\"\"$ URL_RPI=\"${OE_DISTRO_ANALYTICS_RPI}\" " packages/mediacenter/${OE_KODI_VER}/scripts/milhouse_analytics.sh
      sed -i "s ^URL_X86=\"\"$ URL_X86=\"${OE_DISTRO_ANALYTICS_X86}\" " packages/mediacenter/${OE_KODI_VER}/scripts/milhouse_analytics.sh
      sed -i "s ^URL=\"\"$ URL=\"${OE_DISTRO_ANALYTICS}\" " packages/mediacenter/${OE_KODI_VER}/scripts/milhouse_analytics.sh
      cp ${PATCHES}/kodi-analytics.service packages/mediacenter/${OE_KODI_VER}/system.d
      chmod +x packages/mediacenter/${OE_KODI_VER}/scripts/milhouse_analytics.sh
      echo
    fi
  fi
}

# Remove fernetmenta patch and other stuff we don't need, or that breaks the build
remove_conflicts()
{
  [ "${BUILD_CONFLICTS_REMOVE,,}" != "no" ] || return 0

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    # Reload profile, re-initialising any project-based options
    loadconfig reload >/dev/null
    _remove_profile_conflicts
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} Y _remove_profile_conflicts || die 1
    done
    loadconfig reload >/dev/null
  fi

  return 0
}

_remove_profile_conflicts()
{
  local f

  [ -n "${BUILD_CONFLICTS}" ] || return 0

  for f in ${BUILD_CONFLICTS//,/ }; do
    removefile "${f}" "Y" "Y"
  done
}

applymodifications()
{
  # Reload profile, re-initialising any project-based options
  loadconfig reload >/dev/null

  processcontrolfile
  apply_analytics
  remove_conflicts

  # Output a summary of failed file removals, if there have been any
  [ -n "${REMOVEFILE_ERR}" ] && echo -e "${REMOVEFILE_ERR:2}"

  echo

  # Clean packages in build directory that are now out of date
  [ "${OPT_PATCH_ONLY}" == "N" ] && packageclean
}

# Reset repo to "clean" state
resetrepo()
{
  # Restore "deleted" files so that they can be
  # fetched without any problem, then "deleted" again
  while read -r f; do
    restorefile "${f}"
  done < "${DTMP}"

  # Restore original files so that they can be
  # fetched without any problem, then patched again
  # with custom modifications
  while read -r f; do
    restorefile "${f}"
  done < "${MTMP}"

  # Remove untracked files (remove entire directory if the directory is untracked)
  while read -r f; do
    delete_dir_file "${f}"
  done < "${UTMP}"
  echo

  # Restore any possibly modified project files in case of subsequent merge conflict
  restore_project

  # Cleanup junk
  rm -f .fakeroot.*
}

# Pull updates from upstream repo
updaterepo()
{
  git fetch || die "git fetch error"
  git diff --name-only origin/${NEW_BRANCH} > ${CHANGES} || die "git diff error"
  git pull || die "git pull error"

  # Add modified packages to clean...
  while read -r package; do
    ignore_file "${package}" && continue
    cleanpackage "${package}"
  done <<< "$(${TGREP} "^packages/" ${CHANGES})"
}

stash_env_config()
{
  cp -P ${BUILD_ENV_CONTROL} ${ENV_CONFIG_DIR}
  [ -f ${BIN}/profiles.dat ] && cp ${BIN}/profiles.dat ${ENV_CONFIG_DIR}
}

usage()
{
  cat <<EOF
Usage: $(basename $0) [-c] [-U] [p] [-D] [-b [branch]] [-C|-A filter]* [-N] [-v]
    -c  Clean local repository, don't apply modifications
    -U  Don't pull updates from remote repo
    -p  Patch only, don't clean packages
    -D  Defer cleaning of build directory - write dirty packages to deferred_clean.dat
    -b  Switch branch and exit (before applying modifications)
    -C  Filters to be used when selecting modifications
    -A  Additional filters to be used when selecting modifications
    -N  Don't send notifications
    -v  Verbose/debug output
EOF
}

TMPDIR="$(gettmpdirp oepull clean)" && trap "rm -fr ${TMPDIR}" EXIT || die 1 "Can't make temp directory"
MTMP="${TMPDIR}/modified.tmp"
DTMP="${TMPDIR}/deleted.tmp"
UTMP="${TMPDIR}/untracked.tmp"
CHANGES="${TMPDIR}/changes.tmp"
PATCH="${TMPDIR}/prpatch.tmp"
REVERTED="${TMPDIR}/reverted.patch"
TMPCACHE="${TMPDIR}/pull.cache"
TMPCACHE_OUT="${TMPDIR}/pull.cache.out"

ENV_CONFIG_DIR=$(gettmpdir .config clean)

OPT_CLEAN=N
OPT_PULL=Y
OPT_PATCH_ONLY=N
OPT_DEFERRED_CLEAN=N
CUR_BRANCH="$(getcurrentbranch)"
NEW_BRANCH=
HAS_BRANCH=N
OPT_FILTER=
ADD_FILTER=
NOTIFY=Y
VERBOSE=N

GOTOPTS=N
while getopts ":hcUpDb:C:A:Nv" opt; do
  GOTOPTS=Y
  # Allow -b with no argument to confirm current branch (and exit)
  [ "${opt}" == ":" -a "${OPTARG}" == "b" ] && opt="${OPTARG}" && OPTARG="$(getbuildbranch "." ${BUILD_TYPE_REPO_NAME})"
  case ${opt} in
    c)  OPT_CLEAN=Y;;
    U)  OPT_PULL=N;;
    p)  OPT_PATCH_ONLY=Y;;
    D)  OPT_DEFERRED_CLEAN=Y;;
    b)  HAS_BRANCH=Y; NEW_BRANCH=${OPTARG};;
    C)  [ -z "${OPT_FILTER}" ] && OPT_FILTER="${OPTARG}" || OPT_FILTER="${OPT_FILTER}, ${OPTARG}";;
    A)  [ -z "${ADD_FILTER}" ] && ADD_FILTER="${OPTARG}" || ADD_FILTER="${ADD_FILTER}, ${OPTARG}";;
    N)  NOTIFY=N; disable_notify;;
    v)  VERBOSE=Y;;
    h)  usage && exit 0;;
    \?) usage && die 1 "ERROR: Unknown argument [-${OPTARG}]";;
  esac
done

[ -f "${CONTROL}" ] || die 1 "ERROR: Control file [${CONTROL}] not found"

# Use filter from profile if available
[ -z "${OPT_FILTER}" ] && OPT_FILTER="${BUILD_ENV_FILTERS}"
[ -n "${ADD_FILTER}" ] && OPT_FILTER="${OPT_FILTER} ${ADD_FILTER}"

[ "$*" != "" -a ${GOTOPTS} == N ] && usage && die 1 "Error: args must be prefixed with a hyphen/dash"

# Append filter to the default filter if prefixed with "+"
DEF_FILTER="$(${TGREP} -Ei "^defaultFilter" ${CONTROL} | sed 's/^\w*\ *//')"
if [ -z "${OPT_FILTER}" ]; then
  OPT_FILTER="${DEF_FILTER}"
elif [ "${OPT_FILTER:0:1}" == "+" ]; then
  [ -n "${DEF_FILTER}" ] && OPT_FILTER="${DEF_FILTER} ${OPT_FILTER:1}" || OPT_FILTER="${OPT_FILTER:1}"
fi
OPT_FILTER="$(echo "${OPT_FILTER}" | sed 's/,/ /g' | tr -s ' ' | sed 's/ /, /g')"

# Switch branch based on profile information, if available
[ -z "${NEW_BRANCH}" ] && NEW_BRANCH="$(getbuildbranch "." ${BUILD_TYPE_REPO_NAME})"
[ -z "${NEW_BRANCH}" ] && NEW_BRANCH="${CUR_BRANCH}"
[ ${HAS_BRANCH} == N -a "${NEW_BRANCH}" != "${CUR_BRANCH}" ] && HAS_BRANCH=Y

echo "CONFIG"
echo "======"
echo "Current branch  : ${CUR_BRANCH}"
echo "Required branch : ${NEW_BRANCH}"
echo "Using filter    : ${OPT_FILTER}"
echo

echo "Difference"
echo "=========="
git status -s | ${TGREP} -E "^ [DM]" | sort
echo

# Collect deleted, modified and untracked files
git status --short --untracked-files=no  --porcelain | ${TGREP} -E "^ D "   | cut -b4- >${DTMP}
git status --short --untracked-files=no  --porcelain | ${TGREP} -E "^ M "   | cut -b4- >${MTMP}
git status --short --untracked-files=all --porcelain | ${TGREP} -E "^\?\? " | ${TGREP} -vE "${IGNORE_FILES}" | cut -b4- >${UTMP}

# Reset repo to initial "clean" status
resetrepo

# Switch branch and rev, if required
switchbranchrev && exit

# Leave repo in it's "clean" state
[ ${OPT_CLEAN} == Y ] && exit

# Pull udpates from upstream (automatically disabled when selecting a specific rev)
[ ${OPT_PULL} == Y ] && updaterepo

# Apply custom modifications to build environment
applymodifications

# Stash environment config so they can be stored in the build
stash_env_config

echo "Difference"
echo "=========="
#git status --short --untracked-files=no --porcelain | ${TGREP} -E "^ [DM]" | sort
git status --short --untracked-files=all --porcelain | ${TGREP} -vE "${IGNORE_FILES}" | sort
echo

exit 0
