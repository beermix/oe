#!/bin/bash

# Get the PUSHOVER_APIKEY and PUSHOVER_USRKEY from ~/.git.conf
[ -z "${PUSHOVER_APIKEY}" -a -z "${PUSHOVER_USRKEY}" -a -f ~/.git.conf ] && source ~/.git.conf
[ -z "${PUSHOVER_APIKEY}" -o -z "${PUSHOVER_USRKEY}" ] && exit

#[ "${PUSHOVER_USRKEY}" == "uZkaoPjBJPmtyF2W2mYqkgAAStjg9z" ] && exit 0

PUSHOVERAPI='
from __future__ import print_function
import sys
if sys.version_info >= (3, 0):
  import http.client as httplib
  import urllib.parse as urllib
else:
  import httplib, urllib

params = { "token": sys.argv[1],
           "user": sys.argv[2],
           "timestamp": int(sys.argv[3]), 
           "priority": int(sys.argv[4]),
           "sound": sys.argv[5],
           "message": sys.argv[6]
           }

host = "api.pushover.net:443"
try:
  conn = httplib.HTTPSConnection(host, timeout=10)
  conn.request("POST", "/1/messages.json",
    urllib.urlencode(params), { "Content-type": "application/x-www-form-urlencoded" })
  conn.getresponse()
except Exception as e:
  print("ERROR: Unable to send to host %s. Reason: %s" % (host, (str(e))), file=sys.stderr)
'

#[ -z ${PUSHOVER_SOUND_ERR+x} ]    && SOUND_ERR=alien
[ -z ${PUSHOVER_SOUND_ERR+x} ]    && PUSHOVER_SOUND_ERR=siren
[ -z ${PUSHOVER_SOUND_ERR+x} ]    && PUSHOVER_SOUND_ERR=spacealarm
[ -z ${PUSHOVER_SOUND_SILENT+x} ] && PUSHOVER_SOUND_SILENT=none
[ -z ${PUSHOVER_SOUND_OK+x} ]     && PUSHOVER_SOUND_OK=
[ -z ${PUSHOVER_SOUND_OK1+x} ]    && PUSHOVER_SOUND_OK1=classical
[ -z ${PUSHOVER_SOUND_OK2+x} ]    && PUSHOVER_SOUND_OK2=magic

# Default priority
PRIORITY=0

# Pass name of a standard sound code, or a named sound, or "none" for silence, or nothing for default
if [ "${1}" != "SOUND_OK" -o -n "${SOUND_OK}" ]; then
  SOUND="PUSHOVER_$1"
  [ -z ${!SOUND+x} ] && SOUND=$1
  [ -z ${!SOUND+x} ] || SOUND=${!SOUND}
fi
SOUND="${SOUND,,}"
shift

# The message
MESSAGE="$@"

[ -n "${MESSAGE}" ] && python -c "${PUSHOVERAPI}" "${PUSHOVER_APIKEY}" "${PUSHOVER_USRKEY}" "$(date +%s)" "${PRIORITY}" "${SOUND}" "${MESSAGE}"
