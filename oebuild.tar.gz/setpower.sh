#!/bin/bash

source ./settings.sh

if [ "${1,,}" == "off" -o "${1}" == "0" ]; then
  applysettings "powermanagement.shutdowntime" "0"
elif [ "${1,,}" == "on" ]; then
  applysettings "powermanagement.shutdowntime" "15"
else
  applysettings "powermanagement.shutdowntime" "$@"
fi
