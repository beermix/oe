#!/bin/bash

#
# Interpret patches.dat and retrieve commits and pull requests from
# github.com and/or the local filesystem.
#
# As a default, commits will be automatically blacklisted against one or more of
# the following:
#    1) a static blacklist file (blacklist.dat)
#    2) a selection of standard OpenELEC patches
#    3) the entire upstream xbmc/kodi repository
#
# Commits such as pull requests will be split into individual commits and the
# individual patches matched against the available blacklists. Use "-S" to disable
# splitting and any subsequent blacklist matching.
#
# A cache of downloaded commits will be created in ./pcache. It will be purged of
# any patch not accessed for 14 days. Pull requests and non-sha (ie. blob) patches will
# always be downloaded and never cached as such patches can change as new commits are
# added and patches updated/squashed.
#
# Any commit can be reverted using interdiff by prefixing the sha field with the
# "-" symbol. This is a bit experimental, and may not always work but seems OK
# at the moment.
#
# Suggested operation:
#
#   ./lsPatches.sh -iq; ./getPatches.sh -b
#
#-----------------------------------------------------------------------
#
# Use ~/.git.conf for GitHub authentication and avoid rate limiting:
#
#     GIT_USERNAME="Yourgitusername"
#     GIT_PASSWORD="Yourgitpassword"
#
#-----------------------------------------------------------------------
#
# Use lsPatches.sh to generates patches.dat from ipatches.dat, or
# manually maintain patches.dat.
#
# Patch file format (ipatches.dat/patches.dat):
#
# [=patchcode] [?target] [!pkg] [@][-]sha1 description
#
# Note; ipatches.dat will be processed by lsPatches.sh and will generate patches.dat, the
# latter being processed by getPatches.dat.
#
# Lines prefixed with "=patchcode" will be matched against the prevailing patchcode. The
# default patchcode is specified by adding "DEFPATCHODE=<code>" to ipatches.dat. This
# can be overridden by the lsPatches.sh -C <code> argument. Only lines with a matching
# patchcode (or with no =patchcode) will be output to patches.dat. The patchcode used
# to generate patches.dat will be written at the top of the file as "#PATCHCODE=<code>".
#
# PATCHCODES are normally ANDed together, but items can be ORed and negated:
#   =master,rpi|x86,!wetek
# would be interpreted as: master AND (rpi OR x86) and NOT wetek
#
# A field prefixed by "?" will be interpreted as a target path where the patch will
# be written, the default path being ${PATCHDIR}
#
# A field prefixed by "!" will be interpreted as the pacakge name, the default being "kodi".
#
# where sha1 is pr####/oepr####, local filename (relative to MYPATCHES) or github path+sha.
# sha1 must not contain spaces. Description may contain spaces, and must be seperated from
# sha1 by at least one space.
#
# If sha1 is prefixed with "-" then the patches will be automatically reverted using interdiff.
#
# Prefixing sha1 with the "@" symbol is a legacy requirement and should no longer be used.
#
# A special token is "import". This is used by lsPatches.sh and should only be used in
# ipatches.dat. It allows entire branches of commits to be generated. Any argument supported
# by lsPatches.sh can be specified when the "import" token is used.
#
# Any line that is not an import will be written out "as-is" to patches.dat. Lines with
# mismatched patchcodes will be written out as comments.
#
# import examples:
#
# =nc3 import -o popcornmix -r xbmc -b newclock3
# =nc4 import -o popcornmix -r xbmc -b newclock4
#
# will (when the patchcode is nc3) generate all commits on the newclock3 branch of the
# xbmc repo owned by popcornmix. The default repo is xbmc, in which case this argument can be
# omitted.
#
# import -o raspberrypi -r linux -b rpi-3.16.y -c raspberrypi:62de88e8e65811010deac5375f8f0d8b14dc4d94 -p linux
#
# This import will generate a list of all commits from the rpi-3.16.y branch of the linux repo
# owned by raspberrypi, using the comparison raspberrypi:62de88e8e65811010deac5375f8f0d8b14dc4d94
# (ie. all commits since after 62de88e). Each generated commit will be prefixed with the package "!linux".
#
# Example ipatches.dat:
#
# DEFPATCHCODE=nc4
# import -o raspberrypi -r linux -b rpi-3.16.y -c raspberrypi:62de88e8e65811010deac5375f8f0d8b14dc4d94 -p linux
# =nc3 import -o popcornmix -b newclock3
# =nc4 import -o popcornmix -b newclock4
# PR5324    XBMC pull request
# OEPR1234  OpenELEC pull request
# =nc4 -popcornmix/xbmc/commit/f16a...e7d  
#
# Example ipatches.dat/patches.dat:
#
# spinner.patch  Local patch file
# popcornmix/xbmc/commit/b38a...b69  Github commit, output as package "xbmc"
# !linux raspberrypi/linux/commit/6a75...cf1  Linux commit, output as package "linux"
# popcornmix/xbmc/commit/f16a...e7d  
# xbianonpi/xbian-package-xbmc/blob/master/patches/CecStandbyRender.patch  Non-sha based patch, use raw "blob" file
# PR5324    XBMC pull request
# OEPR1234  OpenELEC pull request
# -PR5324   XBMC pull request that will be reverted
#
#-----------------------------------------------------------------------
#
# Blacklist file format (blacklist.dat):
#
# [prefix][=<filter>] sha description
#
# sha can be anything, as long as it doesn't contain spaces. It's not used
# as part of the matching process.
#
# There must be at least one space between sha and description. Commits
# will be matched against only the description, and matching will be
# exact, including any trailing whitespace.
#
# Blacklist prefixes:
#
#   #  Comment - ignore entry
#   +  Whitelist - include entry rather than blacklist
#   *  Suppress library warning
#   @  Token processing (tokens=<token1>=<value>;<token2>=<value>...
#   $  Apply tools patch, but don't apply de-tooled patch (aka partial detool - default is to blacklist both "parts")
#
# Any entry without a prefix will be interpreted as a blacklist item.
#

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

_lock_build_repo

UNIQUE_PATCH_CODE="NJM"

INPUT=${BUILD_PKG_PATCHES}

MYPATCHES=${BUILD_RESOURCES}/patches
BLACKLIST_STA=${BUILD_PKG_BWLIST}
PCACHE=${BIN}/.pcache
PCACHE_VERSION=1
BLACKLIST_DYN=$(gettmpdirp)/blacklist.dyn
BLACKLIST_GIT=$(gettmpdirp)/blacklist.git
BLACKLIST_STA_TMP=$(gettmpdirp)/$(basename ${BLACKLIST_STA}).tmp
TMP=$(gettmpdirp)/newpatch.patch
TMP_SPLIT_DIR=$(gettmpdirp split clean)
TMP_SPLIT=${TMP}.split
TMP_SKIN=${TMP}.skin
DETOOL_DIR=$(gettmpdirp detool clean)
DETOOL_WHITELIST=${DETOOL_DIR}/detooled.whitelist
FILTER_HASH=$(gettmpdirp filter clean)/filter.dat
DETOOLED=N
SPINNER='|/-\|/-\'

# Split skins if pre-PR1080. Do not split post-PR1080 as skins are now combined under kodi
[ -n "$(getoepkgoption kodi-theme-Estuary PKG_URL)" ] && SPLIT_SKINS=Y || SPLIT_SKINS=N

if command -v tput >/dev/null; then
  CLR_BLANKLINE="\r$(tput el)"
else
  CLR_BLANKLINE="\r                            \r"
fi

usage()
{
  cat <<EOF
Usage: $(basename $0) [-b] [-c] [-d] [-g] [-r] [-i] [-p] [-D] [-P] [-S] [-T dir] [-v|-vv|-vvv]

$(basename $0) options:
    -b   Show details of only blacklisted/whitelisted/reverted patches
    -c   Clean patches and exit
    -d   Disable dynamic blacklisting
    -g   Disable git blacklisting
    -r   Set PROJECT=RPi (default)
    -i   Set PROJECT=Generic
    -p   Purge .pcache
    -D   Do not de-tool patches - apply them as they are
    -P   Use profile as source of patches.dat
    -S   Disable patch splitting
    -T   Alternative target directory for downloaded patches
    -v   Verbose output
    -vv  Debug output
    -vvv Verbose + Debug output
    -h   This message
EOF
}

create_pcache()
{
  local vesionfile="${PCACHE}/.version"
  local pcache_version=0

  if [ -d ${PCACHE} ]; then
    # Purge the cache if it's not the latest version
    [ -f ${vesionfile} ] && pcache_version=$(cat ${vesionfile})
    if [ ${pcache_version} -ne ${PCACHE_VERSION} ]; then
      echo "Purging .pcache, version is out of date"
      PURGE=Y
    fi
  fi

  # Purge the commit cache if required
  [ "${PURGE}" == "Y" ] && rm -fr "${PCACHE}"

  # Create commit cache if not found
  [ -d ${PCACHE} ] || mkdir ${PCACHE}

  echo "${PCACHE_VERSION}" >${vesionfile}
}

findstaticblacklist()
{
  local WL_BL="${1}" detool="${2}" description="${3}"
  local line fields c char ftmp
  local islibwarn iswhitelist ispartialdetool

  while read -r line; do
    [ -z "${line}" ] && continue

    fields=(${line})

    istoken=N
    iswhitelist=N
    islibwarn=N
    ispartialdetool=N
    ftmp="${fields[0]}"
    for((c=0; c<${#ftmp}; c++)); do
      char="${ftmp:${c}:1}"
      case "${char}" in
        "@") istoken=Y; continue;;
        "+") iswhitelist=Y; continue;;
        "*") islibwarn=Y; continue;;
        "$") ispartialdetool=Y; continue;;
      esac
      fields[0]=${fields[0]:${c}}
      break
    done

    [ "${islibwarn}" == "Y" ] && continue
    [ "${istoken}" == "Y" ]   && continue
    [ "${WL_BL}" == "BLACKLIST" -a "${iswhitelist}" == "Y" ] && continue
    [ "${WL_BL}" == "WHITELIST" -a "${iswhitelist}" == "N" ] && continue
    [ "${ispartialdetool}" == "Y" -a "${detool}" == "N" ] && continue

    if [ "${fields[0]:0:1}" == "=" ]; then
      findinlist "${fields[0]:1}" "${BUILD_PKG_FILTERS,,}" || continue
    fi

    return 0
  done <<< "$(${TGREP} -F " ${description,,}#ANCHOR#" ${BLACKLIST_STA_TMP})"

  return 1
}

getToken()
{
  local token="${1}" description="${2}"
  local items line fields field t tname tvalue filter

  [ -z "${token}" -o -z "${description}" ] && return 0

  while read -r line; do
    [ -z "${line}" ] && continue
    fields=(${line})
    field=

    #@=<code> etc.
    if [ "${fields[0]:1:1}" == "=" ]; then
      findinlist "${fields[0]:2}" "${BUILD_PKG_FILTERS,,}" || continue
    fi

    for t in "${fields[@]}"; do
      if [[ "${t}" =~ ^tokens=.*$ ]]; then
        field="${t:7}"
        break
      fi
    done
    [ -n "${field}" ] || continue
    for t in ${field//;/ }; do
      tname="${t%=*}"
      tvalue="${t/*=/}"
      [ "${tname}" == "${token}" ] && echo "${tvalue}"
    done
    return 0
  done <<< "$(${TGREP} -F " ${description,,}#ANCHOR#" ${BLACKLIST_STA_TMP} | ${TGREP} -E "^@")"

  return 1
}

# Return 1 (description found in a blacklist) or 0 (not found)
check_blacklist()
{
  local desc="${1#\[PATCH*] }"
  local detool="${2}"
  local BLACKLISTED=
  local WHITELISTED=N
  local MATCHED=

  # Ignore any blacklisted description
  if [ -n "${desc}" ]; then
    if [ -z "${BLACKLISTED}" -a -f ${BLACKLIST_STA_TMP} ]; then
      findstaticblacklist BLACKLIST "${detool}" "${desc}" && BLACKLISTED=sta
    fi
    if [ -z "${BLACKLISTED}" -a -f ${BLACKLIST_DYN} ]; then
      MATCHED="$(${TGREP} -F " ${desc,,}#ANCHOR#" ${BLACKLIST_DYN})"
      if [ -n "${MATCHED}" ]; then
        BLACKLISTED=dyn
        MATCHED="$(echo "${MATCHED}" | head -1 | sed 's/.*#ANCHOR# //g')"
        MATCHED="${MATCHED/${BUILD_REPO_PATH}\//}"
      fi
    fi
    if [ -z "${BLACKLISTED}" -a -f ${BLACKLIST_GIT} ]; then
      [ $(${TGREP} -F "${PKG}#ANCHOR#${desc,,}#ANCHOR#" ${BLACKLIST_GIT} | wc -l) -ne 0 ] && BLACKLISTED=git
    fi

    #If we need to "unblacklist" something... prefix sha with "+"
    if [ -n "${BLACKLISTED}" -a -f ${BLACKLIST_STA_TMP} ]; then
      findstaticblacklist WHITELIST "${detool}" "${desc}" && WHITELISTED=Y
    fi
  fi

  if [ -n "${BLACKLISTED}" ]; then
    local pr_id ctype="."
    [ "${detool}" == "Y" ] && ctype="$"
    [[ "${SHA1^^}" =~ PR[0-9]* || "${SHA1^^}" =~ OEPR[0-9]* ]] && pr_id=" ${SHA1}" || pr_id=
    if [ ${WHITELISTED} == Y ]; then
      [ ${VERBOSE} == Y -o ${SHOWBLACKLIST} == Y ] && printf "${CLR_BLANKLINE}%s\n" "WHITELIST${ctype}${BLACKLISTED}: [PATCH${pr_id}] ${desc}"
    else
      if [ -z "${MATCHED}" ]; then
        [ ${VERBOSE} == Y -o ${SHOWBLACKLIST} == Y ] && printf "${CLR_BLANKLINE}%s\n" "BLACKLIST${ctype}${BLACKLISTED}: [PATCH${pr_id}] ${desc}"
      else
        [ ${VERBOSE} == Y -o ${SHOWBLACKLIST} == Y ] && printf "${CLR_BLANKLINE}%s\n" "BLACKLIST${ctype}${BLACKLISTED}: [PATCH${pr_id}] ${desc} => ${MATCHED}"
      fi
      return 1
    fi
  fi

  return 0
}

inspect_patch()
{
  WARNING=
  [ -n "${DESC}" ] || return 0
  [ -f ${BLACKLIST_STA_TMP} ] || return 0

  #Check for any potential ffmpeg specific patches
  ${TGREP} -E "^[-+]{3,4} [^/]/lib/ffmpeg/.*" "$1" 1>/dev/null && WARNING="${WARNING}, ffmpeg"

  # warn, unless supressed
  if [ -n "${WARNING:2}" ]; then
    if [ $(${TGREP} -F " ${DESC,,}#ANCHOR#" ${BLACKLIST_STA_TMP} | ${TGREP} "^\*" | wc -l) == 0 ]; then
      if [ -f "${DETOOL_WHITELIST}" ]; then
        [ $(${TGREP} -F "#ANCHOR#${DESC,,}#ANCHOR#" "${DETOOL_WHITELIST}" | wc -l) != 0 ] && return 0
      fi
      [ ${VERBOSE} == Y -o ${SHOWBLACKLIST} == Y ] && echo "!LIB WARNING!: [PATCH] ${DESC} (WARNING: ${WARNING:2})"
    fi
  fi

  return 0
}

# Reverse patch. Use cached version if available.
# Prefix PR name with "-" to invert the PR, eg. -PR4008
revert_patch()
{
  local input="${1}" sha1="${2}"
  local cachename offset pos
  local a b c d k modes

  cachename="${PCACHE}/reverted#$(md5sum "${input}" | awk '{print $1}')@$(echo "${sha1}" | sed 's/[^a-zA-Z0-9]/_/g')"

  if [ -s "${cachename}" ]; then
    cp "${cachename}" "${input}"
  else
    if [ "${_IGNORE_RENAME}" != "Y" ] && grep -q "^rename from" "${input}"; then
      echo "ERROR: file rename detected in patch being reverted - this is not supported by GNU patch [${sha1}]"
      exit 1
    fi

    declare -A modes
    while read -r a b c d; do
      [ -n "${d}" ] && modes["${d}"]="${c}"
    done <<< "$(${TGREP} -E "^ delete mode" "${input}")"

    interdiff "${input}" /dev/null > "${input}.tmp"
    mv "${input}.tmp" "${input}"

    # Reverse the order in which the patches appear within the file, so that they "undo"
    # any changes correctly
    pos=$(cat "${input}" | wc -c)
    while read -r offset; do
      dd if="${input}" bs=1 skip=${offset} count=$((pos - offset)) 2>/dev/null >>"${input}.tmp"
      pos=${offset}
    done <<< "$(${TGREP} -bu "^reverted:$" "${input}" | cut -d: -f1 | tac)"

    # Generate create mode diff - fixup file permission modes on deleted files being reverted
    a=0
    for k in "${!modes[@]}"; do
      if [ "${modes[${k}]}" != "100644" ]; then
        a=$((a + 1))
        [ ${a} -eq 1 ] && echo "reverted:" >>"${input}.tmp"
        echo "diff --git a/${k} b/${k}" >>"${input}.tmp"
        echo "old mode 100644" >>"${input}.tmp"
        echo "new mode ${modes[${k}]}" >>"${input}.tmp"
      fi
    done

    mv "${input}.tmp" "${input}"
    cp "${input}" "${cachename}"
  fi
}

# Convert tools patches into a format suitable for the build repo
detool_patch()
{
  local description="${1}" oldpatch="${2}" newpatch="${2}.tmp" sha1="${3}" revert="${4}"
  local validpatch=N package filename fields prefix direction filenames=() issquash
  local tmpname infoname count=0 cadd cdel result

  [ -f "${oldpatch}" ] || return 1

  package="$(${TGREP} -E "^[\+-]{3} [^/].*/tools/depends/target/.*/[^/]*\..*" "${oldpatch}" | head -1)"
  [ -n "${package}" ] || return 1

  debuglog "DETOOLING PATCH(ES)..."

  filename="$(echo "${package}" | awk '{print $2}')"
  fields=(${filename//\// })

  package="$(translatepkg "${fields[4]}")"

  # Determine patching sequence - extract patches in same order
  if ${TGREP} -qE "^\+{3} .*/Makefile" "${oldpatch}"; then
    while IFS= read -r line; do
      if [[ ${line} =~ ^\+{3}\ .* ]]; then
        [[ ${line} =~ ^\+{3}\ .*/Makefile ]] && validpatch=Y || validpatch=N
      fi
      if [ ${validpatch} == Y ]; then
        if [[ ${line} =~ ^[\+-][:isspace:][^#]*.*[:isspace:]*patch\ -p.*\ \<\ .* ]]; then
          prefix="$(echo "${line}" | sed 's/.*patch -p\([0-9]*\) .*/\1/')"
          [ -n "${prefix}" ] || prefix=1
          filename="$(echo "${line}" | sed 's/.* < \(.*\)$/\1/')"
          filenames+=("${line:0:1} ${prefix} N $(basename "${filename}")")
        fi
      fi
    done < "${oldpatch}"
  fi

  # If no patch found, could it be a squashed patch (ie. just a patch, not Makefile + patch file)?
  if [ ${#filenames[@]} -eq 0 ]; then
    while read -r line; do
      if [[ ${line} =~ ^diff ]]; then
        filename="$(basename $(echo "${line}" | awk '{print $NF}'))"
        if [[ ${line} =~ ^diff\ .*/.*\.patch ]]; then
          validpatch=Y
        elif ${TGREP} -A1 "PACKAGE=\"${package}\"" ${DETOOL_DIR}/*.info 2>/dev/null | ${TGREP} "PATCHNAME=\"${filename}\"" >/dev/null; then
          validpatch=Y
        else
          validpatch=N
        fi
      fi
      if [ ${validpatch} == Y ]; then
        if [[ ${line} =~ ^\+{3}\ .*/.*\..* ]]; then
          filename="$(echo "${line}" | awk '{print $2}')"
          filenames+=("${line:0:1} 1 Y $(basename "${filename}")")
        fi
      fi
    done < "${oldpatch}"
  fi

  # No patches to extract and convert - process as an "ordinary" patch
  [ ${#filenames[@]} -ne 0 ] || return 1

  # If we're blacklisting only the de-tooled patch - process as an "ordinary" patch
  check_blacklist "${description}" "Y" || return 1

  mkdir -p ${DETOOL_DIR}/${package}

  for filename in "${filenames[@]}"; do
    direction="$(echo "${filename}" | awk '{ print $1 }')"
    prefix="$(echo "${filename}" | awk '{ print $2 }')"
    issquash="$(echo "${filename}" | awk '{ print $3 }')"
    filename="$(echo "${filename}" | awk '{ print $4 }')"

    detool_extract_patch "${oldpatch}" "${filename}" "${prefix}" "${issquash}" > "${newpatch}"

    if [ ! -f "${newpatch}" ]; then
      MSG="DETOOL ERROR : Unable to de-tool [${sha1}]"
      return 1
    fi

    # Try and match new patch file against an existing patch, in which case new patch
    # will be applied on top of the existing patch.
    tmpname="$(cd ${DETOOL_DIR}/${package}; ls [0-9][0-9][0-9][0-9]_${filename} 2>/dev/null)"
    if [ -z "${tmpname}" ]; then
      DETOOL_INDEX=$((DETOOL_INDEX + 1))
      tmpname="$(printf "%04d_%s" "${DETOOL_INDEX}" "${filename}")"
    fi

    infoname="${DETOOL_DIR}/$(echo "${package}/${tmpname}" | md5sum | awk '{ print $1 }').info"

    echo "SHA1=\"${sha1}\""          >> "${infoname}"
    echo "NAME=\"${NAME//\"/\\\"}\"" >> "${infoname}"
    echo "MSG=\"${MSG//\"/\\\"}\""   >> "${infoname}"
    echo "REVERT=\"${revert}\""      >> "${infoname}"
    echo "PACKAGE=\"${package}\""    >> "${infoname}"
    echo "PATCHNAME=\"${filename}\"" >> "${infoname}"
    echo "MSGS=\"\${MSGS}\${MSG}\t\"">> "${infoname}"
    echo "#ANCHOR#${NAME,,}#ANCHOR#" >> "${DETOOL_WHITELIST}"

    sed -i "s+^diff .*${filename}$+diff ${tmpname} ${tmpname}+" "${newpatch}"
    sed -i "s+^--- .*${filename}$+--- ${tmpname}+" "${newpatch}"
    sed -i "s+^\+\+\+ .*${filename}$+\+\+\+ ${tmpname}+" "${newpatch}"

    [ "${revert}" == "Y" ] && revert_patch "${newpatch}" "${sha1}"

    if ${TGREP} -qE '^GIT binary patch$' ${newpatch}; then
      git apply \
            -p 0 \
            --whitespace=nowarn \
            --directory=${DETOOL_DIR}/${package} \
            --unsafe-paths \
            ${newpatch} 2>&1 | \
            ${TGREP} -qE "^error:|^fatal:" && result=1 || result=0
    else
      patch -p0 -d ${DETOOL_DIR}/${package} -i "${newpatch}" >/dev/null && result=0 || result=1
    fi

    if [ ${result} -eq 0 ]; then
      count=$((count + 1))
      echo "GROUP=${count}" >> "${infoname}"
    else
      cadd=$(${TGREP} -E "^\+\+\+ .*" "${newpatch}" | wc -l)
      cdel=$(${TGREP} -E "^\+\+\+ /dev/null" "${newpatch}" | wc -l)
      # If the patch is only deleting stuff, silently ignore it
      [ ${cadd} -eq ${cdel} ] || echo "DETOOL WARNING: Unable to apply patch without error, ignoring [${filename}] (${description})"
      rm -f "${infoname}" ${DETOOL_DIR}/${package}/*.orig ${DETOOL_DIR}/${package}/*.rej
    fi
    rm -f "${newpatch}"
  done

  return 0
}

# Find the named patch in the patch file, and output it.
# Adjust prefix if required, so that the extracted patch is compatible with "patch -p1".
detool_extract_patch()
{
  local oldpatch="${1}" patchname="${2}" prefix="${3}" issquash="${4}"
  local foundpatch=N

  while IFS= read -r line; do
    if [[ ${line} =~ ^diff.* ]] ; then
      [[ ${line} =~ ^diff.*${patchname//./\\.}$ ]] && foundpatch=Y || foundpatch=N
    fi
    if [ ${foundpatch} == Y ]; then
      if [ -n "${prefix}" ]; then
        if [[ ${line} =~ ^\+diff.* ]] || [[ ${line} =~ ^\+---\ .* ]] || [[ ${line} =~ ^\+\+\+\+\ .* ]]; then
          line="$(detool_fixprefix "${line}" "${prefix}")"
        elif [ "${issquash}" == "Y" ]; then
          if [[ ${line} =~ ^\ diff.* ]] || [[ ${line} =~ ^\ ---\ .* ]] || [[ ${line} =~ ^\ \+\+\+\ .* ]]; then
            line="$(detool_fixprefix "${line}" 0)"
          fi
        fi
      fi
      echo "${line}"
    fi
  done < "${oldpatch}"
}

# Fix prefix to be comptaible with "patch -p1".
detool_fixprefix()
{
  local line="${1}" prefix="${2}"
  local item itemn newitem newline total last nexttolast c f

  if [ ${prefix} -eq 1 ]; then
    echo "${line}"
    return 0
  fi

  newline="${line}"

  itemn=0
  total="$(echo "${line}" | wc -w)"
  last=${total}
  nexttolast=$((last - 1))

  for item in ${line}; do
    itemn=$((itemn + 1))
    [ "${item}" == "/dev/null" ] && continue
    if [[ ${line} =~ ^[\ \+-]diff.*  ]]; then
      [ ${itemn} -lt ${nexttolast} ] && continue
    else
      [ ${itemn} -lt ${last} ] && continue
    fi
    if [ ${prefix} -eq 0 ]; then
      if [[ ${line} =~ ^[\ \+-]diff.* ]]; then
        [ ${itemn} -eq ${nexttolast} ] && newitem="/a" || newitem="/b"
      else
        [[ ${line} =~ ^[\ \+-]--- ]] && newitem="/a" || newitem="/b"
      fi
      # Don't change prefix if it already appears to be "a/" or "b/"
      [ "${item:0:2}" == "${newitem:1}/" ] && newitem=
    else
      newitem=
    fi
    c=1
    for f in ${item//\// }; do
      [ ${c} -eq 1 -o ${c} -gt ${prefix} ] && newitem="${newitem}/${f}"
      c=$((c + 1))
    done
    newline="${newline/ ${item}/ ${newitem:1}}"
  done
  echo "${newline}"
}

# Add a prefix (a/, b/) to the patch
addpatchprefix()
{
  local inputfile="${1}"
  local isgit hasprefix

  ${TGREP} --max-count=1 "^diff --git " "${inputfile}" >/dev/null && isgit=Y || isgit=N
  ${TGREP} --max-count=1 "^diff --git a/" "${inputfile}" >/dev/null && hasprefix=Y || hasprefix=N

  if [ "${isgit}" == "Y" -a "${hasprefix}" == "N" ]; then
    sed -i 's#diff --git \([^/].*\) \([^/].*\)#diff --git a/\1 b/\2#; s#^--- \([^/].*\)#--- a/\1#; s#^+++ \([^/].*\)#+++ b/\1#' "${inputfile}"
  elif [ "${isgit}" == "N" -a "${hasprefix}" == "N" ]; then
    sed -i 's#^--- \([^/].*\)#--- a/\1#; s#^+++ \([^/].*\)#+++ b/\1#' "${inputfile}"
  fi

  return 0
}

# Convert dvdplayer patch to VideoPlayer
fixvideoplayer()
{
  local inputfile="${1}"
  local pairs pold pnew

  # Fix filepaths/filenames
  pairs=()
  pairs+=("/dvdplayer/|/VideoPlayer/")
  pairs+=("/DVDPlayer.cpp|/VideoPlayer.cpp")
  pairs+=("/cores/VideoRenderers/DXVAHD.cpp|/cores/VideoPlayer/VideoRenderers/HwDecRender/DXVAHD.cpp")
  pairs+=("/cores/VideoRenderers/|/cores/VideoPlayer/VideoRenderers/")

  for prefix in "diff" "---" "+++"; do
    for pair in "${pairs[@]}"; do
      pold="${pair%|*}"
      pnew="${pair#*|}"
      [ "${prefix}" == "diff" ] && sed -i "s#^\(${prefix} .*\)${pold}\(.*\)${pold}\(.*\)#\1${pnew}\2${pnew}\3#" "${inputfile}" \
                                || sed -i "s#^\(${prefix} .*\)${pold}#\1${pnew}#" "${inputfile}"
    done
  done

  # Fix in-line comments
  pairs=()
  pairs+=(" dvdplayer | VideoPlayer ")
  pairs+=("dvdplayer,|VideoPlayer,")
  pairs+=("dvdplayer\.|VideoPlayer.")

  for pair in "${pairs[@]}"; do
    pold="${pair%|*}"
    pnew="${pair#*|}"
    sed -i "s#\(//.*\)${pold}#\1${pnew}#" "${inputfile}"
  done
}

# processtoken() function - temporarily disable detooling for the current patch
donotdetool()
{
  _CANDETOOL=N
}

nodetool()
{
  donotdetool
}

# processtoken() function - dummy "do nothing" function, token is handled by lsPatches.sh
ignoremergestatus()
{
  return 0
}

donotsplit()
{
  SPLIT=N
}

nosplit()
{
  donotsplit
}

# processtoken() function - ignore file renames during revert
ignorerename()
{
  _IGNORE_RENAME=Y
}

# Download a pull request, adding to cache if it is merged.
getpullrequest()
{
  local url="${1%.patch}" output="${2}" sha1="${3}"
  local fields=(${1//\// })
  local cachename webresponse

  [ "${PKG_SET}" == "N" ] && PKG=${fields[3]}

  cachename="${PCACHE}/pullrequest#$(echo "${url}" | sed 's/[^a-zA-Z0-9]/_/g')"

  if [ -s "${cachename}" ]; then
    cp "${cachename}" "${output}"
    NAME="${sha1}"
    MSG="Got patch (c): ${sha1}"
  else
    webresponse="$(webrequest "${url}.patch" "${output}" "%{http_code}" || rm -f "${output}")"
    # If forbidden (403), retry using Github API
    # If forbidden (404), doesn't exist, or repo might be private - retry using authenticated API
    if [ "${webresponse}" == "403" -o "${webresponse}" == "404" ]; then
      webrequest "$(rewrite_url4api "${url}")" "${output}" "" "Accept: application/vnd.github.v3.patch" || rm -f "${output}"
    fi

    if [ -f "${output}" ]; then
      NAME="${sha1}"
      MSG="Got patch (d): ${sha1}"

      # If the pull request is merged, we can cache it for next time...
      webrequest "$(rewrite_url4api "${url}")/merge" "" "" "Accept: application/vnd.github.v3.patch" && cp "${output}" "${cachename}"
    fi
  fi
}

rewrite_url4api()
{
  local url="${1}" newurl="${1}"
  local fields=(${url//\// })

  if [ "${fields[1]}" == "github.com" ]; then
    fields[1]="api.github.com"
    [ "${fields[4]}" == "pull" ] && fields[4]="pulls"
    [ "${fields[4]}" == "commit" ] && fields[4]="commits"
    newurl="${fields[0]}//${fields[1]}/repos/${fields[2]}/${fields[3]}/${fields[4]}/${fields[5]%\.patch}"
  elif [ "${fields[1]}" == "patch-diff.githubusercontent.com" ]; then
    fields[1]="api.github.com"
    [ "${fields[5]}" == "pull" ] && fields[5]="pulls"
    [ "${fields[5]}" == "commit" ] && fields[5]="commits"
    newurl="${fields[0]}//${fields[1]}/repos/${fields[3]}/${fields[4]}/${fields[5]}/${fields[6]%\.patch}"
  fi

  echo "${newurl}"
}

# Custom additional post-processing of patches
processtokens()
{
  local inputfile="${1}" tokens="${2}" token inlist

  _CANDETOOL="${CANDETOOL}"
  _IGNORE_RENAME=N

  [ -n "${tokens}" ] || return 0

  for token in ${tokens//,/ }; do
    if [ "$(type -t ${token})" == "function" ]; then
      ${token} "${inputfile}"
    else
      die 1 "ERROR line ${LINECOUNT}: Invalid post-processing token [${token}]"
    fi
  done
}

# Sets NAME and MSG
# Creates TMP
get_patch()
{
  local url tokens webresponse oldsha1
  local fields
  local lSHA1 uSHA1

  SHA1="$1"
  DESC="$2"
  SUB1="$3"
  SUB2="$4"

  NAME=
  ONAME=

  rm -f ${TMP}

  # This is a hack from lsPatches.sh - use + prefix on url to prevent merged pull requests
  # being ignored, so strip the + here
  [ "${SHA1:0:1}" == "+"  ] && SHA1="${SHA1:1}"

  [ "${SHA1:0:1}" == "-" ] && SHA1="${SHA1:1}" && REVERT=Y || REVERT=N
  [ "${REVERT}" == "Y" -a "${DESC:0:1}" == "-" ] && DESC="${DESC:1}"

  MSG="NOT FOUND: ${DESC}"

  tokens="${SHA1%\!*}"
  SHA1="${SHA1#*\!}"
  [ "${tokens}" == "${SHA1}" ] && tokens=

  uSHA1="${SHA1^^}"
  lSHA1="${SHA1,,}"

  if [ -f "${MYPATCHES}/${SHA1}" ]; then
    if [ -n "${SUB1}" ]; then
      sed "s#a/${SUB1}#a/${SUB2}#g;s#b/${SUB1}#b/${SUB2}#g;" ${MYPATCHES}/${SHA1} > ${TMP}
    else
      cp "${MYPATCHES}/${SHA1}" ${TMP}
    fi
    NAME="${SHA1/.patch/}"
    MSG="Got patch (f): ${SHA1}"
  elif [ "x${SHA1:0:1}" == "x/" -a -f "${SHA1}" ]; then
    cp "${SHA1}" ${TMP}
    NAME="${SHA1/.patch/}"
    MSG="Got patch (f): ${SHA1}"
  elif [ "${lSHA1/\/*/}" == "packages" ]; then
    [ -f "${BUILD_REPO_PATH}/${SHA1}" ] || die "ERROR: Cannot find ${BUILD_TYPE_PNAME} patch ${SHA1}"
    cp "${BUILD_REPO_PATH}/${SHA1}" ${TMP}
    NAME="${SHA1/.patch/}"
    MSG="Got patch (f): ${SHA1}"
    # Remove SHA1 from dynamic blacklist so it doesn't have to be whitelisted
    if [ -f "${BLACKLIST_DYN}" ]; then
      ${TGREP} -v "#ANCHOR# ${SHA1}$" "${BLACKLIST_DYN}" > "${BLACKLIST_DYN}.tmp"
      mv "${BLACKLIST_DYN}.tmp" "${BLACKLIST_DYN}"
    fi
  elif [[ "${uSHA1}" =~ ^PR[0-9]*$ ]]; then
    getpullrequest "https://github.com/xbmc/xbmc/pull/${SHA1:2}" "${TMP}" "${SHA1}"
  elif [[ "${uSHA1}" =~ ^OEPR[0-9]*$ ]]; then
    getpullrequest "${BUILD_REPO_GITHUB}/pull/${SHA1:4}" "${TMP}" "${SHA1}"
  elif [[ "${lSHA1}" =~ ^.*/pull/[0-9]*$ ]]; then
    [[ "${SHA1,,}" =~ ^http ]] && url="${SHA1}" || url="https://github.com/${SHA1}"
    getpullrequest "${url}" "${TMP}" "${SHA1}"
  else
    #If partial sha with no http[s]://, or references github, then its a github url...
    if [[ ! "${lSHA1}" =~ ^http ]] || \
       [[ "${lSHA1}" =~ .*github.com/ ]] || \
       [[ "${lSHA1}" =~ .*githubusercontent.com/ ]]; then
      ISGITHUB=Y
    else
      ISGITHUB=N
    fi

    ISBLOB=N
    ISCACHEABLE=Y

    #Never cache blobs - always pull directly
    [[ "${lSHA1}" =~ /blob/ ]] && ISBLOB=Y ISCACHEABLE=N
    #Never cache comparisons - always pull directly as may change
    [[ "${lSHA1}" =~ /compare/ ]] && ISCACHEABLE=N

    cachename="${PCACHE}/${SHA1//\//_}"

    # Derive package name from sha if not already set
    fields=(${SHA1//\// })

    if [ "${PKG_SET}" == "N" ]; then
      if [[ "${fields[0]}" =~ http[s]: ]]; then
        [ "${fields[4]}" == "commit" -o "${fields[4]}" == "compare" ] && PKG="${fields[3]}"
      else
        [ "${fields[2]}" == "commit" ] && PKG="${fields[1]}"
      fi
    fi

    if [ ${ISCACHEABLE} == Y -a -f ${cachename} ]; then
      cp ${cachename} ${TMP}
      CACHE_STATUS=c
    else
      rm -f ${cachename}

      # *.patch likely to be a non-sha1 based patch, ie. actual user file
      if [ ${ISGITHUB} == Y ]; then
        oldsha1="${SHA1}"
        SHA1="${SHA1#*//github.com/}"
        SHA1="${SHA1#*//raw.githubusercontent.com/}"
        SHA1="${SHA1#*//patch-diff.githubusercontent.com/}"
        if [ ${ISBLOB} == Y ]; then
          webrequest "https://raw.githubusercontent.com/${SHA1//\/blob\//\/}" "${TMP}" || rm -f "${TMP}"
        else
          # specific commit in a pull request, eg. https://github.com/LibreELEC/LibreELEC.tv/pull/449/commits/f40d475a01b17b257ecca1450dc27bf76bde3385
          if [ "${fields[1]}" == "github.com" -a "${fields[4]}" == "pull"  -a "${fields[6]}" == "commits" ]; then
            url="${fields[0]}//${fields[1]}/${fields[2]}/${fields[3]}/commit/${fields[7]%.patch}"
          else
            url="https://github.com/${SHA1}"
          fi

          webresponse="$(webrequest "${url}.patch" "${TMP}" "%{http_code}" || rm -f "${TMP}")"
          # If forbidden (403), retry using Github API
          # If forbidden (404), doesn't exist, or repo might be private - retry using authenticated API
          if [ "${webresponse}" == "403" -o "${webresponse}" == "404" ]; then
            webresponse="$(webrequest "$(rewrite_url4api "${url}")" "${TMP}" "%{http_code}" "Accept: application/vnd.github.v3.patch" || rm -f "${TMP}")"
          fi

          #If modified sha can't be found, use original sha as last resort
          if [ "${webresponse}" == "404" ]; then
            webresponse="$(webrequest "${oldsha1}" "${TMP}" "%{http_code}" || rm -f "${TMP}")"
          fi
        fi
      else
        webrequest "${SHA1}" "${TMP}" || rm -f "${TMP}"
      fi

      [ ${ISCACHEABLE} == Y -a -f ${TMP} ] && cp ${TMP} ${cachename}

      CACHE_STATUS=d
    fi

    if [ -f "${TMP}" ]; then
      NAME="${DESC}"
      MSG="$(getSubject ${TMP})"
      [ -z "${MSG}" ] && MSG="${NAME}"
      MSG="Got patch (${CACHE_STATUS}): ${MSG}"
    fi
  fi

  # Tokens take the form "dosomething,doanotherthing!SHA1"
  # where each token is a hard-coded custom action
  processtokens "${TMP}" "${tokens}"

  # De-toolize this patch?
  if [ "${CANDETOOL}" == "Y" -a "${_CANDETOOL}" == "Y" ] && detool_patch "${DESC}" "${TMP}" "${SHA1}" "${REVERT}"; then
    if [ "${REVERT}" == "Y" ]; then
      revert_patch "${TMP}" "${SHA1}"
      MSG="${MSG/Got patch/REVERTED }"
    fi
    return 0
  else
    [ -f "${TMP}" ] || return 1
    if [ "${REVERT}" == "Y" ]; then
      revert_patch "${TMP}" "${SHA1}"
      MSG="${MSG/Got patch/REVERTED }"
    fi
  fi

  return 0
}

# Sets PATCH and MSG.
# Creates TMP from TMP_SPLIT.
# Returns 1 if last patch, else 0
split_patch()
{
  lastline=$(cat ${TMP_SPLIT} | wc -l)

  [ ${PATCH} -ge ${lastline} ] && return 1

  linefrom=${PATCH}
  if [ ${REVERT} == Y ]; then
    lineto=$(tail -n +$((linefrom + 1)) ${TMP_SPLIT} | ${TGREP} --max-count=1 -nE "^reverted:$" | cut -d: -f1)
    [ -n "${lineto}" ] && lineto=$((linefrom + lineto)) || lineto=$((lastline + 1))
    lcount=$((lineto - linefrom))
  else
    lineto=$(tail -n +${linefrom} ${TMP_SPLIT} | ${TGREP} --max-count=1 -nE "^-- $" | cut -d: -f1)
    if [ -n "${lineto}" ]; then
      lineto=$((linefrom + lineto + 3))
    else
      lineto=$(tail -n +$((linefrom + 4)) ${TMP_SPLIT} | ${TGREP} --max-count=1 -nE '^.*: \[PATCH [0-9]*/[0-9]*\]' | cut -d: -f1)
      [ -n "${lineto}" ] && lineto=$((linefrom + lineto))
    fi
    [ -z "${lineto}" ] && lineto=$((lastline + 1))
    lcount=$((lineto - linefrom))
  fi

#  echo "${linefrom}, ${lineto}, ${lcount} (${lastline})"
  tail -n +${linefrom} ${TMP_SPLIT} | head -${lcount} > ${TMP}

  PATCH=${lineto}

  SUBJECT=
  if [ -f "${TMP}" ]; then
    MSG="$(getSubject ${TMP})"
    [ -z "${MSG}" ] && MSG="${NAME}"
    [ "x${MSG}" != "x${NAME}" ] && SUBJECT="${MSG} (${NAME})" || SUBJECT="${MSG}"
    MSG="Got patch (s): ${SUBJECT}"
    [ ${REVERT} == Y ] && MSG="${MSG/Got patch/REVERTED }"
  fi

  COUNT=$((COUNT + 1))
  TOTAL=$((TOTAL + 1))

  return 0  
}

# Creates multiple patch files, which need to be processed in sequence
# If an already cached version of the split file(s) is available (cached as
# a tar file) then use that instead.
split_patch_fast()
{
  local input="${1}" isdetooled="${2}" realname="${3}"
  local archive="${PCACHE}/$(md5sum "${input}" | awk '{print $1}').split" patch

  rm -f ${TMP_SPLIT_DIR}/*
  touch ${TMP_SPLIT_DIR}/header

  if [ -s ${archive} ]; then
    debuglog "UNCACHING SPLIT PATCHES..."
    tar xvzf ${archive} -C ${TMP_SPLIT_DIR} >/dev/null
  else
    debuglog "SPLITTING PATCHES..."
    # If not reverting, and it looks like a typical git patch (set), then
    # split it into patches
    if [ ${REVERT} == N -a -n "$(${TGREP} "^---$" "${input}")" ]; then
      split_patch_fast_patches "${input}" "${isdetooled}" "${realname}"
    else
    # otherwise split into per-file hunks
      split_patch_fast_hunks "${input}" "${isdetooled}" "${realname}"
    fi

    # Delete any patch that only fiddles with .gitignore (which won't exist in the unpacked build folder)
    for patch in $(ls -1 ${TMP_SPLIT_DIR}/*.patch); do
      if [ $(grep "^--- [ab]/.*$" ${patch} | wc -l) -eq 1 ]; then
        if grep -q '^--- [ab]/.gitignore$' ${patch}; then
          rm -f ${patch}
#          echo "deleting $patch"
        fi
      fi
    done

    debuglog "CACHING SPLIT PATCHES..."

    # Compute patch signatures so that it will be added to cached files
    for patch in $(ls -1 ${TMP_SPLIT_DIR}/*.patch); do
      echo "${PKG} $(getpatchsig "${patch}") ${patch}" >> ${TMP_SPLIT_DIR}/patch.sigs
    done

    tar cvzf ${archive} -C ${TMP_SPLIT_DIR} . >/dev/null
  fi

  debuglog "SPLIT COMPLETE"

  return 0
}

split_patch_fast_patches()
{
  local input="${1}" isdetooled="${2}" realname="${3}"
  local line index text pstart
  local chunks=() chunkstart=0 chunkend=0
  local indexfname indexf=0
  local totallines=$(wc -l "${input}" | awk '{print $1}')

  while read -r line; do
    index="${line/:*}"
    text="${line#*:}"
    [[ ${text} =~ ^diff ]] && continue
    [[ ${text} =~ ^index ]] && continue
    [[ ${text} =~ ^new ]] && continue
    [[ ${text} =~ ^deleted ]] && continue
    [[ ${text} =~ ^@@ ]] && continue

    if [[ ${text} =~ ^[^\ ]*\ [0-9a-f]*\ .*\ [0-9]{4}$ ]]; then
      debuglog "PATCH FOUND: ${line}"
      pstart=${index}
    fi

    if [[ ${text} =~ ^---$ ]]; then
      chunks+=(${pstart})
      pstart=
    fi
  done <<< "$(${TGREP} -nE "^---$|^[^ \+-]" "${input}")"
  chunks+=($((totallines + 1)))

  chunkstart=1
  for chunkend in ${chunks[@]:1}; do
    indexf=$((indexf + 1))
    indexfname="${TMP_SPLIT_DIR}/$(printf "%06d.patch" ${indexf})"
    debuglog "SPLITTING PATCH [${indexfname}, ${chunkstart} => ${chunkend}]"

    tail -n+${chunkstart} ${input} | head -n+$((chunkend - chunkstart)) >"${indexfname}"

    chunkstart=${chunkend}
  done
}

split_patch_fast_hunks()
{
  local input="${1}" isdetooled="${2}" realname="${3}"
  local index=0 oindex=0 indexfname inpatch=N
  local lastnonblankline1= lastnonblankline2= lastnonblankline3= successiveblanks=0 ignorenext=0
  local archive="${PCACHE}/$(md5sum "${input}" | awk '{print $1}').split"

  while IFS= read -r line; do
    if [ ${REVERT} == Y ]; then
      [[ ${line} =~ ^reverted:$ ]] && index=$((index + 1))
    else
      if [ ${ignorenext} -ne 0 ]; then
        ignorenext=$((ignorenext - 1))
      elif [[ ${line} =~ ^diff ]]; then
        inpatch=Y
        index=$((index + 1))
      elif [ -n "${line}" ]; then
        if [[ ${lastnonblankline2} =~ ^--\ $ || ${lastnonblankline2} =~ ^--$ ]]; then
          inpatch=N
          index=$((index + 1))
        elif [[ ${line} =~ ^literal\ 0 ]]; then
          ignorenext=1
        elif [[ ${inpatch} == Y && ${successiveblanks} -ne 0 && ! ${line} =~ ^[[:space:]@+-] ]]; then
          [ -s ${TMP_SPLIT_DIR}/header ] && echo -n >${TMP_SPLIT_DIR}/header
          inpatch=N
          index=$((index + 1))
        fi
      fi
    fi
#echo "index: ${index}, inpatch: ${inpatch}, sb: ${successiveblanks}, in: ${ignorenext}, line: [${line}]">&2

    if [ -n "${line}" ]; then
      lastnonblankline3="${lastnonblankline2}"
      lastnonblankline2="${lastnonblankline1}"
      lastnonblankline1="${line}"
      successiveblanks=0
    else
      successiveblanks=$((successiveblanks + 1))
    fi

    if [ ${REVERT} == N -a ${inpatch} == N ]; then
      echo "${line}" >> ${TMP_SPLIT_DIR}/header
      continue
    elif [ ${index} -ne ${oindex} ]; then
      oindex=${index}
      indexfname="${TMP_SPLIT_DIR}/$(printf "%06d.patch" ${index})"
      debuglog "SPLITTING PATCH [${indexfname}]"
      cp ${TMP_SPLIT_DIR}/header "${indexfname}"
    fi

    echo "${line}" >> "${indexfname}"
  done < "${input}"

  return 0  
}

# Creates multiple patch files, which need to be processed in sequence
# If an already cached version of the split file(s) is available (cached as
# a tar file) then use that instead.
split_patch_fast_old()
{
  local input="${1}" isdetooled="${2}" realname="${3}"
  local index=0 oindex=0 indexfname inpatch=N
  local lastnonblankline1= lastnonblankline2= lastnonblankline3= successiveblanks=0 ignorenext=0
  local archive="${PCACHE}/$(md5sum "${input}" | awk '{print $1}').split"

  rm -f ${TMP_SPLIT_DIR}/*
  touch ${TMP_SPLIT_DIR}/header

  if [ -s ${archive} ]; then
    tar xvzf ${archive} -C ${TMP_SPLIT_DIR} >/dev/null
    return 0
  fi

  while IFS= read -r line; do
    if [ ${REVERT} == Y ]; then
      [[ ${line} =~ ^reverted:$ ]] && index=$((index + 1))
    else
      if [ ${ignorenext} -ne 0 ]; then
        ignorenext=$((ignorenext - 1))
      elif [[ ${line} =~ ^diff ]]; then
        inpatch=Y
        index=$((index + 1))
      elif [ -n "${line}" ]; then
        if [[ ${lastnonblankline2} =~ ^--\ $ || ${lastnonblankline2} =~ ^--$ ]]; then
          inpatch=N
          index=$((index + 1))
        elif [[ ${line} =~ ^literal\ 0 ]]; then
          ignorenext=1
        elif [[ ${inpatch} == Y && ${successiveblanks} -ne 0 && ! ${line} =~ ^[[:space:]@+-] ]]; then
          [ -s ${TMP_SPLIT_DIR}/header ] && echo -n >${TMP_SPLIT_DIR}/header
          inpatch=N
          index=$((index + 1))
        fi
      fi
    fi
#echo "index: ${index}, inpatch: ${inpatch}, sb: ${successiveblanks}, in: ${ignorenext}, line: [${line}]">&2

    if [ -n "${line}" ]; then
      lastnonblankline3="${lastnonblankline2}"
      lastnonblankline2="${lastnonblankline1}"
      lastnonblankline1="${line}"
      successiveblanks=0
    else
      successiveblanks=$((successiveblanks + 1))
    fi

    if [ ${REVERT} == N -a ${inpatch} == N ]; then
      echo "${line}" >> ${TMP_SPLIT_DIR}/header
      continue
    elif [ ${index} -ne ${oindex} ]; then
      oindex=${index}
      indexfname="${TMP_SPLIT_DIR}/$(printf "%06d.patch" ${index})"
      debuglog "SPLITTING PATCH [${indexfname}]"
      cp ${TMP_SPLIT_DIR}/header "${indexfname}"
    fi

    echo "${line}" >> "${indexfname}"
  done < "${input}"

  # Compute patch signatures so that it will be added to cached files
  for patch in $(ls -1 ${TMP_SPLIT_DIR}/*.patch); do
    echo "${PKG} $(getpatchsig "${patch}") ${patch}" >> ${TMP_SPLIT_DIR}/patch.sigs
  done

  tar cvzf ${archive} -C ${TMP_SPLIT_DIR} . >/dev/null

  return 0  
}

# Extract skin (Confluence, Estuary) or non-skin patches from a single patch
# Ignore skin.estouchy diffs as we can't handle this skin
# Return 0 if there is a patch to be applied, or 1 if not
process_skin()
{
  local isskin=${1} ignoreskin="${2:-skin.estouchy}"
  local l header=Y inpatch=N startpatch=N result=1
  local ignorefile=N

  while IFS= read -r l; do
    [[ "${l}" =~ ^diff\  ]] && startpatch=Y || startpatch=N
    if [ ${startpatch} == Y ]; then
      if [[ -n "${ignoreskin}" && ${l} =~ .*/addons/${ignoreskin}/.* ]]; then
        ignorefile=Y
      else
        ignorefile=N

        header=N
        if [ ${isskin} == Y ]; then
          [[ "${l}" =~ .*addons/skin\..* ]] && inpatch=Y || inpatch=N
        else
          [[ ! "${l}" =~ .*addons/skin\..* ]] && inpatch=Y || inpatch=N
        fi
        [ ${inpatch} == Y ] && result=0
      fi
    fi
    [ ${ignorefile} == Y ] && continue
    [ ${header} == Y -o ${inpatch} == Y ] && echo "${l}"
  done < ${TMP_SKIN}

  return ${result}
}

#Check for skin (Confluence, Estuary) contamination - if found, split patch
#into a skin and non-skin patch, then process individually
process_patch()
{
  local input="${1}" oldpkg

  if [ ${SPLIT_SKINS} == Y ] && ${TGREP} -qE "^--- [^/]/addons/skin\..*|^diff --git [^/]/addons/skin\..*" ${input}; then
    mv ${input} ${TMP_SKIN}

    process_skin N >${input} && process_single_patch "${input}"

    if process_skin Y >${input}; then
      oldpkg="${PKG}"
      if ${TGREP} -E "addons/skin\.confluence" "${input}" >/dev/null; then
        PKG=${OE_KODI_VER}-theme-Confluence
        sed -i "s#addons/skin\.confluence/##g" "${input}"
      elif ${TGREP} -E "addons/skin\.estuary" "${input}" >/dev/null; then
        PKG=${OE_KODI_VER}-theme-Estuary
        sed -i "s#addons/skin\.estuary/##g" "${input}"
      else # Ignore estouchy etc.
        clear_and_msg "SKIN IGNORED : $(${TGREP} -E -m1 "^[-+]{3,4} [ab]/addons/skin\..*" "${input}" | awk '{print $2}' | awk -F/ '{print $3}')"
        return 0
      fi
      process_single_patch "${input}"
      PKG="${oldpkg}"
    fi

    rm -f ${TMP_SKIN}
  else
    process_single_patch "${input}"
  fi
}

# Sets ITEM
# Creates final patch file.
process_single_patch()
{
  local input="${1}"
  local itemcnt

  # Remove newline add/remove changes from the patch - some developers can never get it right...
  # Return immediately if resulting patch contains no hunks
#  if ${TGREP} -qE "^\\\ No\ newline\ at\ end\ of\ file$" "${input}"; then
#    strip_newline_hunk "${input}" || return 0
#  fi

  CLEAN_NAME=
  THISPKG="${PKG}"

  if [ -n "${NAME}" ]; then
    ITEM=$((ITEM + 1))
#    itemcnt=$(getToken "index" "${DESC}")
    [ -z "${itemcnt}" ] && itemcnt=${ITEM}
    PREFIX="$(printf "%04d_%s" ${itemcnt} "${UNIQUE_PATCH_CODE}")"
    CLEAN_NAME="${PREFIX}_$(echo "${NAME}" | awk '{ X=tolower($0); gsub("[ /]","_",X); gsub("[^_\\-a-zA-Z0-9]","",X); print X }')"
  fi

  if [ -f "${input}" -a -n "${CLEAN_NAME}" ]; then
    inspect_patch "${input}"

    CLEAN_NAME="${CLEAN_NAME:0:120}.patch"

    #Always try to ensure our patches are applied last...
    CLEAN_NAME="${THISPKG}-ZZ-${CLEAN_NAME}"
    CLEAN_NAME="${CLEAN_NAME//\//_}"

    if [ "${TARGET}" == "${PATCHDIR}" -o "${TARGET}" == "${ALT_TARGET}" ]; then
      [ ! -d ${TARGET}/${THISPKG} ] && mkdir -p "${TARGET}/${THISPKG}"
      LASTPATCH="${TARGET}/${THISPKG}/${CLEAN_NAME}"
    else
      if [ -d "${TARGET}/${THISPKG}/patches" ]; then
        LASTPATCH="${TARGET}/${THISPKG}/patches/${CLEAN_NAME}"
      elif [ -d "${TARGET}/patches/${THISPKG}" ]; then
        LASTPATCH="${TARGET}/patches/${THISPKG}/${CLEAN_NAME}"
      else
        LASTPATCH="${TARGET}/${THISPKG}/${CLEAN_NAME}"
      fi
    fi
    mv "${input}" "${LASTPATCH}"
  fi

  showprogress
}

# ** THIS IS IMPOSSIBLE TO SOLVE! **
# Remove hunks adding or removing newlines as these often conflict with other 
# patches applying the same change - patches from different committers may try to
# add (or remove) the same newline.
# Most often affects Windows files (eg. project/VS2010Express/*)
# ** THIS IS IMPOSSIBLE TO SOLVE! **
strip_newline_hunk()
{
  local input="${1}" achanges=0 bchanges=0 nonewlinecnt=0 beingadded
  local hunk="$(gettmpdirp)/hunk.dat"
  local output="$(gettmpdirp)/patch.tmp"

  rm -f "${hunk}" "${output}"

  while IFS= read -r line; do
    if [[ ${line} =~ ^reverted: || ${line} =~ ^diff || ${line} =~ ^index || ${line} =~ ^\-\-\-\  || ${line} =~ ^@@\ .*\ @@$ ]]; then
      # Newline is being added or dropped...
      if [ -f ${hunk} ]; then
        if [ ${nonewlinecnt} -eq 1 ]; then
          [[ $(tail -1 ${hunk}) =~ ^\\\ No\ newline\ at\ end\ of\ file$ ]] && beingadded=N || beingadded=Y
          cat "${hunk}" >> "${output}"
          [ ${beingadded} == Y ] && echo "\ No newline at end of file" >> "${output}"
#          [ ${beingadded} == N ] && cat "${hunk}" | sed "/\ No newline at end of file/d" >> "${output}"
        else
          cat "${hunk}" >> "${output}"
        fi
      fi

      rm -f "${hunk}"
      achanges=0
      bchanges=0
      nonewlinecnt=0
    fi

    echo "${line}" >> "${hunk}"

    [ "${line:0:1}" == "-" ] && achanges=$((achanges + 1))
    [ "${line:0:1}" == "+" ] && bchanges=$((bchanges + 1))
    [[ ${line} =~ ^\\\ No\ newline\ at\ end\ of\ file$ ]] && nonewlinecnt=$((nonewlinecnt + 1))
  done < "${input}"

  # Newline is being added or dropped... ignore if this is the only change
  if [ -f ${hunk} ]; then
    if [ ${nonewlinecnt} -eq 1 ]; then
      [[ $(tail -1 ${hunk}) =~ ^\\\ No\ newline\ at\ end\ of\ file$ ]] && beingadded=N || beingadded=Y
      cat "${hunk}" >> "${output}"
      [ ${beingadded} == Y ] && echo "\ No newline at end of file" >> "${output}"
#      [ ${beingadded} == N ] && cat "${hunk}" | sed "/\ No newline at end of file/d" >> "${output}"
    else
      cat "${hunk}" >> "${output}"
    fi
  fi
  rm -f "${hunk}"

  mv "${output}" "${input}"

  # If updated patch contains no hunks, return 1 so that the patch can be ignored
  if ${TGREP} -qE -m1 "^@@ -[[:digit:]]* \+[[:digit:]]* @@" "${input}" || \
     ${TGREP} -qE -m1 "^@@ -[[:digit:]]*,[[:digit:]]* \+[[:digit:]]*,[[:digit:]]* @@" "${input}"; then
    return 0
  else
    return 1
  fi
}

clear_and_msg()
{
  echo -en "                            \r" >&2
  echo "${1}"
}

showprogress()
{
  if [ ${VERBOSE} == Y -o ${SHOWBLACKLIST} == N ]; then
    printf "%s\n" "${MSG}"
  else
    if [ "${REVERT}" == "Y" -o "${DETOOLED}" == "Y" ]; then
      printf "${CLR_BLANKLINE}%s\n" "${MSG}"
    fi
    printf "Processing patches... %3d%% %s\r" $((100 * COUNT / TOTAL)) ${SPINNER:ITEM%${#SPINNER}:1} >&2
  fi
}

# Run a command. If required, variable ${LASTPATCH} will be available with the
# full path for the most recent patch file.
runCommand()
{
  local cmd="$(echo "${1}" | sed 's/^[ \t]*runCommand[ \t]*//')" curdir="${PWD}"
  [ ${VERBOSE} == Y ] && echo "Executing CMD: ${cmd}"
  cd ${BUILD_REPO_PATH}
  eval "${cmd}"
  cd ${curdir}
}

# Extract patch description from first 12 lines of patch
getSubject()
{
  local filename="${1}" len="${2}" insubject=N
  local line subject

  [ "$(head -1 "${filename}")" == "reverted:" ] && return 0

  while IFS= read -r line; do
    if [ ${insubject} == Y ]; then
      [ -n "${line}" -a "${line:0:1}" == " " ] && subject="${subject}${line}" || break
    elif [[ ${line} =~ ^Subject:\  ]]; then
      insubject=Y
      subject="${line:9}"
    elif [[ ${line} =~ ^\ \ \ \ $ ]]; then
      insubject=Y
      subject="${line:4}"
    fi
  done <<< "$(head -12 ${filename})"
  [ -n "${len}" ] && echo "${subject:0:${len}}" ||  echo "${subject}"
}

# Split a file and eliminate (filter out) duplicates
filterpatches()
{
  local input="$1" prefix="${2}" isdetooled="${3}"
  local newpatch="${input}.new"
  local patch

  rm -f "${newpatch}"

  split_patch_fast "${input}" "${isdetooled}" ""

  for patch in $(ls -1 ${TMP_SPLIT_DIR}/*.patch); do
    filterpatch_single "${patch}" && { echo "${prefix}: $(getSubject "${patch}" 80)"; continue; }
    cat "${patch}" >> "${newpatch}"
  done

  mv "${newpatch}" "${input}"

  return 0
}

# Maintain a digest of patches - if we see a repeated digest (patch), then return 0
# otherwise add the new patch to the history of digests and return 1
filterpatch_single()
{
  local input="${1}"
  local digest

  [ -f ${TMP_SPLIT_DIR}/patch.sigs ] && digest="$(${TGREP} "^${PKG} [0-9a-f]* ${input}$" ${TMP_SPLIT_DIR}/patch.sigs | awk '{print $2}')"
  [ -z "${digest}" ] && digest="$(getpatchsig "${input}")"
  ${TGREP} "^${PKG} ${digest}$" "${FILTER_HASH}" 1>/dev/null 2>&1 && return 0
  echo "${PKG} ${digest}" >>"${FILTER_HASH}"
  return 1
}

# Calculate a "signature" (digest) for the patch
# by eliminating variable parts of the patch (subject,
# comment, index references etc.) so that patches which
# are functionally identical can be detected.
getpatchsig()
{
  local input="${1}"
  local diff=N
  local patch=""
  local scratch=$(gettmpdirp)/tmp.sig
  local PROGRAM

  PROGRAM='
BEGIN { GO=0 }
/^index\ / { next }
/^diff\ / { GO=1 }
/^reverted:$/ { GO=1 }
GO==1 { print $0 }
'

  awk "${PROGRAM}" "${input}" > "${scratch}"

  # If nothing processed, use the whole patch (probably not a git diff, just a regular diff -Naur)
  [ -s ${scratch} ] || cp "${input}" "${scratch}"

  md5sum "${scratch}" | awk '{ print $1 }'

  rm -f ${scratch}
}

getgitblacklist()
{
  local gitdir="${1}" package="${2}"
  local prefix="<<<+++>>>"

  git --git-dir="${gitdir}/.git" log --pretty=format:"${prefix}%H %B" \
    | ${TGREP} "^${prefix}" \
    | sed "s/^${prefix}//" \
    | sed 's`[ \t]*$``; s`\(.*\)`\1`' \
    | awk '{ print tolower($0) "#ANCHOR#"}' \
    | sed "s/[^ ]* /${package}#ANCHOR#/"
}

getallgitblacklists()
{
  local token repo pckg gpath

  for token in ${BUILD_ENV_REPOS}; do
    repo="${token%=*}"
    pckg="${token/*=/}"
    findinlist "${repo}" "${BUILD_ENV_STOCK_REPOS}" && continue
    findinlist "${repo}" "bcm2835-driver kodi-platform platform" && continue
    gpath="${BUILD_REPOS}/${repo}"
    [ -d "${gpath}" ] || gpath="${gpath}.git"
    [ -d "${gpath}/.git" ] || continue
    getgitblacklist "${gpath}" "${pckg}"
  done
}

webrequest()
{
  local url="${1}" output="${2}" withreturn="${3}" header="${4}"
  local result was timestart timetaken
  local mycurl mycurl_redacted

  if [ -n "${url}" ]; then
    [[ ${url} =~ .*://.* ]] || url="https://github.com/${url}"
    # Convert plain pastebin.com to raw - could be pastebin.com/raw.php?i=<id> or pastebin.com/raw/<id>
    if [[ ${url} =~ ^http://pastebin.com/.* ]]; then
      [[ ${url} =~ /raw\.php\?i=.* || ${url} =~ /raw/ ]] || url="${url//\.com\//.com\/raw\/}"
    fi
  fi

  mycurl="curl -sfL --connect-timeout 30 --retry 6"

  [ -n "${header}" ]     && mycurl+=" -H \"${header}\""
  [ -n "${withreturn}" ] && mycurl+=" -w \"${withreturn}\""
  [ -n "${output}" ]     && mycurl+=" -o \"${output}\""

  [ -n "${CURL_INSECURE}" ] && mycurl+=" --insecure"

  mycurl_redacted="${mycurl}"

  if [[ ${url} =~ https://api.github.com/.* ]]; then
    mycurl_redacted+=" ${AUTHENTICATION_REDACTED}"
    mycurl+=" ${AUTHENTICATION}"
  fi

  mycurl_redacted+=" --url \"${url}\""
  mycurl+=" --url \"${url}\""

  debuglog "CURL REQUEST [${mycurl_redacted}]"

  timestart=$(date +%s)

  eval "${mycurl}"
  result=$?
  was=${result}
  [ ${result} -eq 56 ] && result=0

  timetaken=$(($(date +%s) - timestart))

  [ ${was} -eq ${result} ] && debuglog "CURL RESULT  [${result}]" || debuglog "CURL RESULT  [${result}], originally [${was}]"

  [ ${timetaken} -ge 30 ] && echo "NOTICE: Very slow webrequest, ${timetaken} seconds: [${mycurl_redacted}], result [${result}]" >&2

  return ${result}
}

# Renumber patches within each package folder.
# This ensures stability when subsequently calculating stamp checksums.
# Without this, removing or adding a linux patch will have knock-on effects in all
# subsequently generated pacakge folders, causing their stamps to fail and be "dirty" (even when not).
renumber_patches()
{
  local patchdir="$1"
  local count dir oldfile newfile

  if [ -d ${patchdir} ]; then
    cd ${patchdir}
    for dir in $(ls -1); do
      count=0
      for oldfile in $(ls -1 ${dir}/${dir}-ZZ-*.patch 2>/dev/null); do
        count=$((count+1))
        newfile="${oldfile##*/}"
        newfile="${newfile/${dir}-ZZ-[0-9][0-9][0-9][0-9]}"
        newfile="${dir}/$(printf "%s-ZZ-%04d%s" "${dir}" ${count} "${newfile}")"
        [ "${oldfile}" == "${newfile}" ] || mv ${oldfile} ${newfile}
      done
    done
    cd - >/dev/null
  fi
}

translatepkg()
{
  case "$1" in
    xbmc)     echo "${OE_KODI_VER}";;
    service.libreelec.settings) echo "LibreELEC-settings";;
    FFmpeg)   echo "ffmpeg";;
    librtmp)  echo "rtmpdump";;

    *)        echo "$1";;
  esac
  return 0
}

debuglog()
{
  local timestamp

  if [ ${VERBOSEDEBUG} == Y ]; then
    timestamp="$(date "+%Y-%m-%d %H:%M:%S.%N")"
    echo "${timestamp:0:25}: DEBUG: $@" >&2
  fi
}

### main ###

if [ "$1" == "packages" ]; then
  if [ -n "${DEVICE}" ]; then
    _tmp="${BUILD_REPO_PATH}/projects/${PROJECT}/devices/${DEVICE}"
  else
    _tmp="${BUILD_REPO_PATH}/projects/${PROJECT}"
  fi
  PACKAGES="$(find ${_tmp} -regex "^.*/.*[0-9][0-9][0-9][0-9]_${UNIQUE_PATCH_CODE}_.*.patch" -exec dirname "{}" \;)"
  [ -n "${PACKAGES}" ] && TAINTED="$(basename -a ${PACKAGES} | sort -u | tr '\n' ' ')"
  echo "Tainted packages: ${TAINTED%?}"
  exit
fi

CLEAN=N
PURGE=N
VERBOSE=N
VERBOSEDEBUG=N
DYNBLACKLIST=Y
GITBLACKLIST=Y
CANSPLIT=Y
SHOWBLACKLIST=N
ALT_TARGET=
CANDETOOL=Y

[ "${BUILD_AUTOBLACKLIST,,}" == "no" ] && GITBLACKLIST=N

vcount=0

while getopts ":hbdgcrigpDPSvT:" opt; do
  case ${opt} in
    b)  SHOWBLACKLIST=Y;;
    d)  DYNBLACKLIST=N;;
    g)  GITBLACKLIST=N;;
    c)  CLEAN=Y;;
    r)  PROJECT=RPi; ARCH=arm;;
    i)  PROJECT=Generic; ARCH=x86_64;;
    p)  PURGE=Y;;
    D)  CANDETOOL=N;;
    P)  [ -f "$(gettmpdirp)/patches.dat" ] && INPUT="$(gettmpdirp)/patches.dat";;
    S)  CANSPLIT=N;;
    T)  ALT_TARGET="${OPTARG}";;
    v)  vcount=$((vcount+1));;
    h)  usage && exit 0;;
    \?) usage && die 1 "ERROR: Unknown argument [-${OPTARG}]";;
  esac
done

[ ${vcount} -eq 1 ] && VERBOSE=Y
[ ${vcount} -eq 2 ] && VERBOSEDEBUG=Y
[ ${vcount} -ge 3 ] && { VERBOSE=Y; VERBOSEDEBUG=Y; }

cd ${BIN}

# Remove any old blacklist files
rm -f ${BLACKLIST_STA_TMP} ${BLACKLIST_DYN} ${BLACKLIST_GIT}

[ -n "${ALT_TARGET}" ] && mkdir -p "${ALT_TARGET}"

if [ -n "${DEVICE}" ]; then
  PATCHDIR=${BUILD_REPO_PATH}/projects/${PROJECT}/devices/${DEVICE}/patches
else
  PATCHDIR=${BUILD_REPO_PATH}/projects/${PROJECT}/patches
fi
[ ! -d ${PATCHDIR} ] && mkdir ${PATCHDIR}

# Remove old patches from previous runs
for d in ${PATCHDIR}; do
  find ${d} -regex "^.*/.*[0-9][0-9][0-9][0-9]_${UNIQUE_PATCH_CODE}_.*\.patch" -delete
  while read -r dir; do
    [ -n "${dir}" ] || continue
    (cd ${BUILD_REPO_PATH} && git ls-files --error-unmatch "${dir/${BUILD_REPO_PATH}\//}" &>/dev/null || rm -fr "${dir}")
  done <<< "$(find ${d} -empty)"
done

[ "${CANDETOOL}" == "Y" ] || echo "NOTICE: De-tooling is DISABLED"

create_pcache

# Exit if we're only cleaning
[ "${CLEAN}" == "Y" ] && exit

# Nothing to process, exit
[ ! -f ${INPUT} ] && exit

# Remove from the cache any file last accessed more than 14 days ago
find "${PCACHE}" -type f -atime +14 -delete

# Use PATCHCODE as filter, if present
tmpfilter="$(${TGREP} -m1 -E "^#PATCHCODE=.*" ${INPUT} | sed 's/.*=//;s/,//g')"
[ -n "${tmpfilter}" ] && BUILD_PKG_FILTERS="${tmpfilter}"

#Pre-process static blacklist to avoid repeated processing with sed/tr/grep etc.
if [ -f ${BLACKLIST_STA} ]; then
  cat ${BLACKLIST_STA} \
    | tr -d "\r" \
    | ${TGREP} -v '^#' \
    | awk '{print tolower($0) "#ANCHOR#"}' \
    > ${BLACKLIST_STA_TMP}
fi

#Create a dynamic blacklist extracted from included patches
if [ ${DYNBLACKLIST} == Y ]; then
  MSG="Building dynamic blacklist... "
  CLEAR=
  echo "${MSG}"
  for f in ${BUILD_REPO_PATH}/packages/linux/patches/$(getoepkgoption packages/linux PKG_VERSION)/*.patch \
           ${BUILD_REPO_PATH}/projects/${PROJECT}/patches/linux/*.patch \
           ${BUILD_REPO_PATH}/packages/multimedia/ffmpeg/patches/*.patch \
           ${BUILD_REPO_PATH}/packages/mediacenter/${OE_KODI_VER}/patches/*.patch \
           ${BUILD_REPO_PATH}/packages/mediacenter/${OE_KODI_VER}-theme-Confluence/patches/*.patch \
           ${BUILD_REPO_PATH}/packages/mediacenter/${OE_KODI_VER}-theme-Estuary/patches/*.patch \
           ${BUILD_REPO_PATH}/projects/${PROJECT}/patches/${OE_KODI_VER}/*.patch \
           ${BUILD_REPO_PATH}/projects/${PROJECT}/patches/${OE_KODI_VER}-theme-Confluence/*.patch \
           ${BUILD_REPO_PATH}/projects/${PROJECT}/patches/${OE_KODI_VER}-theme-Estuary/*.patch \
           ;
  do
    [ -f "${f}" ] || continue
    F="$(echo "${f}" | sed "s#^${BUILD_REPO_PATH}/##")"
    echo -en "${CLEAR}${MSG}${F}" >&2
    ENDPATCH=Y
    while read -r l; do
      if [[ ${l} =~ ^Subject:\  ]]; then
        SUBJECT="${l}"
        ENDPATCH=N
      elif [ ${ENDPATCH} == N ]; then
        if [ -z "${l}" ]; then
          ENDPATCH=Y
        elif [[ ${l} =~ ^MIME-Version:\  || ${l} =~ ^--- ]]; then
          ENDPATCH=Y
        fi

        if [ ${ENDPATCH} == N ]; then
          SUBJECT="${SUBJECT} ${l}"
        else
          if [ -n "${SUBJECT}" ]; then
            echo "${SUBJECT}" \
              | sed "s/Subject: \[PATCH [0-9/]*\][ ]*//" \
              | sed "s/Subject: \[PATCH\][ ]*//" \
              | sed "s/\(.*\)/ \1/" \
              | awk -v filename="${F}" '{print tolower($0) "#ANCHOR#" " " filename}' \
              >> "${BLACKLIST_DYN}"
            SUBJECT=
          fi
        fi
      fi
    done < ${f}
    CLEAR="\r$(echo "${MSG}${F}" | sed "s/./ /g")\r"
  done
  echo -en "${CLEAR}" >&2
fi

# Create a blacklist based on Kodi and other repo git commits - add anchor to improve reliability of subsequent matching
if [ ${GITBLACKLIST} == Y  ]; then
  echo "Building git-based blacklist... "
  getallgitblacklists > ${BLACKLIST_GIT}
fi

# Start processing patches...

ITEM=0
COUNT=0
LINECOUNT=0
DETOOL_INDEX=0
TOTAL=$(${TGREP} -vE "^#|^$" ${INPUT} | wc -l)
[ ${TOTAL} == 0 ] && TOTAL=1
PATCH_NOT_FOUND=N

while read -r p; do
  LINECOUNT=$((LINECOUNT + 1))

  [ "${p:0:1}" == "#" ] && continue
  p="${p#"${p%%[![:space:]]*}"}"   # remove leading whitespace characters
  [ -z "${p}" ] && continue

  COUNT=$((COUNT + 1))

  [ -z "${ALT_TARGET}" ] && TARGET="${PATCHDIR}" || TARGET="${ALT_TARGET}"
  PKG="${OE_KODI_VER}"
  SUB1=
  SUB2=
  FIELDS=(${p})

  if [ "${FIELDS[0]}" == "runCommand" ]; then
    runCommand "${p}"
    continue
  fi

  LASTPATCH=

  PKG_SET=N
  for f in {0..2}; do
    FIELD="${FIELDS[${f}]}"
    case "${FIELD:0:1}" in
      "!") PKG="${FIELD:1}"; PKG_SET=Y;;
      "?") TARGET="${FIELD:1}";;
    esac
  done

  #Remove target and pkg from p, leaving sha1 and desc
  p="${p/!${PKG} }"
  p="${p/\?${TARGET} }"

  p="${p#${p%%[![:space:]]*}}"   # remove leading whitespace characters
  SHA1="${p%% *}" #first field
  DESC="${p#* }"  #second field
  DESC="${DESC#"${DESC%%[![:space:]]*}"}"   # remove leading whitespace characters

  [ "${SHA1:0:1}" == "@" ] && SHA1="${SHA1:1}"

  SPLIT=N
  CHECKBLACKLIST=Y
  if [ -f "${MYPATCHES}/${SHA1}" -o -f "${MYPATCHES}/${SHA1}.patch" ]; then
    SPLIT=Y
    CHECKBLACKLIST=N
    [ -f "${MYPATCHES}/${SHA1}" ] || SHA1="${SHA1/.patch}.patch"
  elif [[ "${SHA1^^}" =~ ^-?PR[0-9]*$ ]]; then
    SPLIT=Y
  elif [[ "${SHA1^^}" =~ ^-?OEPR[0-9]*$ ]]; then
    SPLIT=Y
  elif [[ "${SHA1,,}" =~ .*/pull/[0-9]*$ ]]; then
    SPLIT=Y
  else
    #Don't blacklist commits that are being reverted, or with tokens (xyz!<sha>)
    if [ "${SHA1:0:1}" != "-" -a "${SHA1#*\!}" == "${SHA1}" ]; then
      check_blacklist "${DESC}" "N" || continue
    fi
  fi

  if get_patch "${SHA1}" "${DESC}" "${SUB1}" "${SUB2}"; then
    PKG="$(translatepkg "${PKG}")"

    if [ ${SPLIT} == Y -a ${CANSPLIT} == Y ]; then
      [ ${SHOWBLACKLIST} == N -o ${VERBOSE} == Y ] && echo "${MSG}"

      split_patch_fast "${TMP}" "N" "${SHA1}"

      for patch in $(ls -1 ${TMP_SPLIT_DIR}/*.patch); do
        SUBJECT="$(getSubject "${patch}")"
        [ -n "${SUBJECT}" ] && SUBJECT="${SUBJECT} (${NAME})" || SUBJECT="${NAME}"
        if [ ${CHECKBLACKLIST} == Y ]; then
          check_blacklist "${SUBJECT}" "N" || continue
        fi
        if filterpatch_single "${patch}"; then
          echo "IGNORED  DUPE: ${SUBJECT}"
          continue
        fi
        MSG="Got patch (s): ${SUBJECT}"
        [ ${REVERT} == Y ] && MSG="${MSG/Got patch/REVERTED }"

        process_patch "${patch}"
      done
    else
      process_patch "${TMP}"
    fi
  else
    PATCH_NOT_FOUND=Y
    clear_and_msg "${MSG}"
  fi
done <<< "$(cat ${INPUT} | tr -d '\r')"

if [ "${CANDETOOL}" == "Y" -a "$PATCH_NOT_FOUND}" != "Y" ]; then
  # Process de-tooled patches...
  DETOOLED=Y
  echo "Processing DE-TOOLED patches..."

  while read -r package; do
    package="$(basename "${package}")"
    [ "${package}" == "." ] && continue
    PKG=${package}
    while read -r patch; do
      [ -n "${patch}" ] || continue
      patch="$(basename "${patch}")"
      infoname="${DETOOL_DIR}/$(echo "${package}/${patch}" | md5sum | awk '{ print $1 }').info"
      [ -f "${infoname}" ] || continue
      MSGS=

      source "${infoname}"

      TMP="${DETOOL_DIR}/${package}/${patch}"

      DESC="$(getSubject "${TMP}")"
      [ -z "${DESC}" ] && DESC="tools/depends/target/${package}/${patch}"

      check_blacklist "${DESC}" "N" || continue

      HASH="$(md5sum "${TMP}" | awk '{ print $1 }')"
      MATCHED=
      while read -r otherpatch; do
        if [ -n "${otherpatch}" ]; then
          if [ "${HASH}" == "$(md5sum "${otherpatch}" | awk '{ print $1 }')" ]; then
            MATCHED="${otherpatch}"
            break
          # Check hash of other patch without last line (which is often blank)
          elif [ "${HASH}" == "$(head -n-1 "${otherpatch}" | md5sum | awk '{ print $1 }')" ]; then
            MATCHED="${otherpatch}"
            break
          fi
        fi
      done <<< "$(find "${BUILD_REPO_PATH}/packages" -path "*/${package}/*" -iname "*.patch" | sort)"

      if [ -n "${MATCHED}" ]; then
        MSG="BLACKLIST.hsh: ${DESC} => ${MATCHED/${BUILD_REPO_PATH}\//}"
        showprogress
      else
        filterpatches "${TMP}" "DETOOLED DUPE" "Y"
        _dtotal=$(echo -e "${MSGS:0:-2}" | sed "s/\t/\n/g" | wc -l)
        _ntotal=$(${TGREP} -F "NAME=\"${NAME}\"" ${DETOOL_DIR}/*.info | wc -l)
        _dcount=0
        while read -r onemsg; do
          _dcount=$((_dcount + 1))
          if [ "${REVERT}" == "Y" ]; then
            MSG="${onemsg/Got patch/DTOOL&REV}"
          else
            MSG="${onemsg/Got patch/DETOOLED }"
          fi
          [ $_ntotal -ne 1 ] && MSG="${MSG} (${GROUP} of ${_ntotal})"
          [ ${_dcount} -eq ${_dtotal} ] && process_patch "${TMP}" || showprogress
        done <<< "$(echo -e "${MSGS:0:-2}" | sed "s/\t/\n/g")"
      fi
    done <<< "$(cd ${DETOOL_DIR}/${package}; find . -type f | sort)"
  done <<< "$(cd ${DETOOL_DIR}; find . -maxdepth 1 -type d | sort)"
fi

# Renumber patches within each package folder to avoid invalidating existing stamp files
[ -z "${ALT_TARGET}" ] && renumber_patches "${PATCHDIR}" || renumber_patches "${ALT_TARGET}"

printf "\r                            \r" >&2

rm -fr ${BLACKLIST_STA_TMP} ${BLACKLIST_DYN} ${BLACKLIST_GIT} ${TMP} ${TMP_SPLIT_DIR} ${TMP_SPLIT} ${TMP_SKIN} ${DETOOL_DIR}

[ ${PATCH_NOT_FOUND} == N ] && exit 0 || exit 1
