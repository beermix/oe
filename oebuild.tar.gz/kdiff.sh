#!/bin/bash

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

usage()
{
  echo "kdiff.sh [-c] [-d] [-p path] [-b path] [-C] [-F] [-L] [-A filter] [-h] [-v]"
  echo " -c  Compare against current config, not original/backup"
  echo " -d  Accept defaults"
  echo " -p  Path to config directory, if not default"
  echo " -b  Path to build (source) directory eg. .unpack, if not default"
  echo " -C  Full check with current commits - run checkpatches.sh -k. Assume -b .unpack"
  echo " -F  Full check with in-tree commits - run oepull.sh, checkpatches.sh -k. Assume -b .unpack"
  echo " -L  Full check with latest commits - run oepull.sh, checkpatches.sh -kr. Assume -b .unpack"
  echo " -A  Filter codes"
  echo " -v  Verbose"
  echo " -h  This message"
  die 0
}

verbose()
{
  [ ${VERBOSE} == Y ] && cat || cat >/dev/null
}

if [ -n "${DEVICE}" ]; then
  NCONFIG=/tmp/config.new.${DEVICE,,}
  NDIFF=/tmp/config.diff.${DEVICE,,}
  DIRCONFIG=${BUILD_REPO_PATH}/projects/${PROJECT}/devices/${DEVICE}/linux
else
  NCONFIG=/tmp/config.new.${PROJECT,,}
  NDIFF=/tmp/config.diff.${PROJECT,,}
  DIRCONFIG=${BUILD_REPO_PATH}/projects/${PROJECT}/linux
fi

CONFIGNAME=linux.${ARCH}.conf
BUILD="${BUILD_REPO_PATH}/$(getoeoption BUILD)"

TARGET_KERNEL_ARCH=$(getoeoption TARGET_KERNEL_ARCH)
[ "${TARGET_KERNEL_ARCH}" == "x86" ] && TARGET_KERNEL_ARCH=x86_64

KERNEL_VERSION=$(getoepkgoption linux PKG_VERSION)
[ -f ${DIRCONFIG}/${KERNEL_VERSION}/${CONFIGNAME} ] && DIRCONFIG="${DIRCONFIG}/${KERNEL_VERSION}"

DEFAULT=N
USECURRENT=N
FILTERCODES=kdiff
VERBOSE=N
COMMITS=
ALTDIRCONFIG=

while getopts "cdhCFLvp:b:A:" opt; do
  case ${opt} in
    c) USECURRENT=Y;;
    d) DEFAULT=Y;;
    A) FILTERCODES+=,${OPTARG};;
    p) ALTDIRCONFIG="$(_getabspath "${OPTARG}")";;
    b) BUILD=${OPTARG};;
    C) COMMITS=current;;
    F) COMMITS=upstream; FILTERCODES+=",kdiff-upstream";;
    L) COMMITS=latest; FILTERCODES+=",kdiff-latest";;
    v) VERBOSE=Y;;
    *) usage;;
  esac
done

ODIRCONFIG="${DIRCONFIG}"
if [ -n "${ALTDIRCONFIG}" ]; then
  _tmpdir="${ALTDIRCONFIG}/${DIRCONFIG#$(dirname "${BUILD_REPO_PATH}")/}"
  if [ -d "${_tmpdir}" ]; then
    DIRCONFIG="${_tmpdir}"
  else
    DIRCONFIG=${ALTDIRCONFIG}
  fi
fi

if [ -n "${COMMITS}" ]; then
  [ -n "${FILTERCODES}" ] && FILTERCODES="-A ${FILTERCODES}"
  echo "Initialising build environment..."
  if [ "${COMMITS}" == "latest" ]; then
    BUILD_CONFLICTS_REMOVE=yes ${BIN}/oepull.sh -p ${FILTERCODES} | verbose
    [ ${PIPESTATUS[0]} == 0 ] || exit
    echo "Initialising unpack environment ${TXYELLOW}(using latest support patches)${TXRESET}..."
    ${BIN}/checkpatches.sh -p linux -d -k ${FILTERCODES} -r ${CHECKPATCHES} | verbose
    [ ${PIPESTATUS[0]} == 0 ] || exit
  elif [ "${COMMITS}" == "upstream" ]; then
    BUILD_CONFLICTS_REMOVE=no ${BIN}/oepull.sh -p ${FILTERCODES} | verbose
    [ ${PIPESTATUS[0]} == 0 ] || exit
    echo "Initialising unpack environment ${TXGREEN}(using in-tree support patches)${TXRESET}..."
    ${BIN}/checkpatches.sh -p linux -d -k ${FILTERCODES} ${CHECKPATCHES} | verbose
    [ ${PIPESTATUS[0]} == 0 ] || exit
  elif [ "${COMMITS}" == "current" ]; then
    echo "Initialising unpack environment ${TXMAGENTA}(using current patches)${TXRESET}..."
    ${BIN}/checkpatches.sh -p linux -d -k ${FILTERCODES} ${CHECKPATCHES} | verbose
    [ ${PIPESTATUS[0]} == 0 ] || exit
  fi
  BUILD=${BIN}/.unpack
fi

ODIRCONFIG="$(_getabspath "${ODIRCONFIG}")"
DIRCONFIG="$(_getabspath "${DIRCONFIG}")"
BUILD="$(_getabspath "${BUILD}")"

CONFIG=${ODIRCONFIG}/${CONFIGNAME}
CONFIG_SHORT="${CONFIG#${BUILD_REPO_PATH}/}"
CONFIG=${DIRCONFIG}/${CONFIGNAME}

[ ${USECURRENT} == Y ] && OCONFIG=${CONFIG} || OCONFIG=${CONFIG}.bak

[ -f ${OCONFIG} ] || die 1 "Config file not found [${OCONFIG}] - quitting, use -c or -p?"
[ -d ${BUILD} ]   || die 1 "Build directory not found [${BUILD}] - quitting, use -b?"

LINUX="$(cd ${BUILD}; ls -1 | grep "^linux-")"
[ -z "${LINUX}" ] && die 1 "linux build folder not found, needs to be unpacked!"

cd ${BUILD}/${LINUX}
cp ${OCONFIG} .config

# Set CONFIG_INITRAMFS_SOURCE to a non-blank value as some options depend on it (see PR1594)
orig_initramfs_source="$(grep CONFIG_INITRAMFS_SOURCE= .config | awk -F= '{print $2}')"
sed -i 's#^CONFIG_INITRAMFS_SOURCE=.*#CONFIG_INITRAMFS_SOURCE=" "#' .config

if [ ${DEFAULT} == Y ]; then
  yes "" | ARCH=${TARGET_KERNEL_ARCH} make oldconfig || die
else
  ARCH=${TARGET_KERNEL_ARCH} make oldconfig || die
fi

# Restore original CONFIG_INITRAMFS_SOURCE so that it doesn't appear in the diff
sed -i "s#^CONFIG_INITRAMFS_SOURCE=.*#CONFIG_INITRAMFS_SOURCE=${orig_initramfs_source}#" .config

cp .config ${NCONFIG}

if [ ${ARCH} = x86_64 ]; then
  grep -qE "^CONFIG_EXTRA_FIRMWARE_DIR=" ${NCONFIG} || sed -i 's/^CONFIG_EXTRA_FIRMWARE=.*/&\nCONFIG_EXTRA_FIRMWARE_DIR="external-firmware"/' ${NCONFIG}
fi

echo "diff --git a/${CONFIG_SHORT} b/${CONFIG_SHORT}" >${NDIFF}
echo "--- a/${CONFIG_SHORT}" >>${NDIFF}
echo "+++ b/${CONFIG_SHORT}" >>${NDIFF}
diff -Naur ${OCONFIG} ${NCONFIG} | tail -n +3 >>${NDIFF}

echo "######################################################################################"
cat ${NDIFF}
echo "######################################################################################"
echo "New config: ${NCONFIG}"
echo "New diff  : ${NDIFF}"
