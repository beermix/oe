#/bin/bash

MAX_KEEP=64

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

[ -n "${PURGE_KEEP}" ] && MAX_KEEP=${PURGE_KEEP}

# Read patterns we don't want to purge - if one of the patterns
# matches the current profile, don't purge...
# example pattersn ".*", "pi.*", ".*-testing" etc.
if [ -f ${BIN}/.purge.limit ]; then
  while read -r pattern newlimit; do
    if [[ "${PROFILE}" =~ ^${pattern}$ ]]; then
      MAX_KEEP=${newlimit}
      break
    fi
  done < ${BIN}/.purge.limit
fi

[ ${MAX_KEEP} -eq 0 ] && exit 0

TARGET=$(getbuildtarget)

[ -d ${TARGET} ] && cd ${TARGET} || exit 1

PATTERN="${BUILD_REPO_DISTRO}-${DEVICE:-${PROJECT}}.${ARCH}-"

OLDEST="$(ls -lart ${PATTERN}*.kernel 2>/dev/null | tail -${MAX_KEEP} | head -1 | awk '{ print $9 }')"

if [ -n "${OLDEST}" ]; then
  find . -name "${PATTERN}*.*" -not -name "." -not -name "$(basename ${OLDEST} .kernel).*" -not -anewer "${OLDEST}" -exec rm {} \;
fi
