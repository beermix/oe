#!/bin/bash

# Notify completion.
# In the event of failure, send log to pastebin (if available)
onexit()
{
  local status="${1}" pburl
  shift

  if [ ${status} -eq 0 ]; then
    notifyme SOUND_OK "$@"
  else
    notifyme_with_log SOUND_ERR "${BUILD_LOG}" "$@"
  fi
}

# Lock a repo to prevent concurrent updates
lockrepo()
{
  local count=0
  exec 11>"$(gettmpdirg .global/.locks/repository)/$(echo "${1}" | md5sum | awk '{ print $1 }').lock"
  while ! flock --nonblock --exclusive 11; do
    [ ${count} -eq 0 ] && echo "Waiting on exclusive lock for local repo [${2}]..."
    count=$((count+1))
    sleep 1
  done
  FLOCKED="${1}"
}

unlockrepo()
{
  if [ -n "${FLOCKED}" ]; then
    flock --unlock 11 2>/dev/null
    FLOCKED=
  fi
}

clean_builds()
{
  echo "Cleaning cache and build directories..."

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _clean_one_build || return 1
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} Y _clean_one_build || return 1
    done
  fi

  echo
}

_clean_one_build()
{
  local build_dir="$(getoeoption BUILD)"

  printf "  PROFILE: %-20s  BUILD: %s\n" "${PROFILE}" "${build_dir}"

  [ -n "${BUILD_REPO_PATH}" ] || return 1
  [ -n "${build_dir}" ] || return 1

  if command -v ccache >/dev/null; then
    [ -n "${CCACHE_DIR}" -a -d "${CCACHE_DIR}" ] && ccache --clear --zero-stats >/dev/null
  fi
  [ -d "${build_dir}" ] && rm -fr "${build_dir}"

  return 0
}

update_repositories()
{
  local update_build_repo="${1}"
  local ctrlfile="$(gettmpdirp)/ctrlfile.dat"
  local cleanfile="$(gettmpdirp)/cleanfile.dat"
  local writeprofile=Y

  rm -f ${ctrlfile} ${cleanfile}
  touch ${ctrlfile} ${cleanfile}

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _update_repositories_one_repo ${update_build_repo} Y ${cleanfile} || return 1
  else
    if [ "${AUTOBUILD_PARALLEL,,}" == "yes" ]; then
      for profile in ${AUTOBUILD_PROFILES//,/ }; do
        resettainteditems
        executeasprofile ${profile} Y _update_repositories_one_repo ${update_build_repo} ${writeprofile} ${cleanfile} ${ctrlfile} "${AUTOBUILD_PROFILES}" || return 1
        writeprofile=N
      done
    fi
  fi

  return 0
}

# For each different build repo, update the build repo and associated repositories.
_update_repositories_one_repo()
{
  local update_build_repo="${1}" writeconfig="${2}" cleanfile="${3}" ctrlfile="${4}" autobuild_profiles="${5}"
  local repolist="${BUILD_ENV_REPOS} ${BUILD_ENV_ADDON_REPOS}" token repo pckg BEB BEAB
  local deferred_file="$(gettmpdir)/deferred_clean.dat"
  local oepull_deferred_packages

  # Don't update the same build repo repository more than once
  if [ -n "${ctrlfile}" ]; then
    [ -n "$(${TGREP} -E "^${BUILD_REPO_PATH}$" ${ctrlfile})" ] && return 0
  fi

  [ -n "${autobuild_profiles}" ] && export AUTOBUILD_PROFILES="${autobuild_profiles}"

  [ -n "${repolist}" ] || repolist="kodi-latest=kodi kodi-pvr-addons kodi-addon-xvdr bcm2835-driver libcec libnfs"

  rm -f ${deferred_file}
  if [ "${update_build_repo}" == "Y" ]; then
    optionalmk "${BUILD_TYPE_REPO_NAME}" || die 1 "git error (${BUILD_TYPE_REPO_NAME})"
    BEB="${BEB}${BUILD_TYPE_REPO_NAME}=${LAST_REPO_BRANCH_REV} "
  fi

  for token in ${repolist}; do
    repo="${token%=*}"
    pckg="${token/*=/}"
    optionalmk "${repo}" "${pckg}" || die 1 "git error (${repo})"
    if [ -n "${LAST_REPO_BRANCH_REV}" ]; then
      if findindelimitedlist_key1 "${repo}" "=" "${BUILD_ENV_ADDON_REPOS}"; then
        BEAB="${BEAB}${repo}=${LAST_REPO_BRANCH_REV} "
      else
        BEB="${BEB}${repo}=${LAST_REPO_BRANCH_REV} "
      fi
    fi
  done

  if [ "${writeconfig}" == "Y" ]; then
    AUTOBUILD_CONFIG="$(gettmpdir .config)/autobuild.conf"

    echo "${AUTOBUILD_CONFIG_INIT}" > ${AUTOBUILD_CONFIG}
    echo "" >> ${AUTOBUILD_CONFIG}

    echo "BUILD_ENV_REPOS=${BUILD_ENV_REPOS}" >> ${AUTOBUILD_CONFIG}
    echo "BUILD_ENV_ADDON_REPOS=${BUILD_ENV_ADDON_REPOS}" >> ${AUTOBUILD_CONFIG}
    echo "BUILD_ENV_BRANCHES=${BEB}" >> ${AUTOBUILD_CONFIG}
    echo "BUILD_ENV_ADDON_BRANCHES=${BEAB}" >> ${AUTOBUILD_CONFIG}
    echo "BUILD_ENV_STOCK_REPOS=${BUILD_ENV_STOCK_REPOS}" >> ${AUTOBUILD_CONFIG}
    echo "" >> ${AUTOBUILD_CONFIG}

    cp ${AUTOBUILD_CONFIG} "${BIN}/autobuild.conf"
  fi

  [ -s ${deferred_file} ] && oepull_deferred_packages="$(sed 's/--sync//g' ${deferred_file})"
  rm -f ${deferred_file}
  
  [ -n "${ctrlfile}" ] && echo "${BUILD_REPO_PATH}" >>${ctrlfile}
  [ -n "${cleanfile}" ] && echo "${BUILD_REPO_PATH}|${oepull_deferred_packages} $(gettainteditems)" >> ${cleanfile}

  return 0
}

# Make package if git timestamp of last commit is more recent than timestamp of last package
optionalmk()
{
  local REPO="${1}" PKG_NAME="${2}" MK_PKG="${3}" PKG_CLASS="${4}" GIT_PATH="${5}"
  local PKSYNC=No DOREFRESH=${REFRESH} OLD_SHA NEW_SHA CUR_SHA srcpath isgiturl result GIT FETCH MSG REPO_UPDATED
  local NEWBRANCH CURBRANCH BRANCHREV MK_PKG_ARGS FETCHED

  LAST_REPO_BRANCH_REV=

  # Determine any unspecified options and basic validation
  if [ -z "${REPO}" ]; then
    return 0
  elif [ "${REPO}" == "${BUILD_TYPE_REPO_NAME}" ]; then
    [ -n "${MK_PKG}" ]    || MK_PKG="${BIN}/oepull.sh"
    [ -n "${GIT_PATH}" ]  || GIT_PATH="${BUILD_REPO_PATH}"
  else
    [ -n "${MK_PKG}" ]    || MK_PKG="${BUILD_REPOS}/make-${REPO}.sh"
    [ -n "${PKG_NAME}" ]  || PKG_NAME="${REPO}"
#    [ "${PKG_NAME}" == "kodi-latest" ] && PKG_NAME="kodi"
    [ "${REPO}" == "kodi" ] && PKG_NAME="kodi"
    [ -n "${PKG_CLASS}" ] || PKG_CLASS="$(basename $(dirname $(find ${BUILD_REPO_PATH}/packages -type d -name "${PKG_NAME}") 2>/dev/null) 2>/dev/null)"
    [ -z "${GIT_PATH}" -a ${REPO} == "kodi-theme-Estuary" ] && GIT_PATH="${BUILD_REPOS}/kodi-latest.git" #legacy hack
    [ -n "${GIT_PATH}" ]  || GIT_PATH="${BUILD_REPOS}/${REPO}"
    [ -d "${GIT_PATH}" ]  || GIT_PATH="${BUILD_REPOS}/${REPO}.git"
    [ -n "${PKG_CLASS}" ] || { warn "${TXRED}WARNING: Repo [${REPO}] - cannot determine PKG_CLASS for this repo. Repo ignored.${TXRESET}";  return 0; }
  fi
  [ "${PKG_CLASS}" == "kodi-binary-addons" ] && PKG_CLASS="mediacenter/${PKG_CLASS}"

  # Do nothing for repos we want to ignore
  if findindelimitedlist_key1 "${REPO}" "=" "${BUILD_ENV_IGNORE_REPOS}"; then
    printf "${TXGREEN}Ignoring repo updates : [%-25s]${TXRESET}\n" "${REPO}"
    return 0
  fi

  # Remove source tarball of those repos that may have been updated
  # locally by another build, but for this build we need to be using
  # the stock tarball.
  # Deleting the tarball forces *ELEC to download the "current" version
  if findindelimitedlist_key1 "${REPO}" "=" "${BUILD_ENV_STOCK_REPOS}"; then
    printf "${TXGREEN}Using stock tarball   : [%-25s]${TXRESET}" "${REPO}"
    if [ -n "${PKG_CLASS}" -a -n "${PKG_NAME}" ]; then
      isgiturl="$(getoepkgoption ${PKG_NAME} PKG_GIT_URL)"
      srcpath="$(getoepkgtarpath ${PKG_CLASS} ${PKG_NAME})"
      if [ -n "${isgiturl}" ]; then
        addtainteditem "${PKG_NAME}"
        echo -n " [GIT]"
      elif [ -n "${srcpath}" -a -f "${srcpath}" ]; then
        if rm -f ${srcpath}* 2>/dev/null; then
          addtainteditem "${PKG_NAME}"
          echo -n " [OK]"
        fi
      fi
    fi
    echo
    return 0
  fi

  # If the repository is not the OE/LE repo but PKG_URL is blank, then we there is nothing to do here
  if [ "${REPO}" != "${BUILD_TYPE_REPO_NAME}" -a -z "$(getoepkgoption ${PKG_NAME} PKG_URL)" ]; then
    printf "${TXGREEN}Ignoring repo updates : [%-25s]${TXRESET}\n" "${REPO}"
    return 0
  fi

  [ -x ${MK_PKG} ] || { warn "${TXRED}WARNING: Repo [${REPO}] - cannot locate/execute MK_PKG (${MK_PKG}) for this repo. Repo ignored.${TXRESET}";  return 0; }

  # Acquire exclusive lock on this repo until we're finished with it (or we die)
  lockrepo "${GIT_PATH}" "${REPO}"

  # If repo directory doesn't exist but maker script exists, run it once now to clone the repo before proceeding
  if [ ! -d ${GIT_PATH} -a -x ${MK_PKG} ]; then
    ${MK_PKG}
    [ -d "${GIT_PATH}" ] || GIT_PATH="${BUILD_REPOS}/${REPO%\.git}"
  fi

  [ -d ${GIT_PATH} ] || { warn "${TXRED}WARNING: Repo [${REPO}] - cannot locate GIT_PATH (${GIT_PATH}) for this repo. Repo ignored.${TXRESET}";  unlockrepo; return 0; }

  # Switch branch
  NEWBRANCH="$(getbuildbranch "${GIT_PATH}" "${REPO}" "${BRANCHES}")"
  CURBRANCH="$(getcurrentbranch "${GIT_PATH}")"
  if [ -n "${NEWBRANCH}" ]; then
    if [ "${CURBRANCH}" != "${NEWBRANCH}" ]; then
      if [ "${REPO}" == "${BUILD_TYPE_REPO_NAME}" ]; then
        ${MK_PKG} -b "${NEWBRANCH}" || return 1
        loadconfig reload
      else
        ( cd "${GIT_PATH}" && git checkout "${NEWBRANCH}" >/dev/null ) || return 1
      fi
      DOREFRESH=Yes
      CURBRANCH="${NEWBRANCH}"
    fi
  fi

  # Always refresh build repo as this will re-init (clean) the repo
  if [ "${REPO}" == "${BUILD_TYPE_REPO_NAME}" ]; then
    MK_PKG_ARGS="${MK_PKG_ARGS} -D"
    [ -n "${PATCHCODE}" ] && MK_PKG_ARGS="${MK_PKG_ARGS} ${PATCHCODE}"
    [ -n "${PADDCODE}"  ] && MK_PKG_ARGS="${MK_PKG_ARGS} ${PADDCODE}"
    DOREFRESH=Yes
  fi

  # If we don't need a refresh, is the source tarball already present? If not, force a sync.
  if [ ${DOREFRESH} == No ]; then
    # If the package version has changed in the build repo then re-make the package using the new GIT_REV
    if [ -n "${PKG_CLASS}" -a -n "${PKG_NAME}" ]; then
      srcpath="$(getoepkgtarpath ${PKG_CLASS} ${PKG_NAME})"
      if  [ -z "${srcpath}" ]; then
        echo "WARNING: Cannot determine tarball url/path for package [${REPO}]" >&2
      elif [ ! -f ${srcpath} ]; then
        PKSYNC=Yes
      elif [ $(stat -c%Y "${srcpath}") -gt $(stat -c%Y "${GIT_PATH}/.git") ]; then
        PKSYNC=Yes
      fi
    fi
  fi

  # Check origin for any updates
  # If resetting to a specific rev, we must fetch just in case we're trying to reset to an as-yet unfetched rev
  BRANCHREV="$(getbuildbranchrevfromprofile "${GIT_PATH}" "${REPO}" "${BRANCHES}")"
  [ "${BRANCHREV}" == "HEAD" ] && BRANCHREV=
  if [[ ( ${DOREFRESH} == No && ${PKSYNC} == No ) || -n "${BRANCHREV}" ]]; then
    OLD_SHA="$(getcurrentrev "${GIT_PATH}" HEAD)"
    FETCH="$(cd "${GIT_PATH}" && git fetch origin 2>&1)" || return 1
    NEW_SHA="$(getcurrentrev "${GIT_PATH}" "@{upstream}")" || return 1
    if [ "${REPO}" != "${BUILD_TYPE_REPO_NAME}" -a ${DOREFRESH} == No -a -n "${PKG_CLASS}" -a -n "${PKG_NAME}" ]; then
      srcpath="$(getoepkgtarpath ${PKG_CLASS} ${PKG_NAME})"
      if [ -f "${srcpath}.repo" ]; then
        CUR_SHA_LONG="$(head -1 "${srcpath}.repo")"
        CUR_SHA_SHORT="$(echo "${CUR_SHA_LONG} ${BRANCHREV}" | awk '{ print $1 " " substr($2,0,length($3)) }')"
      fi
      # Force a refresh if we're missing any files
      [ ! -f "${srcpath}" ]      && DOREFRESH=Yes
      [ ! -f "${srcpath}.url" ]  && DOREFRESH=Yes
#      [ ! -f "${srcpath}.md5" ]  && DOREFRESH=Yes
      [ ! -f "${srcpath}.repo" ] && DOREFRESH=Yes
    fi

    if [ -n "${BRANCHREV}" ]; then
      # If tarball is for a different branch/revision, replace it
      [ "${CUR_SHA_SHORT}" != "${CURBRANCH} ${BRANCHREV}" ] && DOREFRESH=Yes
    else
      [ "${OLD_SHA}" != "${NEW_SHA}" ] && DOREFRESH=Yes

      # Final sanity check - if tarball is for a different branch/revision, replace it
      if [ "${REPO}" != "${BUILD_TYPE_REPO_NAME}" -a ${DOREFRESH} == No ]; then
        [ "${CUR_SHA_LONG}" != "${CURBRANCH} ${NEW_SHA}" ] && DOREFRESH=Yes
      fi
    fi
  fi

  [ -n "${BRANCHREV}" ] && CURBRANCH="${CURBRANCH}, rev=$(getshortrev "${BRANCHREV}")" || CURBRANCH="${CURBRANCH}, rev=HEAD"
  if [ ${DOREFRESH} == Yes -o ${PKSYNC} == Yes ]; then
    MSG="$(printf "Pulling repo updates  : [%-25s] (package.mk sync: %s, refresh: %s), [branch=%s]\n" "${REPO}" "${PKSYNC}" "${DOREFRESH}" "${CURBRANCH}")"
    echo "${TXYELLOW}${MSG}${TXRESET}"
    (cd "${GIT_PATH}" && git config color.ui always)
    ${MK_PKG} ${MK_PKG_ARGS} && result=0 || result=1
    (cd "${GIT_PATH}" && git config --unset color.ui)
    # Reload build repo config in case a property has now changed
    [ "${REPO}" == "${BUILD_TYPE_REPO_NAME}" ] && loadconfig reload || addtainteditem "${PKG_NAME}"
    REPO_UPDATED=Y
  else
    printf "${TXGREEN}No need to update repo: [%-25s], [branch=%s]${TXRESET}\n" "${REPO}" "${CURBRANCH}"
    result=0
  fi

  LAST_REPO_BRANCH_REV="$(getcurrentrev "${GIT_PATH}" HEAD)"
  LAST_REPO_BRANCH_REV="$(getcurrentbranch "${GIT_PATH}")@$(getshortrev "${LAST_REPO_BRANCH_REV}")"

  unlockrepo

  return ${result}
}

# Download latest commits
get_patches()
{
  local profile first=Y result=0
  local sigdir="$(gettmpdirp patches.sig clean)"
  local cleanfile="$(gettmpdirp)/cleanfile.dat"

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _get_patches "${sigdir}" || result=1
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} N _get_patches "${sigdir}" "${cleanfile}" || result=1
      [ ${result} -eq 0 ] || break
      first=N
    done
    loadconfig reload >/dev/null
  fi
  echo

  rm -fr "${sigdir}"

  return ${result}
}

_get_patches()
{
  local sigdir="${1}" cleanfile="${2}"
  local used_filters="$(_getusedfilters "${BUILD_PKG_CONTROL}" "${BUILD_PKG_FILTERS}")"
  local patch_signature="$(echo "${BUILD_PKG_CONTROL}|${BUILD_PKG_PATCHES}|${BUILD_DETOOL_PATCHES}|${BUILD_PKG_BWLIST}|${used_filters}" | md5sum | awk '{print $1}')"
  local creator="${sigdir}/${patch_signature}.creator"
  local icontrol="${sigdir}/${patch_signature}.icontrol"
  local blacklist="${sigdir}/${patch_signature}.blacklist"
  local control="${sigdir}/${patch_signature}.control"
  local patches="${sigdir}/${patch_signature}.tar.gz"
  local stash patchdir args

  if [ -n "${cleanfile}" -a -s "${cleanfile}" ]; then
    resettainteditems
    addtainteditems $(${TGREP} -E "^${BUILD_REPO_PATH}\|" "${cleanfile}" | cut -d"|" -f2-)
  fi

  # Add tainted packages based on existing patches
  settainteditems

  echo
  # Retrieve list of latest commits - avoid this step if same as a previous multibuild
  if [ -f "${creator}" -a -f "${control}" -a -f "${patches}" ]; then
    echo "${TXGREEN}[${PROFILE}]: Patch download avoided - reusing patches downloaded by a previous multi-build profile ($(cat ${creator}))${TXRESET}"
    echo

    # Remove any existing patches
    ${BIN}/getPatches.sh -c || return 1

    [ -f "${icontrol}" ]  && cp -P "${icontrol}" "$(gettmpdirp)/ipatches.dat"
    [ -f "${control}" ]   && cp -P "${control}" "$(gettmpdirp)/patches.dat"
    [ -f "${blacklist}" ] && cp -P "${blacklist}" "$(gettmpdirp)/blacklist.dat"

    # Next line needed for release notes, unless we configure each profile to use a unique patches.dat which would be tedious
    [ -n "${PROFILE}" -a -f ${BIN}/latest.sh ] && cp ${control} "$(gettmpdirp)/patches.dat"
  else
    stash="$(gettmpdirp patch.stash clean)"

    if [ ${DOLSPATCHES} == Y ]; then
      ${BIN}/lsPatches.sh -iq ${PATCHCODE} ${PADDCODE} 2>&1
      [ $? -gt 1 ] && return 1
    fi
    
    args=
    [ "${BUILD_DETOOL_PATCHES}" == "no" ] && args+="-D "
    
    # Download latest commits to a temporary folder
    ${BIN}/getPatches.sh -P -b -T ${stash} ${args} || return 1

    [ -f "$(gettmpdirp)/ipatches.dat" ]  && cp "$(gettmpdirp)/ipatches.dat" "${icontrol}"
    [ -f "$(gettmpdirp)/patches.dat" ]   && cp "$(gettmpdirp)/patches.dat" "${control}"
    [ -f "$(gettmpdirp)/blacklist.dat" ] && cp "$(gettmpdirp)/blacklist.dat" "${blacklist}"

    tar czf "${patches}" -C "${stash}" .
    echo "${PROFILE}" >"${creator}"
    rm -fr "${stash}"
  fi

  # Apply commits to project
  if [ -n "${DEVICE}" ]; then
    patchdir="${BUILD_REPO_PATH}/projects/${PROJECT}/devices/${DEVICE}/patches"
  else
    patchdir="${BUILD_REPO_PATH}/projects/${PROJECT}/patches"
  fi
  mkdir -p ${patchdir}
  tar xzf "${patches}" -C ${patchdir}

  # Add tainted packages based on current patches
  settainteditems

  # Clean tainted packages
  cleanpackages || return 1

  return 0
}

settainteditems()
{
  local tainted
  tainted="$(${BIN}/getPatches.sh packages | tail -1)"
  addtainteditems ${tainted#*: }

  # Include items as tainted that usually need to be updated for a successful build
  #addtainteditems image busybox linux kodi
}

gettainteditems()
{
  echo "${CLEAN_ITEMS%?}"
}

resettainteditems()
{
  CLEAN_ITEMS=
}

cleanpackages()
{
  [ "${DONOTCLEAN}" == "Y" ] && return 0
  # Clean tainted packages
  ${BIN}/clean.sh $(gettainteditems) --sync
}

addtainteditems()
{
  local item
  for item in $*; do addtainteditem "${item}"; done
}

addtainteditem()
{
  local item
  [ "${1}" == "${BUILD_TYPE_REPO_NAME}" ] && return
  for item in ${CLEAN_ITEMS}; do
    [ "${item}" == "${1}" ] && return
  done
  CLEAN_ITEMS="${CLEAN_ITEMS}${1} "
}

getnewbuilddate()
{
  local CDATE="$(date +%y%m%d)"
  local BDATE lastbd lastbdch

  [ -f ${BIN}/.build ] && BDATE="$(awk '{print $1}' ${BIN}/.build)"

  if [ "${BDATE_ISCLEARED}" == "Y" -o -z "${BDATE}" ]; then
    BDATE="${CDATE}"
  elif [ "${BDATE_ISROLLED}" == "Y" ]; then
    lastbd="${BDATE:0:6}"
    lastbdch="${BDATE:6:1}"
[ "${lastbd}" == "170925" ] && CDATE="${lastbd}"
    if [ "${CDATE}" != "${lastbd}" ]; then
      BDATE="${CDATE}"
    else
      #BDATE="${lastbd}$(python -c "print(chr(ord(\"${lastbdch:-a}\")+1))")"
      BDATE="${lastbd}$(python -c "c=ord(\"${lastbdch:-a}\")+1; print(chr(c) if chr(c) <= 'z' else chr(c - 32 - 26))")"
    fi
  fi

  echo "--builddate ${BDATE}"
}

build_all()
{
  local profile result=0 numjobs
  local commsdir="$(gettmpdirg .global/pid_$$ clean)"
  local monfile="$(gettmpdirg .global)/build.profile.${MH_SESSION_GUID:0:7}"

  # Ensure the communication directory is removed on exit.
  # Being pid-based, these can proliferate due to build failure.
  trap "rm -fr ${commsdir}" EXIT

  rm -f ${commsdir}/build.fail

  echo -e "${PROFILE}\n${AUTOBUILD_PROFILES//,/ }" >"${monfile}"

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _build_one_image "${commsdir}" "${BUILD_LOG}" 1 1 || result=1
  else
    if [ "${AUTOBUILD_PARALLEL,,}" == "yes" ]; then
      build_concurrent_images "${commsdir}"
    else
      for profile in ${AUTOBUILD_PROFILES//,/ }; do
        executeasprofile ${profile} N _build_one_image "${commsdir}" "${BUILD_LOG}" 1 1 || break
      done
    fi
    [ -f ${commsdir}/build.fail ] && result=1
    loadconfig reload >/dev/null
  fi

  rm -fr ${commsdir}

  return ${result}
}

build_concurrent_images()
{
  local commsdir="${1}"
  local profile result=0 jobn=0 numjobs
  local blockfile="${commsdir}/build.wait"
  local readyfile="${commsdir}/build.ready"
  local maxidwidth=0
  local i

  BUILDARGS="${BUILDARGS} $(getnewbuilddate)"

  fixgetscript
  touch ${blockfile}
  rm -f ${readyfile}.*
  numjobs="$(echo "${AUTOBUILD_PROFILES//,/ }" | wc -w)"

  for profile in ${AUTOBUILD_PROFILES//,/ }; do [ ${#profile} -gt ${maxidwidth} ] && maxidwidth=${#profile}; done

  for profile in ${AUTOBUILD_PROFILES//,/ }; do
    jobn=$((jobn + 1))
    ( 
      executeasprofile ${profile} N _build_one_image "${commsdir}" "${BUILD_LOG}" ${numjobs} ${jobn} ${maxidwidth}
    ) &
    # Synchronise job startup - allow job to become "ready" before starting next job
    _waitforjobready $! ${readyfile}.${jobn}
  done

  # Release jobs
  rm -f ${blockfile}

  # ...and wait for all jobs to complete.
  wait

  # Cursor down past progress lines of all jobs...
  for (( i=0; i<${numjobs}; i++ )); do echo; done

  # Output completion status of each job
  for profile in ${AUTOBUILD_PROFILES//,/ }; do
    executeasprofile ${profile} N _showbuildstatus
  done

  return 0
}

_waitforjobready()
{
  local pidchild="${1}" readyfile="${2}" i

  for i in {1..60}; do
    kill -0 ${pidchild} 2>/dev/null || break
    [ -f "${readyfile}" ] && break
    sleep 0.25
  done
  return 0
}

_showbuildstatus()
{
  local commsdir="${1}"
  local statusfile="$(gettmpdirp)/build.status"
  local failfile="$(gettmpdirp)/build.fail"

  [ -f "${statusfile}" ] && cat "${statusfile}"

  [ -f "${failfile}" ] && return 1 || return 0
}

_build_one_image()
{
  local commsdir="${1}" mainlog="${2}" jobtotal="${3:-1}" jobindex="${4:-1}" maxidwidth="${5:0}"
  local bcode etime result
  local buildargs
  local buildlog="${BUILD_LOG}.job${jobindex}" 

  rm -f $(gettmpdirp)/.build $(gettmpdirp)/build.status 

  # If not pulling updates, then need to clean build directory here
  if [ ${PULLUPDATES} != Y ]; then
    # Add tainted packages based on current patches
    settainteditems
    # Clean tainted packages
    cleanpackages || return 1
    echo
  fi

  # When building in parallel, copy main log to temporary log
  # so that each build appends it's own log
  if [ -n "${mainlog}" -a -n "${buildlog}" ]; then
    cp "${mainlog}" "${buildlog}"
    buildargs="--log ${buildlog}"
  fi

  # If we're building more than one job, add the args needed when building multiple concurrent jobs
  [ ${jobtotal} -gt 1 ] && buildargs="${buildargs} --job ${jobindex} --jobtotal ${jobtotal} --jobidw ${maxidwidth}"
  
  [ "${BUILD_MKIMAGE,,}" == "yes" ] && buildargs="${buildargs} --mkimage" || buildargs="${buildargs} --noimage"

  touch $(gettmpdirp)/build.fail
  ${BIN}/build.sh -S "${commsdir}" -N ${BUILDARGS} ${buildargs}
  result=$?

  bcode="$(awk '{print $1}' $(gettmpdirp)/.build)"
  etime="$(awk '{print $2}' $(gettmpdirp)/.build)"

  if [ ${result} -eq 0  -a ! -f $(gettmpdirp)/build.fail ]; then
    notifyme SOUND_OK1 "Successful $(getbuildstr) build, #${bcode:2}. Elapsed time: ${etime}"
    return 0
  else
    touch ${commsdir}/build.fail
    [ -n "${buildlog}" ] && notifyme_with_log SOUND_ERR "${buildlog}" "Build failure: $(getbuildstr)"
    return 1
  fi
}

# Patch the tarball download script to avoid concurrent downloads, necessary when building in parallel
fixgetscript()
{
  local blocker tmpfile="$(gettmpdirp)/blocker"
  local getscript="${BUILD_REPO_PATH}/scripts/get"

  ${TGREP} "_isblocked=N" ${getscript} >/dev/null && return 0

  read -r -d '' blocker <<'EOF'
_isblocked=N
mkdir -p $SOURCES/$1
exec 99>$SOURCES/$1/.lock
while ! flock --nonblock --exclusive 99; do
  [ ${_isblocked} == N ] && { echo "Project ${PROJECT} waiting to avoid concurrent download of ${1}..."; _isblocked=Y; }
  sleep 1
done
EOF
  echo -e "${blocker}\n" >${tmpfile}

  # Insert blocker after recursive call to "$SCRIPTS/get $GET_PKG", which could deadlock...
  sed -i "/if \[ -n \"\$PKG_URL\" \]; then/ \
          {
          h
          r ${tmpfile}
          g
          N
          }" ${getscript}

  if ! ${TGREP} "_isblocked=N" ${getscript} >/dev/null; then
    # Alternate version of get script if PKG_SOURCE_NAME patch applied
    sed -i "/if \[ -n \"\$PKG_URL\" -a -n \"\$PKG_SOURCE_NAME\" \]; then/ \
            {
            h
            r ${tmpfile}
            g
            N
            }" ${getscript}
  fi

  rm -f ${tmpfile}
  return 0
}

# latest.sh is not available publically as it includes details of remote servers
# but basically it just uses scp to push the latest tar to a remote Pi, and/or uploads
# the same file to a remote server.
update_all()
{
  local profile result=0

  [ -x ${BIN}/latest.sh ] || return 0

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _update_one || result=1
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} N _update_one || result=1
      [ ${result} -eq 0 ] || qdie 1 "Error(s) while updating client, PROFILE=${profile}" 
    done
    loadconfig reload >/dev/null
  fi

  return ${result}
}

publish_all()
{
  local profile result=0

  [ -x ${BIN}/latest.sh ] || return 0

  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _publish_one || result=1
    [ ${result} -eq 0 ] && ${BIN}/latest.sh combine
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} N _publish_one || result=1
      [ ${result} -eq 0 ] || qdie 1 "Error(s) while publishing new build, PROFILE=${profile}"
    done
    ${BIN}/latest.sh combine ${AUTOBUILD_PROFILES}
    loadconfig reload >/dev/null
  fi

  return ${result}
}

remoteupload_all()
{
  local profile result=0
  local profiles=${REMOTE_UPLOAD_PROFILES:-${AUTOBUILD_PROFILES}}

  [ -x ${BIN}/latest.sh ] || return 0

  if [ -z "${profiles}" ]; then
    _remote_upload_one || result=1
  else
    for profile in ${profiles//,/ }; do
      if findinlist "${profile}" "${AUTOBUILD_PROFILES}"; then
        executeasprofile ${profile} N _remote_upload_one || result=1
        [ ${result} -eq 0 ] || qdie 1 "Error(s) while uploading new build to remote server, PROFILE=${profile}"
      fi
    done
    loadconfig reload >/dev/null
  fi

  return ${result}
}

_update_one()
{
  local bcode
  bcode="$(awk '{print $1}' $(gettmpdirp)/.build)"
  ${BIN}/latest.sh tarw 2>&1 && notifyme SOUND_OK2 "Build $(getbuildstr) #${bcode:2} updated on local system" || return 1
  return 0
}

_publish_one()
{
  if [ ${QUICKPUBLISH} == Y ]; then
    ${BIN}/latest.sh qpublish 2>&1 || return 1
  else
    ${BIN}/latest.sh publish 2>&1 || return 1
  fi

  return 0
}

_remote_upload_one()
{
  ${BIN}/latest.sh remote 2>&1 || return 1

  return 0
}

_get_profile_build_repo()
{
  local ctrlfile="${1}"

  if ! ${TGREP} -E "\|${BUILD_REPO_PATH}$" "${ctrlfile}" >/dev/null; then
    _lock_build_repo
    echo "${PROFILE}|${BUILD_REPO_PATH}" >> ${ctrlfile}
  fi

  return 0
}

check_multi_build()
{
  local profile
  local builddirs="$(gettmpdirp)/builddirs.dat"
  local pkgfilters="$(gettmpdirp)/pkgfilters.dat"
  local ctrlfile="$(gettmpdirp)/ctrlfile.dat"
  local line result=0

  [ "${AUTOBUILD_PARALLEL}" == "yes" -a -z "${AUTOBUILD_PROFILES}" ] && die 1 "Error: Profiles [${PROFILE}] needs AUTOBUILD_PROFILES!"

  # Lock build repo for the current profile if not an autobuild profile
  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    _lock_build_repo
    return 0
  fi

  echo "Checking autobuild profiles..."

  rm -fr "${builddirs}" "${pkgfilters}" "${ctrlfile}"
  touch "${builddirs}" "${pkgfilters}" "${ctrlfile}"

  # Determine unique build repo paths for all autobuild profiles, and lock each build repo path
  for profile in ${AUTOBUILD_PROFILES//,/ }; do
    executeasprofile ${profile} Y _get_profile_build_repo ${ctrlfile} || die 1 "Error: Multi-build profile [${profile}] is not valid"
  done

  while read -r line; do
    executeasprofile ${line%|*} Y check_multi_build_single "${builddirs}" "${pkgfilters}" "${AUTOBUILD_PROFILES}" || result=1
    [ ${result} -eq 1 ] && break
  done <<< "$(cat "${ctrlfile}")"

  rm -fr "${builddirs}" "${pkgfilters}" "${ctrlfile}"

  echo

  return ${result}
}

check_multi_build_single()
{
  local builddirs="${1}"
  local pkgfilters="${2}"
  local autobuild_profiles="${3}"
  local profile result=0 match
  local in_use_filters in_use_pkg_filters
  local BUILD_DIR="$(getoeoption "BUILD")"

  in_use_env_filters="$(_getusedfilters "${BUILD_ENV_CONTROL}" "${BUILD_ENV_FILTERS}")"

  for profile in ${autobuild_profiles//,/ }; do
    (
      # Get profile settings of another profile, prefix settings with "OTHER"
      eval "$(_getotherprofile "${profile}" "OTHER")"

      # Ignore profiles not for this build repo
      [ "${BUILD_REPO_PATH}" != "${OTHER_BUILD_REPO_PATH}" ] && continue

      # Check "other" profile against current multi-build profile
      _checkbuildtoken BUILD_ENV_CONTROL        || exit 1
      _checkbuildtoken BUILD_ENV_REPOS          || exit 1
      _checkbuildtoken BUILD_ENV_ADDON_REPOS    || exit 1
      _checkbuildtoken BUILD_ENV_BRANCHES       || exit 1
      _checkbuildtoken BUILD_ENV_ADDON_BRANCHES || exit 1
      _checkbuildtoken BUILD_ENV_STOCK_REPOS    || exit 1
      _checkbuildtoken BUILD_ENV_IGNORE_REPOS   || exit 1
      _checkbuildtoken BUILD_ANALYTICS_APPLY    || exit 1
      _checkbuildtoken BUILD_CONFLICTS_REMOVE   || exit 1

      _checkbuildtoken BUILD_ENV_FILTERS "${in_use_env_filters}" "$(_getusedfilters "${BUILD_ENV_CONTROL}" "${OTHER_BUILD_ENV_FILTERS}")" || exit 1

      match="$(${TGREP} -E "^.*: ${OTHER_BUILD_DIR}$" "${builddirs}")"
      [ -n "${match}" ] && qdie 1 "Error: Multi-build profile ${OTHER_PROFILE} has the same BUILD directory as $(echo "${match}" | awk '{ print $1 }') (${OTHER_BUILD_DIR})"
      echo "${OTHER_PROFILE}: ${OTHER_BUILD_DIR}" >>"${builddirs}"

      # Cannot build the same project with different package filters, but OK to do so when
      # the same filters are in use (as long as a different build directory is used - see previous match)
      in_use_pkg_filters="$(_getusedfilters "${OTHER_BUILD_PKG_CONTROL}" "${OTHER_BUILD_PKG_FILTERS}")"
      match="$(${TGREP} -E "^.*: ${OTHER_BUILD_REPO_PATH}/${OTHER_PROJECT} " "${pkgfilters}")"
      if [ -n "${match}" ]; then
        if [ "${match#*: }" != "${OTHER_BUILD_REPO_PATH}/${OTHER_PROJECT} ${in_use_pkg_filters}" ]; then
          qdie 1 "Error: Multi-build profile ${OTHER_PROFILE} has the same PROJECT but different package filters as $(echo "${match}" | awk '{ print $1 }') (${in_use_pkg_filters})"
        fi
      else
        echo "${OTHER_PROFILE}: ${OTHER_BUILD_REPO_PATH}/${OTHER_PROJECT} ${in_use_pkg_filters}" >>"${pkgfilters}"
      fi
      printf "  %-20s [OK]\n" "${profile}"
    ) || result=1
    [ ${result} -eq 0 ] || break
  done
  return ${result}
}

_getotherprofile()
{
  local profile="${1}" prefix="${2}" token
  loadprofile "${profile}" || die 1
  for token in PROFILE PROJECT ARCH BUILD_REPO_PATH BUILD_ENV_CONTROL BUILD_ENV_REPOS BUILD_ENV_ADDON_REPOS BUILD_ENV_FILTERS \
               BUILD_ENV_BRANCHES BUILD_ENV_ADDON_BRANCHES BUILD_ENV_STOCK_REPOS BUILD_ENV_IGNORE_REPOS \
               BUILD_ANALYTICS_APPLY BUILD_CONFLICTS_REMOVE BUILD_PKG_CONTROL BUILD_PKG_FILTERS; do
    echo "${prefix}_${token}=\"${!token}\""
  done
  echo "${prefix}_BUILD_DIR=\"$(getoeoption "BUILD")\""
}

_checkbuildtoken()
{
  local thistoken="${1}" othertoken="OTHER_${1}"
  local thisvalue="${!thistoken}" othervalue="${!othertoken}"

  [ -n "${2}" ] && thisvalue="${2}"
  [ -n "${3}" ] && othervalue="${3}"

  [ "${thisvalue}" == "${othervalue}" ] && return 0

  qdie 1 "Error: Multi-build profile ${OTHER_PROFILE} is using an incompatible ${thistoken} (current: [${thisvalue}], requested: [${othervalue}])"
}

# When multi-building, the environment filters only need to be the same for those
# filters that are actually being used.
# For example, filters "master" and "master debug" can be considered the same when
# there are no references to "=debug" in the environment control file.
_getusedfilters()
{
  local controllist="$(${TGREP} -E "^=" ${1} | awk '{ print $1 }' | tr -s '[=,!|]' '\n' | sort -u | tr '\n' ' ')"
  local filterlist="${2}"
  local usedlist filter

  controllist="$(trim "${controllist}")"

  for filter in ${filterlist}; do
    findinlist "${filter}" "${controllist}" && usedlist="${usedlist} ${filter}"
  done

  # Sort filters into same predictable/comparable order
  usedlist="$(echo "${usedlist:1}" | tr ' ' '\n' | sort -u | tr '\n' ' ')"

#  echo "USEDLIST: ${PROFILE}, [${filterlist}], [${controllist}], [$(trim ${usedlist})]" >&2

  trim "${usedlist}"
}

# Send stderr to stdout so both are logged
redirect_stderr()
{
  exec 3>&2  # Save stderr
  exec 2>&1  # Redirect stderr to stdout
}
# Temporarily restore stderr, for instance if we don't want progress meters logged
restore_stderr()
{
  exec 2>&3 3>&- # Restore stderr, close fd #3
}

usage()
{
  cat <<EOF
Usage: $(basename $0) [-f] [-R] [-b <repo>=<branch>] [-u] [-p] [-r] [-Q] [-U|-E] [-Z] [-B] [-L] [-O] [-N] [-C|-A <code>] [-9] [-D|-w] [-q] [-T]
Autobuild options:
    -f  Force a clean build, including clearing of ccache
    -R  Refresh all repositories
    -b  If required, switch branch for repo, repo=branch. Repeat for each repo.
    -u  Upload new tar to test client at end of build
    -p  Generate release notes for publication
    -r  Upload new tar to remote site
    -Q  Prompt for URL when publishing
    -U  Don't pull new updates from github and do not refresh any repositories
    -E  Don't pull new updates from github but do refresh repositories if required
    -B  Don't build new release
    -Z  Don't clean any packages (use with -U to avoid unecessary cleaning)
    -L  Don't run lsPatches.sh, only run getPatches.sh - useful when rebuilding an old build
    -O  Don't log autobuild output, only build (default is to log both)
    -N  Don't send notifications
    -C  Patch code(s) to filter when importing patches (lsPatches.sh)
    -A  Additional patch code(s) to be used when importing patches (oepull.sh, lsPatches.sh)
    -9  Do not renice the build processes, use default process priorities (increased performance)
Build options:
    -D  Do not increment build code at start of build, keep as-is
    -w  Wipe build code, so that it is reinitialised using todays date
    -q  Don't log the build
    -T  Test build (don't create image)
EOF
}

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

BRANCHES=
LOCAL_UPLOAD=N
PUBLISH=N
REMOTE_UPLOAD=N
REFRESH=No
REFRESH_REPOSITORIES=N
QUICKPUBLISH=Y
PULLUPDATES=Y
DONOTCLEAN=N
LOGAUTOBUILD=Y
NOTIFY=Y
DOBUILD=Y
DOLSPATCHES=Y
PATCHCODE=
PADDCODE=
CLEANBUILD=N
DO_NICE=Y

BUILDARGS=
GOTOPTS=N

BDATE_ISCLEARED=N
BDATE_ISROLLED=Y

while getopts ":9fRuprUEBZcQLNODwqThC:A:b::" opt; do
  GOTOPTS=Y
  case ${opt} in
    9) DO_NICE=N;;
    # Switch local repo branches, repo=branch
    b) BRANCHES="${BRANCHES} ${OPTARG}";;
    # Force a build even if no repo or patch changes detected (OBSOLETE)
    f) CLEANBUILD=Y;;
    # Refresh repos
    R) REFRESH=Yes;;
    # Call the script latest.sh to scp the most recent tar to the testing Pi
    u) LOCAL_UPLOAD=Y;;
    # Call the script latest.sh to generate release notes for publication
    p) PUBLISH=Y;;
    # Call the script latest.sh to upload the most recent tar for public access
    r) REMOTE_UPLOAD=Y;;
    # Prompt for url when publishing
    Q) QUICKPUBLISH=N;;
    # Don't pull new updates from github
    U) PULLUPDATES=N;;
    # Don't pull new updates from github
    E) PULLUPDATES=N; REFRESH_REPOSITORIES=Y;;
    # Don't build (actually a build opt as -X, but works better here)
    B) DOBUILD=N;;
    # Don't clean anything
    Z) DONOTCLEAN=Y;;
    # Don't pull new patches - get only current patches
    L) DOLSPATCHES=N;;
    # Don't log autobuild output, log only build (default is to log both)
    O) LOGAUTOBUILD=N;;
    # Don't send notifications (prowl etc.)
    N) NOTIFY=N; disable_notify;;
    # Patches to import (lsPatches.sh)
    C) PATCHCODE="${PATCHCODE}-C ${OPTARG// /,} ";;
    A) PADDCODE="${PADDCODE}-A ${OPTARG// /,} ";;
    # Don't create image (actually a build opt, but needed here)
    T) LOCAL_UPLOAD=N; PUBLISH=N; REMOTE_UPLOAD=N; BUILDARGS="${BUILDARGS}-${opt} ";;
    # Remove this scripts options before passing what remains (eg. -w) to build.sh
    D) BUILDARGS="${BUILDARGS}-${opt} "; BDATE_ISCLEARED=N; BDATE_ISROLLED=N;;
    w) BUILDARGS="${BUILDARGS}-${opt} "; BDATE_ISCLEARED=Y;;
    q) BUILDARGS="${BUILDARGS}-${opt} ";;
    h|*) usage; exit 1;;
  esac
done

[ "$*" != "" -a ${GOTOPTS} == N ] && usage && die 1 "Error: args must be prefixed with a hyphen/dash"

# Simplify logging...
if [ "${LOGAUTOBUILD}" == "Y" ]; then
  if [ -z "${_autobuild_logging_enabled}" ]; then
    export _autobuild_logging_enabled=Y
    rm -f ${BUILD_LOG}
    ${BIN}/${SELF} "$@" | tee --append ${BUILD_LOG}
    exit ${PIPESTATUS[0]}
  fi
fi

if [ ${DO_NICE} == Y ]; then
  [ -n "${AUTOBUILD_RENICE}" ] && ${AUTOBUILD_RENICE} >/dev/null
  [ -n "${AUTOBUILD_IONICE}" ] && ${AUTOBUILD_IONICE} >/dev/null
fi

echo "Starting autobuild [$@]: $(date)"

# Switch branches based on profile configuration
[ -z "${BRANCHES}" ] && BRANCHES="${BUILD_ENV_BRANCHES} ${BUILD_ENV_ADDON_BRANCHES}"

# Check we can build all profiles
check_multi_build || die 1 "Error: Multi-build profile is not valid"

# Initialise here for use later
AUTOBUILD_CONFIG_INIT="Start Date: $(date)
Profile   : ${PROFILE}
Autobuild : ${AUTOBUILD_PROFILES}
Arguments : [$@]"

if [ ${DOBUILD} == Y -a ${CLEANBUILD} == Y ]; then
  # Clean .ccache_dir and build directories
  clean_builds || die 1 "Failure during clean: $(getbuildstr)"
fi

if [ ${PULLUPDATES} == Y ]; then
  # Optionally refresh repositories including build repo, pulling updates if required
  update_repositories Y || die

  # Download latest commits
  get_patches || die 1 "Error(s) while obtaining patches"
elif [ ${REFRESH_REPOSITORIES=N} == Y ]; then
  # Refresh repositories, but not build repo
  update_repositories N || die
fi

if [ ${DOBUILD} == Y ]; then
  # Build image(s)
  build_all || die 1 "Build failure: $(getbuildstr)"
fi

if [ ${LOCAL_UPLOAD} == Y ]; then
  update_all  || die 1 "Update failure: $(getbuildstr)"
fi

if [ ${PUBLISH} == Y ]; then
  publish_all || die 1 "Publish failure: $(getbuildstr)"
fi

if [ ${REMOTE_UPLOAD} == Y ]; then
  remoteupload_all || die 1 "Remote update failure: $(getbuildstr)"
fi
