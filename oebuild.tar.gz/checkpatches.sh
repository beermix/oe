#!/bin/bash
#
# Verify patches apply cleanly against an build repo source package.
#
BIN=$(readlink -f $(dirname $0))
[ -f "${BIN}/functions" ] && source ${BIN}/functions

on_exit_trap()
{
  [ ${KEEPUNPACK} == N -a -d "${TMPDIR}" ] && rm -fr ${TMPDIR}
  [ -f ${PACKAGEROOT}/package.mk.check ] && mv ${PACKAGEROOT}/package.mk.check ${PACKAGEROOT}/package.mk
}

process_all_packages()
{
  local package package_name
  local dpdir
  
  [ -n "${DEVICE}" ] && dpdir=${BUILD_REPO_PATH}/projects/${PROJECT}/devices/${DEVICE}/patches || dpdir=${BUILD_REPO_PATH}/projects/${PROJECT}/patches

  refresh_patches

  if [ -d ${dpdir} ]; then
    for package in $(find ${dpdir} -mindepth 1 -maxdepth 1 | sort); do
      package_name="$(basename "${package}")"
      echo $0 ${@} -p "${package_name}"
      if [ ${PATCHALL} == N ]; then
        $0 ${@} -p "${package_name}" || die 1 "ERROR: Verify failed for package ${package_name}"
      else
        $0 ${@} -p "${package_name}"
      fi
      refresh=
    done
  else
    warn "ERROR: No project patches directory found - refresh patches!"
  fi
}

process_patches()
{
  local action="${1}" PKG_NAME="${2}" PKG_DIR="${3}" UNPACKED="${4}" PKG_PROJECT PKG_ARCH PKG_VERSION PATCH_DESC PATTERN i count=0 total=0
  local TARGET_ARCH PATCH_ARCH PROJECT_DIR PATCH_DIRS_PKG PATCH_DIRS_PRJ pkg_dir patch_dir

  PKG_VERSION="$(getoepkgoption "${PKG_DIR}" PKG_VERSION)" || die 1 "ERROR: PKG_VERSION is not known"
  PKG_PROJECT="$(getoepkgoption "${PKG_DIR}" PROJECT)" || die 1 "ERROR: PROJECT is not known"
#  PKG_ARCH="$(getoepkgoption "${PKG_DIR}" ARCH)" || die 1 "ERROR: ARCH is not known"
  PKG_PATCH_DIRS="$(getoepkgoption "${PKG_DIR}" PKG_PATCH_DIRS)"

  TARGET_ARCH="$(getoeoption TARGET_ARCH)" || die 1 "ERROR: TARGET_ARCH is not known"
  PROJECT_DIR="$(getoepkgoption "${PKG_DIR}" PROJECT_DIR)" || die 1 "ERROR: PROJECT_DIR is not known"

  if [ "$TARGET_ARCH" = "x86_64" ]; then
    PATCH_ARCH="x86"
  else
    PATCH_ARCH="${TARGET_ARCH}"
  fi

  PATCH_DIRS_PKG=""
  PATCH_DIRS_PRJ=""
  if [ -n "$PKG_PATCH_DIRS" ]; then
    for patch_dir in $PKG_PATCH_DIRS; do
      [ -d $PKG_DIR/patches/$patch_dir ] && PATCH_DIRS_PKG="$PATCH_DIRS_PKG $PKG_DIR/patches/$patch_dir"
      [ -d $PROJECT_DIR/$PROJECT/patches/$PKG_NAME/$patch_dir ] && PATCH_DIRS_PRJ="$PATCH_DIRS_PRJ $PROJECT_DIR/$PROJECT/patches/$PKG_NAME/$patch_dir"
    done
  fi

  for i in $PKG_DIR/patches \
           $PKG_DIR/patches/$PATCH_ARCH \
           $PATCH_DIRS_PKG \
           $PKG_DIR/patches/$PKG_VERSION \
           $PKG_DIR/patches/$PKG_VERSION/$PATCH_ARCH \
           $PROJECT_DIR/$PROJECT/patches/$PKG_NAME \
           $PROJECT_DIR/$PROJECT/patches/$PKG_NAME/$PATCH_ARCH \
           $PATCH_DIRS_PRJ \
           $PROJECT_DIR/$PROJECT/patches/$PKG_NAME/$PKG_VERSION \
           $PROJECT_DIR/$PROJECT/devices/$DEVICE/patches/$PKG_NAME; do

    [ -d ${i} ] || continue

    case "${i}" in
      $PKG_DIR/patches)
        PATCH_DESC="Package patches";          PATTERN="${PKG_NAME}-*.patch";;
      $PKG_DIR/patches/$PATCH_ARCH)
        PATCH_DESC="Package patches/arch";     PATTERN="${PKG_NAME}-*.patch";;
      $PKG_DIR/patches/$PKG_VERSION|$PKG_DIR/patches/*)
        PATCH_DESC="Package patches/version";  PATTERN="*.patch";;
      $PKG_DIR/patches/$PKG_VERSION/$PATCH_ARCH)
        PATCH_DESC="Package patches/ver/arch"; PATTERN="*.patch";;
      $PROJECT_DIR/$PROJECT/patches/$PKG_NAME)
        PATCH_DESC="Project patches";          PATTERN="*.patch";;
      $PROJECT_DIR/$PROJECT/patches/$PKG_NAME/$PATCH_ARCH)
        PATCH_DESC="Project patches/arch";     PATTERN="*.patch";;
      $PROJECT_DIR/$PROJECT/patches/$PKG_NAME/$PKG_VERSION|$PROJECT_DIR/$PROJECT/patches/$PKG_NAME/*)
        PATCH_DESC="Project patches/version";  PATTERN="*.patch";;
      $PROJECT_DIR/$PROJECT/devices/$DEVICE/patches/$PKG_NAME)
        PATCH_DESC="Project patches/device";   PATTERN="*.patch";;
    esac

    count=$(ls -1 ${i}/${PATTERN} 2>/dev/null | wc -l)
    [ ${count} -ne 0 ] || continue
    total=$((total + count))
    case ${action} in
      stats) printout "${PATCH_DESC}" "$(printf "%3d" ${count}) (${i/${BUILD_REPO_PATH}\//}/${PATTERN})";;
      apply) apply_patches "${UNPACKED}" "${i}" "${PATTERN}" "${count}" || return 1;;
    esac
  done
  [ "${action}" == "count" ] && echo ${total}
  return 0
}

# Return the list of files to be deleted/modified by a patch
getfilesinpatch()
{
  local unpackdir="${1}" patch="${2}" files=()

  # Files to be deleted...
  while read -r file; do
    [ -z "${file}" -o ! -f "${unpackdir}/${file}" ] && continue
    files+=(${file})
  done <<<"$(${TGREP} -B1 "^+++ /dev/null" ${patch} | ${TGREP} -E "^--- [^/][^/]*/" | cut -d/ -f2- | cut -d' ' -f1)"

  # Files to be created/modified...
  while read -r file; do
    [ -z "${file}" -o ! -f "${unpackdir}/${file}" ] && continue
    files+=(${file})
  done <<<"$(${TGREP} "^+++ [^/][^/]*/" ${patch} | cut -d/ -f2- | cut -d' ' -f1)"

  # Binary files to be created/modified...
  while read -r file; do
    [ -z "${file}" -o ! -f "${unpackdir}/${file}" ] && continue
    files+=(${file})
  done <<<"$(${TGREP} -B3 "^GIT binary patch" ${patch} | awk '/^diff --git/ {print $4}' | cut -d/ -f2-)"

  printf "%s\n" "${files[@]}" | sort -u
}

clear_orig_files()
{
  rm -fr ${TMPDIR}/backup.tar.gz
}

# Backup original files that will be deleted or modified by a patch
backup_orig_files()
{
  local unpackdir="${1}" patch="${2}" files
  files="$(getfilesinpatch "${unpackdir}" "${patch}")"
  [ -n "${files}" ] && tar czf ${TMPDIR}/backup.tar.gz -C "${unpackdir}" ${files}
}

# Delete files that will be created or modified by a patch, and restore the original files
restore_orig_files()
{
  local unpackdir="${1}" patch="${2}" file files
  if [ -f ${TMPDIR}/backup.tar.gz ]; then
    while read -r file; do
      [ -n "${file}" ] && rm -f "${unpackdir}/${file}"
    done <<< "$(getfilesinpatch "${unpackdir}" "${patch}")"
    tar xzf ${TMPDIR}/backup.tar.gz -C "${unpackdir}"
  fi
}

apply_patches()
{
  local unpacked="${1}" patchdir="${2}" pattern="${3}" count="${4}" pdir="${2/${BUILD_REPO_PATH}\//}"
  local result output outputiws count patch c
  local iws iws_required needcr=N

  [ -z "${patchdir}" ] && return 0

  c=0
  for patch in ${patchdir}/${pattern}; do
    c=$((c+1))
    needcr=Y
    printf "%-24s: %3d of %3d\r" "Patching ${pdir//\/*/}..." ${c} ${count} >&2
    if [ -f "${patch}" ]; then
      iws_required=N
      if [ ${IGNOREWHITESPACE} == Y ]; then
        backup_orig_files "${unpacked}" "${patch}"
        output="$(apply_patch "${unpacked}" "${patch}" N)"
        result=$?
        if [ ${result} -ne 0 ]; then
          iws_required=Y
          restore_orig_files "${unpacked}" "${patch}"
          outputiws="$(apply_patch "${unpacked}" "${patch}" Y)"
          result=$?
        fi
        clear_orig_files
      else
        output="$(apply_patch "${unpacked}" "${patch}" N)"
        result=$?
      fi
      if [ ${result} -ne 0 ]; then
        echo >&2
        printout "Patching failed" "${patch}"
        echo "========================================================"
        echo "${output}"
        echo "========================================================"
        PATCH_ERROR=$((PATCH_ERROR + 1))
        [ "${PATCHALL}" == "N" ] && return 1
        needcr=N
      elif [ ${iws_required} == Y ]; then
        echo
        printout "WHITESPACE WARNING" "${patch}"
        echo "${TXYELLOW}Whitespace issues prevent patch from applying cleanly!${TXRESET}"
        echo "========================================================"
        echo "${output}"
        echo "========================================================"
        needcr=N
      fi
    fi
  done
  [ ${needcr} == Y ] && echo >&2
  return 0
}

apply_patch()
{
  local patchdir="${1}" patchfile="${2}" ignorewhitespace="${3:-N}" result dr iws

  if ${TGREP} -qE '^GIT binary patch$|^rename from .*|^rename to .*' ${patchfile}; then
    [ "${ignorewhitespace}" == "Y" ] && iws="--ignore-whitespace"
    output="$(cat ${patchfile} | git apply --directory="${patchdir}" -p1 --verbose --whitespace=nowarn ${iws} ${WITH_UNSAFE_PATHS} 2>&1)"
  else
    [ "${ignorewhitespace}" == "Y" ] && iws="--ignore-whitespace"
    output="$(cat ${patchfile} | patch -d "${patchdir}" -p1 ${iws})"
  fi
  result=$?
  echo "${output}"
  return ${result}
}

download_tarball()
{
  local pname="${1}" ppath="${2}" purl="${3}" psha="${4}"
  local bytes fbytes
  local pdir="$(dirname "${ppath}")"
  local isgithub=N calcsha

  if [ -n "${psha}" -a -f "${ppath}.sha256" ]; then
    if [ "$(cat "${ppath}.sha256")" != "${psha}" ]; then
      echo "WARNING: Removing current files, checksum mismatch - downloading new files"
      rm -f ${ppath}*
    fi
  fi

  [ -f "${ppath}" ] && return 0
  [ -d "${pdir}" ] || mkdir -p "${pdir}"

  rm -f "${TMPDIR}/tarball.tmp"

  [[ "${purl}" =~ http.*://*github\.com/.* ]] && isgithub=Y

  if [[ ${purl} =~ ^ftp:// ]]; then
    bytes="$(curl -sfIL "${purl}" | tr -d '\r' | ${TGREP} "^Content-Length:" | awk '{print $2}')"
  elif [ ${isgithub} == N ]; then
    bytes="$(curl -sfIL "${purl}" | tr -d '\r' | ${TGREP} -A20 -EA999 "^HTTP/.* 200 OK$")"
    if [ -n "${bytes}" ]; then
      bytes="$(echo "${bytes}" | ${TGREP} "^Content-Length:" | awk '{print $2}')"
    else
      purl="http://sources.libreelec.tv/mirror/${pname}/$(basename "${purl}")"
      bytes="$(curl -sfIL "${purl}" | tr -d '\r' | ${TGREP} -A20 -EA999 "^HTTP/.* 200 OK$" | ${TGREP} "^Content-Length:" | awk '{print $2}')"
      [ -n "${bytes}" ] || return 1
    fi
  fi

  if [ -n "${bytes}" ]; then
    fbytes="$(python -c "print(format(${bytes}, ',d'))")"
    curl -sfL "${purl}" -o - | pv -s ${bytes} -N "Downloading tarball...  : ${fbytes} bytes $(basename "${ppath}")" >"${TMPDIR}/tarball.tmp"
  else
    curl -sfL "${purl}" -o - | pv -N "Downloading tarball...  : ${fbytes} bytes $(basename "${ppath}")" >"${TMPDIR}/tarball.tmp"
  fi
  [ ${PIPESTATUS[0]} -eq 0 ] || return 1

  calcsha="$(sha256sum "${TMPDIR}/tarball.tmp" | cut -d" " -f1)"
  # If $REVISION then we're using an alternative version to what is in the package
  if [ -n "${REVISION}" ]; then
    echo -e "${TXYELLOW}Calculated sha256       : ${calcsha} (for revision ${REVISION})${TXRESET}"
  elif [ $IGNORE_CHECKSUM = Y ]; then
    echo -e "${TXYELLOW}Calculated sha256       : ${calcsha} (validation disabled)${TXRESET}"
  else
    if [ -n "${psha}" -a "${calcsha}" != "${psha}" ]; then
      echo -e "${TXRED}ERROR${TXRESET}: checksum mismatch - got ${calcsha}, wanted ${psha}" >&2
      return 1
    fi
  fi

  mv "${TMPDIR}/tarball.tmp" "${ppath}"
  echo "${purl}" >"${ppath}.url"
  [ "$IGNORE_CHECKSUM" = N ] && echo "${calcsha}" >"${ppath}.sha256"

  echo "New calculated sha256...: ${calcsha}" >&2

  return 0
}

unpack()
{
  local tarball="${1}" packagelabel="${2}" packagemk="${3}"
  local arch_type="tar"
  local filename extension unpacked compression count=

  filename="${tarball/*\//}"
  extension="${tarball/*./}"

  case "${extension}" in
    xz)  compression=J;;
    bz2) compression=j;;
    gz)  compression=z;;
    tgz) compression=z;;
    zip) arch_type="zip";;
    run) arch_type="run";;
    *)  warn "ERROR: Need to add support for tarball type ${extension}" >&2; return 1;;
  esac

  if [ ${QUICKUNPACK} == N -a ! "${arch_type}" == "run" ]; then
    printout "Analysing tarball..." "${filename}\r" >&2
    if [ "${arch_type}" == "tar" ]; then
      count="-s $(tar tvf${compression} "${tarball}" | wc -l)"
    else
      count="-s $(unzip -l "${tarball}" | wc -l)"
    fi
  fi

  dountar "${arch_type}" "${tarball}" "${compression}" "${packagemk}" "${packagelabel}" | pv -lN "Unpacking tarball...    : ${filename}" ${count} 1>/dev/null

  [ -d ${TMPDIR}/${packagelabel} ] && echo "${TMPDIR}/${packagelabel}" && return 0

  return 1
}

# Use package unpack if available, otherwise perform a standard untar
dountar()
{
  local arch_type="${1}" tarball="${2}" compression="${3}" packagemk="${4}" packagelabel="${5}"
  local pkg_name=$(basename $(dirname ${packagemk}))

  rm -f ${TMPDIR}/.selfunpack

  if [ -f "${packagemk}" ]; then
    (
      unset unpack
      cd ${BUILD_REPO_PATH}
      source ./config/options ${pkg_name} 2>/dev/null

#      source "${packagemk}" 2>/dev/null
      if [ "$(type -t unpack)" == "function" ]; then
        ROOT="${TMPDIR}"
        PKG_BUILD="$(basename ${PKG_BUILD})"
        SOURCES="sources"
        BUILD="."
        mkdir -p ${ROOT}/${SOURCES}/${PKG_NAME}
        cp "${tarball}" ${ROOT}/${SOURCES}/${PKG_NAME}

        cd ${ROOT}
        if unpack >&2; then
          touch ${TMPDIR}/.selfunpack
#          if [ -n "${PKG_SOURCE_DIR}" ]; then
#            find  ${ROOT}/${BUILD}/${PKG_SOURCE_DIR}
#          else
#            find  ${ROOT}/${BUILD}/${PKG_NAME}-${PKG_VERSION}
#          fi
          find  ${ROOT}/${BUILD}/${packagelabel}
        fi
        rm -fr ${ROOT}/${SOURCES}
      fi
    )
    [ -f ${TMPDIR}/.selfunpack ] && return
  fi

  if [ "${arch_type}" == "tar" ]; then
    tar xvf${compression} "${tarball}" -C "${TMPDIR}"
  else
    unzip -q "${tarball}" -d "${TMPDIR}"
  fi

  if [ -f "${packagemk}" ]; then
    (
      cd ${BUILD_REPO_PATH}
      source ./config/options ${pkg_name}

      ROOT=
      BUILD="${TMPDIR}"
      PKG_BUILD="${BUILD}/${packagelabel}"

      source "${packagemk}" 2>/dev/null

      if [ ! -d $TMPDIR/$PKG_NAME-$PKG_VERSION ]; then
        if [ -n "${PKG_SOURCE_DIR}" ]; then
          mv ${TMPDIR}/${PKG_SOURCE_DIR} $TMPDIR/$PKG_NAME-$PKG_VERSION
        elif [ -d $TMPDIR/$PKG_NAME-$PKG_VERSION* ]; then
          mv $TMPDIR/$PKG_NAME-$PKG_VERSION* $TMPDIR/$PKG_NAME-$PKG_VERSION
        fi
      fi

      if [ -d "$PKG_DIR/sources" ]; then
        [ ! -d "${BUILD}/${packagelabel}" ] && mkdir -p ${BUILD}/${packagelabel}
        cp -PRf ${PKG_DIR}/sources/* ${BUILD}/${packagelabel}
      fi

      if [ "$(type -t post_unpack)" = "function" ]; then
        post_unpack
      fi
    )
  fi
}

refresh_patches()
{
  local getargs
  
  [ "${AUTOBLACKLIST}" == "N" ] && getargs="-gd"

  if [ ${REFRESHPATCHES} == Y -a -x ${BIN}/lsPatches.sh -a -x ${BIN}/getPatches.sh ]; then
    ${BIN}/lsPatches.sh -iq ${PATCHCODE} ${PADDCODE}
    [ $? -gt 1 ] && return 1
    ${BIN}/getPatches.sh -b ${getargs} || return 1
  fi
  return 0
}

printout()
{
  if [ "${2: -2}" == "\r" ]; then
    printf "%-24s: %s\r" "$1" "${2:0:-2}"
  else
    printf "%-24s: %s\n" "$1" "$2"
  fi
}

usage()
{
  cat <<EOF
Usage: $(basename $0) [-p package | -V] [-g] [-D path] [-B path] [-R ver] [-a] [-d] [-u|-k|-U] [-I] [-w] [-r] [-q] [-C|-A patchcode] [-K] [-G] [-h]
$(basename $0) options:
    -p  Name of package and associated patches to be checked, eg. kodi, linux, libcec, gcc etc.
    -g  Disable autoblacklist by applying -gd when calling getPatches.sh
    -V  Verify all packages that have project patches
    -D  Directory path (relative to /package) of package folder, ie. -D lang/Python (only needed if auto-detect fails)
    -B  Path for base repo, default ${BUILD_REPO_PATH}
    -R  Revision to be used for package - disables sha256 checksum verification, show checksum of new file
    -a  Apply all patches - do not stop after first patch failure
    -d  Download tarball into sources cache if not already available
    -u  Unpack only - don't apply any patches (implies -k)
    -k  Keep unpacked directory after exiting (${TMPDIR})
    -U  Don't unpack, download only (if specified)
    -I  Don't validate sha256 checksum
    -w  Don't re-try patching with --ignorewhitespace enabled if patch fails to apply normally
    -r  Refresh patches (lsPatches.sh/getPatches.sh) before unpacking
    -q  Quicker unpack - don't count number of files in tarball
    -C  Patchcode(s) when filtering commits/imports
    -A  Additional patchcode(s) to be used when filtering commits/imports
    -K  Keep (don't clear) unpack directory. Implies -k
    -G  Run git init/git add -A/git commit -am "init" on unpacked package. Implies -k.
    -h  This message
EOF
}

TMPDIR="${BIN}/.unpack"

COUNT=0
PACKAGE=
PATCHALL=N
DOWNLOAD=N
UNPACKONLY=N
DONTUNPACK=N
KEEPUNPACK=N
REFRESHPATCHES=N
AUTOBLACKLIST=Y
QUICKUNPACK=N
IGNOREWHITESPACE=Y
PACKAGEROOT=
PATCH_ERROR=0
PATCHCODE=
PADDCODE=
VERIFY_ALL=N
SHOW_INFO=N
GITINIT=N
KEEPCONTENTS=N
ALL_ARGS=
REVISION=
IGNORE_CHECKSUM=N

GOTOPTS=N
while getopts ":p:ghadwukUIrqKGVSD:C:A:R:B:" opt; do
  GOTOPTS=Y
  case ${opt} in
    g) AUTOBLACKLIST=N;;
    V) VERIFY_ALL=Y;;
    S) SHOW_INFO=Y;;
    p) PACKAGE=${OPTARG};;
    D) PACKAGEROOT=${OPTARG};;
    B) BUILD_REPO_PATH=${OPTARG};;
    a) ALL_ARGS="${ALL_ARGS}-${opt} "; PATCHALL=Y;;
    d) ALL_ARGS="${ALL_ARGS}-${opt} "; DOWNLOAD=Y;;
    w) ALL_ARGS="${ALL_ARGS}-${opt} "; IGNOREWHITESPACE=N;;
    u) UNPACKONLY=Y; KEEPUNPACK=Y;;
    k) KEEPUNPACK=Y;;
    U) DONTUNPACK=Y;;
    I) IGNORE_CHECKSUM=Y;;
    r) REFRESHPATCHES=Y;;
    R) REVISION=${OPTARG};;
    q) ALL_ARGS="${ALL_ARGS}-${opt} "; QUICKUNPACK=Y;;
    C) PATCHCODE="${PATCHCODE}-C ${OPTARG// /,} ";;
    A) PADDCODE="${PADDCODE}-A ${OPTARG// /,} ";;
    K) KEEPCONTENTS=Y; KEEPUNPACK=Y;;
    G) GITINIT=Y; KEEPUNPACK=Y;;
    h) usage && exit 0;;
    ?) usage && die 1 "ERROR: Unknown argument [${OPTARG}]"
  esac  
done

[ -n "${PACAKGEROOT}" ] && PACKAGEROOT="${BUILD_REPO_PATH}/packages/${PACKAGEROOT}"

[ "$*" != "" -a ${GOTOPTS} == N ] && usage && die 1 "ERROR: args must be prefixed with a hyphen/dash"

[ "${REFRESHPATCHES}" == "Y" -o -n "${REVISION}" ] && _lock_build_repo

if [ ${VERIFY_ALL} == Y -a -z "${PACKAGE}" ]; then
  process_all_packages ${ALL_ARGS}
  exit 0
fi

[ -n "${PACKAGE}" ] || die 1 "ERROR: A valid package name must be specified"

trap "on_exit_trap" EXIT

#See https://github.com/git/git/commit/c536c0755 for --unsafe-paths requirement
[ -n "$(git apply --help| ${TGREP} " --unsafe-paths")" ] && WITH_UNSAFE_PATHS="--unsafe-paths"

[ ${KEEPCONTENTS} == N ] && rm -fr ${TMPDIR}
mkdir -p ${TMPDIR}

if [ -z "${PACKAGEROOT}" ]; then
  PACKAGEROOT="$(find ${BUILD_REPO_PATH}/packages -type f -name package.mk | ${TGREP} "/${PACKAGE}/package.mk")"
  [ -n "${PACKAGEROOT}" ] && PACKAGEROOT="$(dirname "${PACKAGEROOT}")"
fi

[ -n "${PACKAGEROOT}" ] || die 1 "ERROR: Package [${PACKAGE}] not found"

if [ -n "${REVISION}" ]; then
  PACKAGEVER="${REVISION}"
  cp ${PACKAGEROOT}/package.mk ${PACKAGEROOT}/package.mk.check
  sed -i "s/PKG_VERSION=.*/PKG_VERSION=\"${PACKAGEVER}\"/" ${PACKAGEROOT}/package.mk
fi

PACKAGEVER="$(getoepkgoption "${PACKAGEROOT}" PKG_VERSION)" || die 1 "ERROR: PKG_VERSION is not known"
PACKAGEURL="$(getoepkgoption "${PACKAGEROOT}" PKG_URL)"     || die 1 "ERROR: PKG_URL is not known"
PACKAGESHA="$(getoepkgoption "${PACKAGEROOT}" PKG_SHA256)"
PACKAGESRCDIR="$(getoepkgoption "${PACKAGEROOT}" PKG_SOURCE_DIR)"
PACKAGESRCNAME="$(getoepkgoption "${PACKAGEROOT}" PKG_SOURCE_NAME)"

if [ ${SHOW_INFO} == Y ]; then
  printout "Package name" "${PACKAGE}"
  printout "Package version" "${PACKAGEVER}"
  printout "Download URL" "${PACKAGEURL}"
  printout "Package SHA" "${PACKAGESHA}"
  exit 0
fi

#[ -n "${PACKAGESRCDIR}" ] && PACKAGELABEL="${PACKAGESRCDIR}" || PACKAGELABEL="${PACKAGE}-${PACKAGEVER}"
PACKAGELABEL="${PACKAGE}-${PACKAGEVER}"
[ -n "${PACKAGESRCNAME}" ] && TARBALL="${BUILD_REPO_PATH}/sources/${PACKAGE}/${PACKAGESRCNAME}" || TARBALL="${BUILD_REPO_PATH}/sources/${PACKAGE}/${PACKAGEURL//*\//}"

if [ ${DOWNLOAD} == Y ]; then
  download_tarball "${PACKAGE}" "${TARBALL}" "${PACKAGEURL}" "${PACKAGESHA}"
  if [ ! -f "${TARBALL}" ]; then
    warn  "ERROR: Download [${PACKAGEURL}] has failed"
    die 1 "ERROR: Tarball [${TARBALL}] not found"
  fi
elif [ ! -f "${TARBALL}" ]; then
  die "ERROR: Tarball [${TARBALL}] not found - specify -d to attempt download"
fi
TARBALLMOD="$(date --date=@$(stat -c%Y "${TARBALL}") "+%a, %d-%b-%Y %H:%M:%S")"
printout "Source tarball" "${TARBALL/${BUILD_REPO_PATH}\//} (${TARBALLMOD})"

[ ${DONTUNPACK} == Y ] && exit 0

refresh_patches || die 1 "ERROR: Refreshing patches failed"

process_patches stats "${PACKAGE}" "${PACKAGEROOT}"

[ $(process_patches count "${PACKAGE}" "${PACKAGEROOT}") -ne 0 -o ${UNPACKONLY} == Y -o ${KEEPUNPACK} == Y ] || die 0 "No patches to be applied, quitting"

UNPACKED="$(unpack "${TARBALL}" "${PACKAGELABEL}" "${PACKAGEROOT}/package.mk")" || die "Unpacked source code for package [${PACKAGELABEL}] not found"

printout "Unpack directory" "${UNPACKED}"

if [ ${UNPACKONLY} == N ]; then
  process_patches apply "${PACKAGE}" "${PACKAGEROOT}" "${UNPACKED}"
  [ ${PATCH_ERROR} -eq 1 ] && die 1 "WARNING: ${PATCH_ERROR} patch failed to apply cleanly"
  [ ${PATCH_ERROR} -ge 2 ] && die 1 "WARNING: ${PATCH_ERROR} patches failed to apply cleanly"
  echo
  echo "ALL PATCHES APPLIED SUCCESSFULLY"
fi

if [ ${GITINIT} == Y ]; then
  cd $UNPACKED || die "Unable to enter unpacked dir [${UNPACKED}]"
  git init . && git add -A && git commit -am "init" >/dev/null
fi

exit 0
