#!/bin/bash

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

_lock_build_repo

BUILD_DIR="$(getoeoption "BUILD")" || die
BUILD_SUFFIX="$(getoeoption "BUILD_SUFFIX")" || die

[ -n "$(getoepkgoption kodi-theme-Estuary PKG_URL)" ] && POST_PR1080=N || POST_PR1080=Y

# Hack, while Helix doesn't support build suffix
[ -n "${BUILD_SUFFIX}" ] && BUILD_DIR="${BUILD_DIR%-${BUILD_SUFFIX}}-${BUILD_SUFFIX}"

_is_valid_package()
{
  source config/options $1 &>/dev/null
  [ -n "${PKG_DIR}" ] && return 0 || return 1
}

_get_pkg_name()
{
  (
    is_valid_package $1 || return 1
    echo $PKG_NAME
  )
}

_find_build_folder()
{
  local pkg dir without_ver matchedpkg

#  local pkg_name
#  (
#    if _is_valid_package $1; then
#      echo "$PKG_NAME,$PKG_VERSION"
#    else
#      echo "$PKG_NAME,"
#    fi
#  )
#  return 0

  for dir in ${BUILD_DIR} ${BUILD_DIR}/.stamps ${BUILD_DIR}/image/.stamps ${BUILD_DIR}/addons; do
    if [ -d "${dir}" ]; then
      while read -r matchedpkg; do
        [ -n "${matchedpkg}" ] || continue
        pkg="$(basename ${matchedpkg})"
        without_ver="${pkg}"
        while [[ ${without_ver} =~ .*-.* ]]; do
          without_ver="${without_ver%-*}"
          if _is_valid_package "${without_ver}"; then
            [ "${without_ver}" == "${1}" ] || break
            echo "${without_ver},${pkg/${without_ver}-/}"
            return 0
          fi
        done
      done <<< "$(find ${dir} -maxdepth 1 -type d -name "${1}*" | sort)"
    fi
  done

  echo "${1},"
  return 1
}

checkcleandirty()
{
  local checktype="${1}" pkgargs="${2}"
  local pkgname packages status i found timestamp status_extra sourceok

  ALWAYSDIRTY=N

  if [ -n "${pkgargs}" ]; then
    packages="$(echo "${pkgargs}" | tr ' ' '\n' | sort -u --ignore-case)"
  else
    packages="$(getpackages | awk '{print $3}' | sort --ignore-case)"
  fi

  while read -r pkgname; do
    [ -z "${pkgname}" ] && continue
    found=N
    for i in ${BUILD_DIR}/${pkgname}-*; do
      [ -d ${i} -a -f "${i}/.libreelec-unpack" ] || continue
      . "${i}/.libreelec-unpack"
      if [ "${STAMP_PKG_NAME}" == "${pkgname}" ]; then
        found=Y
        status=DIRTY
        status_extra=
        if [ -d ${BUILD_REPO_PATH}/sources/${pkgname} ]; then
          timestamp="$(find ${BUILD_REPO_PATH}/sources/${pkgname} -not -name .lock -printf '%T@\n' 2>/dev/null | sort -k1r | head -n 1)"
          [ $(find ${i} -newermt @${timestamp} | wc -l) -eq 0 ] && sourceok=N || sourceok=Y
        else
          sourceok=Y
        fi
        if ispkgdirty ${pkgname}; then
          status_extra="modified package"
          [ "${sourceok}" == "Y" ] || status_extra+=" and updated tarball"
        else
          [ "${sourceok}" == "Y" ] && status=CLEAN || status_extra="updated tarball"
        fi
        if [ "${status}" == "DIRTY" -a "${checktype}" != "C" ] || \
           [ "${status}" == "CLEAN" -a "${checktype}" != "D" ]; then
           if [ -n "${status_extra}" ]; then
              printf "%-40s  [%s] (%s)\n" "$(basename ${i})" "${status}" "${status_extra}"
           else
              printf "%-40s  [%s]\n" "$(basename ${i})" "${status}"
           fi
        fi
        break
      fi
    done
    [ "${found}" == "N" -a -n "${pkgargs}" ] && printf "%-40s  [%s] (%s)\n" "${pkgname}" "NOSTAMP" "already cleaned, not yet built, or invalid"
  done <<< "$(echo "${packages}")"
}

# Check all files in the package to detect if any have changed.
ispkgdirty()
{
  local pkg="${1}"

  [ "${ALWAYSDIRTY}" == "Y" -o "${FORCE}" == "Y" ] && return 0
  [ -d ${BUILD_DIR} ] || return 0

  (
    cd ${BUILD_REPO_PATH}
    . config/options "${pkg}" &>/dev/null

    if [ -n "${PKG_NAME}" ]; then
      STAMP_DEPENDS="${PKG_DIR} ${PKG_NEED_UNPACK} ${PROJECT_DIR}/${PROJECT}/patches/${PKG_NAME}"
      [ -n "$DEVICE" ] && STAMP_DEPENDS="${STAMP_DEPENDS} $PROJECT_DIR/$PROJECT/devices/$DEVICE/patches/$PKG_NAME"

      for i in ${BUILD_DIR}/${pkg}-*; do
        if [ -d ${i} -a -f "${i}/.libreelec-unpack" ]; then
          . "${i}/.libreelec-unpack"
          if [ "${STAMP_PKG_NAME}" = "${pkg}" ]; then
#echo "STAMP FILES: ${STAMP_DEPENDS}">&2
            PKG_DEEPMD5=$(find ${STAMP_DEPENDS} -exec md5sum {} \; 2>/dev/null | sort | md5sum | cut -d" " -f1)
#echo "STMP HASH: ${STAMP_PKG_DEEPMD5}" >&2
#echo "CALC HASH: ${PKG_DEEPMD5}" >&2
            [ "${PKG_DEEPMD5}" == "${STAMP_PKG_DEEPMD5}" ] && return 1
          fi
        fi
      done
    fi

    return 0
  )

  return $?
}

_clean()
{
  local PKG="$1"
  local oPKG

  [ "${PKG}" == "xbmc" ] && PKG="kodi"
  [ "${PKG}" == "kernel" ] && PKG="linux"

  oPKG="${PKG}"
  (_clean1 $(_find_build_folder "${PKG}") "${oPKG}")
}

#Usage: _clean p1 [p2]
#where p1 is the main build folder, and p2
#the .stamps folder, which if not supplied
#will be assumed to be the same name as the
#build folder
_clean1()
{
  local pkg_comma_ver="${1}"  original_pkg="${2}"
  local pkg="${pkg_comma_ver%%,*}" ver="${pkg_comma_ver#*,}"
  local status DIR1 DIR2 opwd=${pwd} buildmsg
  local rmpkg

  status=
  DIR1="${pkg}"
  DIR2="${pkg}"
  [ -n "${ver}" ] && DIR1+="-${ver}"

  printf "Cleaning %-35s" "${pkg}"
  if [ -n "${DEVICE}" ]; then
    buildmsg="${DEVICE}/${ARCH}/${BUILD_REPO_VERSION}"
  else
    buildmsg="${PROJECT}/${ARCH}/${BUILD_REPO_VERSION}"
  fi
  [ -n "${BUILD_SUFFIX}" ] && buildmsg="${buildmsg} (${BUILD_SUFFIX})"

  [ ! -d ${BUILD_DIR} ] && mkdir -p ${BUILD_DIR}

  if [ -d ${BUILD_DIR} ]; then
    echo -n " ${buildmsg}"

    cd ${BUILD_DIR}

    if ispkgdirty "${original_pkg}"; then
      # Special case some folders...
      if [ "${DRYRUN}" != "Y" ]; then
        case "${original_pkg}" in
          "initramfs")
            find . -maxdepth 1 -name initramfs -exec rm -fr {} \; 2>/dev/null && status=OK
            find . -path "*/.stamps/initramfs" -exec rm -fr {} \; 2>/dev/null && status=OK
            ;;
#          "TexturePacker")
#            rm -rf toolchain/bin/TexturePacker .stamps/TexturePacker
#            ;;
#          "JsonSchemaBuilder")
#            rm -rf toolchain/bin/JsonSchemaBuilder .stamps/JsonSchemaBuilder
#            ;;
#          "kodi"|"kodi-theme-Estuary")
#            for rmpkg in TexturePacker JsonSchemaBuilder; do
#              rm -rf toolchain/bin/${rmpkg} .stamps/${rmpkg} ${rmpkg}-0
#            done
#            ;;
        esac

        rm --recursive --interactive=never ${DIR1} 2>/dev/null && status=OK

        if [ -d .stamps ]; then
          cd .stamps
          rm --recursive --interactive=never ${DIR2} 2>/dev/null && status=OK
          cd ..
        fi
        if [ -d image/.stamps ]; then
          cd image/.stamps
          if [ $(find ${DIR2} -type f 2>/dev/null | wc -l) -ne 0 ]; then
            rm --recursive --interactive=never ${DIR2}/* 2>/dev/null && status=OK
          fi
          cd ../..
        fi
        if [ -d addons ]; then
          cd addons
          rm --recursive --interactive=never ${DIR2} 2>/dev/null && status=OK
          cd ..
        fi
      fi
    else
      status=CLEAN
    fi
  fi

  cd ${opwd}

  [ -n "${status}" ] && echo "  [${status}]" || echo ""
}

# Generate a list of packages, along with a timestamp of the
# most recently modified file within the package folder tree.
getpackages()
{
  local packagemk directory lastupdate

  [ -d ${BUILD_REPO_PATH}/packages ] || return 0

  while read -r packagemk; do
    [ -z "${packagemk}" ] && continue
    directory="$(dirname "${packagemk}")"
    lastupdate="$(find ${directory} -printf '%T@ %T+\n' 2>/dev/null | sort -k1r | head -n 1)"
    [ -n "${lastupdate}" ] && echo "${lastupdate} $(basename ${directory})"
  done <<< "$(find ${BUILD_REPO_PATH}/packages -type f -name package.mk)"
}

# Same, for source tarballs
getsources()
{
  local directory lastupdate

  [ -d ${BUILD_REPO_PATH}/sources ] || return 0

  while read -r directory; do
    [ -z "${directory}" ] && continue
    lastupdate="$(find ${directory} -not -name .lock -printf '%T@ %T+\n' 2>/dev/null | sort -k1r | head -n 1)"
    [ -n "${lastupdate}" ] && echo "${lastupdate} $(basename ${directory})"
  done <<< "$(find ${BUILD_REPO_PATH}/sources -type d)"
}

# Return combined results in descending order of timestamp
# so that processing can be terminated as soon as the first
# "current" package is located.
getcombined()
{
  (
    getpackages
    getsources
  ) | sort -k1nr
}

# For the current build directory, clean any package whose package or source has been
# modified since it was last built.
#
# Stop processing once a package is found that pre-dates that of the
# corresponding build folder.
#
# Package folders are considered optional as they might not be "dirty" even when the timestamp is modified.
# Sources are always considered dirty, and will not be treated as optional.
identify_modified_packages()
{
  local timestamp datestamp pkgname package i
  local -A dirty_pkg
  local -A dirty_src

  echo "Syncing build directory ${BUILD_DIR}..."

  [ -d "${BUILD_DIR}" ]         || return

  while read -r timestamp datestamp pkgname; do
    package=
    for i in ${BUILD_DIR}/${pkgname}-*; do
      [ -d ${i} -a -f "${i}/.libreelec-unpack" ] || continue
      . "${i}/.libreelec-unpack"
      if [ "${STAMP_PKG_NAME}" == "${pkgname}" ]; then
        package="${i}"
        break
      fi
    done
    if [ -n "${package}" ]; then
      [ $(find ${package} -newermt @${timestamp} | wc -l) -eq 0 ] || break
      ispkgdirty ${pkgname} && dirty_pkg["${pkgname}"]="Y"
    fi
  done <<< "$(getpackages | sort -k1nr)"

  while read -r timestamp datestamp pkgname; do
    package=
    for i in ${BUILD_DIR}/${pkgname}-*; do
      [ -d ${i} -a -f "${i}/.libreelec-unpack" ] || continue
      . "${i}/.libreelec-unpack"
      if [ "${STAMP_PKG_NAME}" == "${pkgname}" ]; then
        package="${i}"
        break
      fi
    done
    if [ -n "${package}" ]; then
      [ $(find ${package} -newermt @${timestamp} | wc -l) -eq 0 ] && dirty_src["${pkgname}"]="Y" || break
    fi
  done <<< "$(getsources | sort -k1nr)"

  for package in $(echo "${!dirty_pkg[@]}" | sed "s/ /\n/g" | sort -u); do SYNCDIRS_OPT="${SYNCDIRS_OPT}${package} "; done
  for package in $(echo "${!dirty_src[@]}" | sed "s/ /\n/g" | sort -u); do SYNCDIRS_MND="${SYNCDIRS_MND}${package} "; done
}

# If newitems is blank, it must have been passed as blank in second arg (unless first arg is blank, but
# that would be silly). In either case, when newitems is blank, do nothing.
linkeditems()
{
  local linkeditems="${1}" newitems="${2}"
  local pkglist_optional="${ALLARGS} ${SYNCDIRS_OPT}" pkglist_mandatory="${SYNCDIRS_MND} ${EXTRAARGS}"
  local item

  [ $# -eq 1 ] && newitems="${linkeditems}"
  [ -z "${newitems}" ] && return 0

  for item in ${linkeditems}; do
    if findinlist "${item}" "${pkglist_mandatory}"; then
      echo " ${item} ${newitems}"
      break
    elif findinlist "${item}" "${pkglist_optional}"; then
      if ALWAYSDIRTY=N ispkgdirty "${item}"; then
        echo " ${item} ${newitems}"
        break
      fi
    fi
  done

  return 0
}

getuniqueitems()
{
  local suffix="${1}" items="${2}" otheritems="${3}"
  local newitems withsuffix

  for item in $(echo ${items} | tr ' ' '\n' | sort -u --ignore-case); do
    findinlist "${item}" "${otheritems}" || newitems+="${item}/${suffix} "
  done
  echo "${newitems}"
}

get_all_binary_addons()
{
  local packages

  [ -d ${BUILD_REPO_PATH}/packages ] || return 0
  [ -d ${BUILD_DIR} ] || return 0

  for package in $(ls -1 ${BUILD_REPO_PATH}/packages/mediacenter/kodi-binary-addons); do
#    [ -d ${BUILD_DIR}/${package}-* ] && packages+="${package} "
    packages+="${package} "
  done
  
  [ -n "${packages}" ] && echo "${packages:0:-1}"
}

if [ -z "$1" ]; then
  $0 base
  exit
fi

cd ${BUILD_REPO_PATH}

DRYRUN=N
DOSYNC=N
FORCE=N
ALLARGS=
EXTRAARGS=
SYNCDIRS_OPT=
SYNCDIRS_MND=
ALWAYSDIRTY=N
ADDADDONS=N
DEBUG=N

CHECKCLEANDIRTY=

while read -r target; do
  [ -z "${target}" ] && continue
  case ${target} in
    --dryrun|--dry-run)
      DRYRUN=Y
      ;;
    --sync)
      DOSYNC=Y
      ;;
    --force)
      FORCE=Y
      ;;
    --debug)
      DEBUG=Y
      ;;
    --check)
      CHECKCLEANDIRTY=X
      ;;
    --checkdirty|--check-dirty)
      CHECKCLEANDIRTY=D
      ;;
    --checkclean|--check-clean)
      CHECKCLEANDIRTY=C
      ;;
    --addons)
      ADDADDONS=Y
      ;;
    --*)
      ;;
    *)
      ALLARGS+="${target} "
  esac
done <<< "$(echo "$@" | tr ' ' '\n')"

[ ${ADDADDONS} == Y ] && ALLARGS+="$(get_all_binary_addons) "

if [ -n "${CHECKCLEANDIRTY}" ]; then
  checkcleandirty ${CHECKCLEANDIRTY} "${ALLARGS}"
  exit
fi

[ ${DOSYNC} == Y ] && identify_modified_packages

# Associate linked packages so that linked/dependent packages also cleaned
EXTRAARGS="${EXTRAARGS}$(linkeditems "kodi kodi-theme-Estuary TexturePacker JsonSchemaBuilder")"
EXTRAARGS="${EXTRAARGS}$(linkeditems "bcm2835-driver bcm2835-bootloader")"

# Clean addons when cleaning either kodi-platform or platform/p8-platform...
EXTRAARGS="${EXTRAARGS}$(linkeditems "platform p8-platform kodi-platform" "${BUILD_ENV_ADDON_REPOS}")"

# If cleaning busybox or plymouth-lite, clean initramfs/linux
EXTRAARGS="${EXTRAARGS}$(linkeditems "busybox" "linux initramfs")"
EXTRAARGS="${EXTRAARGS}$(linkeditems "plymouth-lite" "linux initramfs")"

OPTIONAL_CLEAN="$(getuniqueitems "optional" "${ALLARGS} ${SYNCDIRS_OPT}" "${SYNCDIRS_MND} ${EXTRAARGS}")"
MANDATORY_CLEAN="$(getuniqueitems "mandatory" "${SYNCDIRS_MND} ${EXTRAARGS}" "")"

if [ "${DEBUG}" == "Y" ]; then
  echo "AA: ${ALLARGS}"
  echo "OP: ${OPTIONAL_CLEAN}"
  echo "MN: ${MANDATORY_CLEAN}"
  echo "SO: ${SYNCDIRS_OPT}"
  echo "SM: ${SYNCDIRS_MND}"
  echo "EA: ${EXTRAARGS}"
  exit
fi

while read -r target; do
  [ -z "${target}" ] && continue

  suffix="${target#*/}"
  target="${target%/*}"

  if [ "${suffix}" == "optional" ]; then
    ALWAYSDIRTY=N
  elif [ "${suffix}" == "mandatory" ]; then
    ALWAYSDIRTY=Y
  else
    ALWAYSDIRTY=N
  fi

  _clean "$target"

done <<< "$(echo "${OPTIONAL_CLEAN} ${MANDATORY_CLEAN}" | tr ' ' '\n' | sort -u --ignore-case)"

exit 0
