#!/bin/bash

PROFILE=defaults
BIN=$(readlink -f $(dirname $0))

[ -f ${BIN}/functions ] && source ${BIN}/functions

# Prefix ! to expand a set
# Addition:     "<setname>+suffix", eg. "pi+debug" to create debug variant of pi set
# Substitution: "<setname>/match/replace", eg. "pi/debug/testing" to create testing variant of pi-debug set
declare -A PROFILE_SETS=(
  ["pi1"]="pi1-testing"
  ["pi2"]="pi2-testing"
  ["x86"]="x86-testing"

  ["pi"]="pi1-testing,pi2-testing"
  ["pi-debug"]="!pi/testing/debug"

  ["x86-debug"]="x86-debug"

  ["all"]="pi1-testing,pi2-testing,x86-testing"
  ["all-debug"]="!all/testing/debug"
  ["all-stable"]="!all/testing/stable"
  ["all-nightly"]="!all/testing/nightly"
#  ["all-next"]="!all/testing/next"
  ["all-wipupnp"]="!all/testing/wipupnp"

  ["alt"]="pi1-alt,pi2-alt,x86-alt"
  ["alt-debug"]="!alt+-debug"
  ["alt-stable"]="!alt+-stable"
  ["alt-nightly"]="!alt+-nightly"
  ["alt-next"]="!alt+-next"
  ["alt-oe"]="!alt+-oe"
  ["alt-python3"]="!alt+-python3"
  ["alt-samba"]="!alt+-samba"

  ["alt-iwd"]="!alt+-iwd"
  ["alt-iwd-debug"]="!alt+-iwd-debug"
  ["alt-iwd-all"]="!alt-iwd,!alt-iwd-debug"

  ["alt-vc4"]="!alt+-vc4"

  # Disable usual max while x86-debug is broken
  ["max"]="!all,!all-debug"
  #["max"]="!all,!pi-debug"

  ["max-nq"]="!all,!pi-debug"
  ["insane"]="!all,!all-debug,!alt"
  ["insane++"]="!all,!all-debug,!alt,!alt-debug"
  ["all-alt"]="!all,!alt"
  ["pi-x4"]="!pi,!pi-debug"
  ["x86-x2"]="!x86,!x86-debug"

  ["alt-max"]="!alt,!alt-debug"

  ["everything-master"]="@pi1,@pi2,@x86,wetekp,wetekp2,wetekc,wetekh,imx6,odroidc2"
  ["everything"]="!everything-master+-testing"
  ["alt-everything"]="!everything-master+-alt"
  ["alt-everything-stable"]="!alt-everything+-stable"
  ["alt-everything-nightly"]="!alt-everything+-nightly"
  
  ["pi2x86"]="pi2-testing,x86-testing"

  ["slice"]="slice1-testing,slice2-testing"

  ["pi1-master"]="pi1"
  ["pi2-master"]="pi2"
  ["x86-master"]="x86"
  ["slice1-master"]="slice1"
  ["slice2-master"]="slice2"
)

DELAY=5
WARNING="${TXRED}WARNING${TXRESET}: ${TXMAGENTA}CACHE WILL BE CLEARED!${TXRESET}"

# ! = expand item, @=suppress expansion
translateprofile() {
  local profile="${1}"
  local profiles newap baseprof suffix match replace p translated expand

  if [[ ${profile} =~ ..*,.* ]]; then
    for p in ${profile//,/ }; do
      translated+="$(translateprofile "!${p}"),"
    done
    echo "${translated:0:-1}"
  else #expandable individual profiles, with optional addition/substitution
    if [ "${profile:0:1}" == "!" ]; then
      profile="${profile:1}"
      expand=Y
    else
      expand=N
    fi

    if [[ ${profile} =~ .*\+.* ]]; then #addition
      baseprof="${profile%+*}"
      suffix="${profile#*+}"
      profiles="$(translateprofile "!${baseprof}")"
      for p in ${profiles//,/ }; do
        newap+="${p}${suffix},"
      done
      echo "${newap:0:-1}"
    elif [[ ${profile} =~ .*/.*/.* ]]; then #substitution
      baseprof="${profile%%/*}"
      match="${profile#*/}"
      replace="${match#*/}"
      match="${match%/*}"
      profiles="$(translateprofile "!${baseprof}")"
      for p in ${profiles//,/ }; do
        newap+="${p/${match}/${replace}},"
      done
      echo "${newap:0:-1}"
    elif [ ${expand} == Y -a -n "${PROFILE_SETS["${profile}"]}" ]; then
      translateprofile "${PROFILE_SETS["${profile}"]}"
    else
      echo "${profile}"
    fi
  fi
}

combineprofiles() {
  local profiles="${1}"
  local p translated
  for p in ${1//,/ }; do
    translated+="$(translateprofile "${p}"),"
  done
  echo "${translated:0:-1}"
}

preprocess_all_sets()
{
  local key value
  for key in ${!PROFILE_SETS[@]}; do
    PROFILE_SETS["${key}"]="$(combineprofiles "${PROFILE_SETS["${key}"]}")"
  done
}

# Remove any leading @, used to suppress expansion
clean_set()
{
  echo "${1//@/}"
}

preprocess_all_sets

usage()
{
  local key keys tmp

  keys="$(echo "${!PROFILE_SETS[@]}"  | tr -s ' ' '\n' | sort | tr -s '\n' ' ')"
  keys="${keys:0:-1}"

  [ -n "${1}" ] && echo -e "ERROR: ${1}\n"

  cat <<EOF
Usage: $(basename $0) -s <${keys}> [-f] [-u] [-r] [-p] [-A filter] [-D|-w] [-R] [-9] [-Z<args>] [-x<arg>] [-h]
    -s  Profile set to build
    -f  Force a clean build, including clearing of ccache
    -u  Upload to local client
    -r  Upload to remote server
    -p  Generate release notes for publication 
    -A  Additional filter codes
    -w  Wipe build date
    -D  Do not roll build date
    -R  Refresh repositories
    -9  Do not renice the build processes, use default process priorities (increased performance)
    -Z  Eval args for each profile, eg. "clean.sh kodi"
    -x  Autobuild argument - pass -<arg> to autobuild

Profile Sets:
EOF

  for key in ${keys}; do
    tmp="${PROFILE_SETS["${key}"]//,/, }"
    tmp="${tmp//@/}"
    printf "  -s %-20s = %s\n" "${key}" "${tmp}"
  done
  printf "  -s <profile>,<profile>,...\n"
}

while getopts ":fwDRurp9s:A:x:Z:h" opt; do
  case ${opt} in
    f) AUTOBUILD="${AUTOBUILD} -f"; DELAY=15;;
    w) AUTOBUILD="${AUTOBUILD} -w";;
    D) AUTOBUILD="${AUTOBUILD} -D";;
    R) AUTOBUILD="${AUTOBUILD} -R";;
    u) AUTOBUILD="${AUTOBUILD} -u";;
    r) AUTOBUILD="${AUTOBUILD} -r";;
    p) AUTOBUILD="${AUTOBUILD} -p";;
    9) AUTOBUILD="${AUTOBUILD} -9";;
    s) PROFILE_SET="${OPTARG}";;
    A) AUTOBUILD="${AUTOBUILD} -A ${OPTARG}";;
    x) AUTOBUILD="${AUTOBUILD} -${OPTARG}";;
    Z) EXECPROG="${OPTARG}";;
    h) usage ; exit 1;;
    *) usage "Unknown argument [-${OPTARG}]"; exit 1;;
  esac
done

[ -n "${PROFILE_SET}" ] || { usage "Profile Set argument [-s] required"; exit 1; }

[ -n "${PROFILE_SETS["${PROFILE_SET}"]}" ] && AUTOBUILD_PROFILES="${PROFILE_SETS["${PROFILE_SET}"]}" || AUTOBUILD_PROFILES="$(translateprofile "${PROFILE_SET}")"

AUTOBUILD_PROFILES="$(clean_set "${AUTOBUILD_PROFILES}")"

[ -n "${AUTOBUILD_PROFILES}" ] || { usage "Invalid Profile Set [${PROFILE_SET}]"; exit 1; }

if [ -n "${EXECPROG}" ]; then
  [[ ${EXECPROG:0:1} =~ [\./] ]] || EXECPROG="${BIN}/${EXECPROG}"
  for profile in ${AUTOBUILD_PROFILES//,/ }; do
    eval "PROFILE=${profile} ${EXECPROG}" || exit
  done
  exit 0
fi

echo "Building: ${AUTOBUILD_PROFILES//,/ }"

[ -n "${CLEANBUILD}" ] && echo -e "\n${WARNING}\n${WARNING}\n${WARNING}\n"
[ -z "${NODELAY}" ] && echo -n "Starting in ${DELAY} seconds..." && sleep ${DELAY} && echo

PROFILE=multi-adhoc AUTOBUILD_PROFILES="${AUTOBUILD_PROFILES}" ${BIN}/autobuild.sh ${AUTOBUILD:1}
