#!/bin/bash

source ./settings.sh

#applysettings "audiooutput.normalizelevels audiooutput.boostcenter" "$@"
applysettings "audiooutput.boostcenter" "$@"
