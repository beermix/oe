#!/bin/bash

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

FORMAT_BYTES='
import sys;
f=float(sys.argv[1]);
if f < 1024:
  s="B"
elif f < (1024*1024):
  s="KB"
  f=f/1024
else:
  s="MB"
  f=f/1024/1024
print("%s %s" % (format(f, ",.1f"), s))
'

DRYRUN=N

while getopts "d" opt; do
  case ${opt} in
    d) DRYRUN=Y; MSGDRYRUN=" (DRY RUN)";;
  esac
done

cd ${BUILD_REPO_PATH}/sources

BYTES=0
for dir in $(find . -type d -not -name "." | sort); do
  cd ${BUILD_REPO_PATH}/sources/${dir}

  BASE="$(ls -1rt *.url | tail -1)"
  [ -z "${BASE}" ] && continue

  BASE="$(basename "${BASE}" .url)"

  ITEM=0
  for file in $(ls -1rt | grep -vE "^${BASE}"); do
    [ $ITEM = 0 ] && echo "Enter directory: ${dir:2}"
    #ACCESS="$(stat -c%x ${file})"
    ACCESS="$(stat -c%y ${file})"
    SIZE=$(stat -c%s ${file})
    BYTES=$(($BYTES + ${SIZE}))
    MSIZE="$(python -c "${FORMAT_BYTES}" $SIZE)"
    if [ ${DRYRUN} == N ]; then
      echo "  Removing file: (${ACCESS:0:19}) ${file} (${MSIZE})"
      rm -f "${file}"
    else
      echo "  Dry Run: (${ACCESS:0:19}) ${file} (${MSIZE})"
    fi
    ITEM=$((${ITEM}+1))
  done
done
echo
echo "Bytes recovered: $(python -c "${FORMAT_BYTES}" $BYTES)${MSGDRYRUN}"
