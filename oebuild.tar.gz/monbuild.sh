#!/bin/bash

if [ "${_UNBUFFERED}" != "Y" ]; then
  export _UNBUFFERED=Y
  stdbuf --input=0 --output=0 $0 $@
  exit
fi

renice +19 $$ &>/dev/null

NOLOCK=Y
PROFILE=defaults
BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

function getfile()
{
  echo $(gettmpdirp)/progress.dat
}

function getfiles()
{
  if [ -z "${AUTOBUILD_PROFILES}" ]; then
    executeasprofile ${PROFILE} N getfile
  else
    for profile in ${AUTOBUILD_PROFILES//,/ }; do
      executeasprofile ${profile} N getfile
    done
  fi
  echo >&2
}

monitorfiles()
{
  local line pos posd posu text clr blank
  local count files

  SPACES="$(printf "%*s" 999 " ")"
  NLINES="${SPACES// /\\n}"

  FILES=$(getfiles)
  FILES_COUNT=$(echo ${FILES} | wc -l)

  if command -v tput >/dev/null; then
    COLUMNS="$(tput cols)"
    ESC_BLANKLINE="$(tput el)"
    trap "tput cud 999" EXIT
  else
    COLUMNS=150
  fi

  files="$(echo "${FILES}" | tr '\n' ' ')"
  blank="${ESC_BLANKLINE}"

  tail -qF -n1 --follow=name --retry --max-unchanged-stats=2 ${files} 2>/dev/null | \
    while read -r line; do
      [[ ${line} =~ ^|.*|$ ]] || continue
      line="${line:1:-1}"

      pos="${line%%;*}"

      count="${pos/,*}"
      [ -n "${count}" ] || continue
      [[ ${count} =~ ^[0-9]* ]] || continue
      posd="${NLINES:0:$((count + count))}"

      posu="${pos/*,}"
      [ -z "${posu}" -o ${#posu} == 4 -o ${#posu} == 5 ] || continue

      text="${line#*;}"
      text="${text:0:${COLUMNS}}"

      if [ -z "${ESC_BLANKLINE}" ]; then
        clr=$((COLUMNS - ${#text}))
        [ ${clr} -gt 0 ] && blank="${SPACES:0:${clr}}" || blank=""
      fi

      echo -en "${posd}${text}${blank}${posu}\r"
    done
}

BUILD_PROFILE=$(gettmpdirg .global)/build.profile

if [ $# -eq 0 -a $(ls -1 ${BUILD_PROFILE}.* 2>/dev/null | wc -l) -gt 1 ]; then
  echo "Multiple sessions available... select session to be monitored (latest is first):"
  count=0
  guids=("")
  while read -r guid; do
    count=$((count + 1))
    guids+=(${guid##*.})
    echo "${count}: ${TXGREEN}${guid##*.}${TXRESET} => $(cat ${guid} | head -1): $(cat ${guid} | tail -1)"
  done <<< "$(ls -1t ${BUILD_PROFILE}.*)"

  read -p "Enter GUID [1..${count}]: " count

  [ -z "${count}" ] && count=1
  [[ ${count} =~ ^[0-9]*$ ]] || exit 1
  [ ${count} -lt 1 -o ${count} -ge ${#guids[@]} ] && exit 1

  BUILD_PROFILE="${BUILD_PROFILE}.${guids[${count}]}"
elif [ $# -eq 1 ]; then
  BUILD_PROFILE="$(ls -1t ${BUILD_PROFILE}.* | head -$1 | tail -1)"
else
  BUILD_PROFILE="$(ls -1 ${BUILD_PROFILE}.* 2>/dev/null)"
fi

[ -z "${BUILD_PROFILE}" ] && { echo "No available builds to monitor - quitting"; exit 1; }

PROFILE="$(cat ${BUILD_PROFILE} | head -1)"
AUTOBUILD_PROFILES="$(cat ${BUILD_PROFILE} | tail -1)"

[ -n "${PROFILE}" ] || die 1 "Need to know which profile(s) to monitor!"
echo "Monitoring build progress for profile: ${PROFILE}"

monitorfiles
