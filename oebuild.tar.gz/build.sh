#!/bin/bash

BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

_lock_build_repo

BUILD_PROGRESS='
BEGIN {
  DEBUG=0
  C = 0
  GO = 0
  FAILED = 0
  LINE = ""
  LAST_LINE = ""
  LAST_LINE_LEN = 0
  ROT = 0
  TICK = "|/-\\|/-\\"
  TOTAL = (TOTAL <= 0 ? 1 : TOTAL)
  WAITING = 0
  ACTION_REPEAT = 0
  START = 0
  ETIME = "00h00m00s"

  PROGRESS_FILE = PROFDIR "/progress.dat"
  PROGRESS_LENGTH = 0
  PROGRESS_LEN_MAX = 2 * 1024 * 1024

  ESC_PREAMBLE_LEN = length(ESC_PREAMBLE)
}

# Save the original record
{ ORIGINAL_REC = $0 }

/^## BUILD STARTED:/ {
  START = systime()
}

# With "[  1%] Linking CXX shared", we can lose field #1 (and trailing spaces) to
# simplify subsequent processing of cmake fields
$1 == "[" && $2 ~ /^[0-9]*%\]$/ { gsub(/^\[ */,"") }

# Inject elapsed time at beginning of record if not already present
!/^[0-9][0-9]h[0-9][0-9]m[0-9][0-9]s: / {
  SECS = (START != 0 ? systime() - START : 0)
  $0 = sprintf("%02dh%02dm%02ds: ", int(SECS/3600), int(SECS/60)%60, SECS%60) $0
}

!GO {
  if ( $0 ~ "^.*: ##" )
  {
    GO = 1
    ACTION = ""
    LINE = "Configuration"
  }
  else
  {
    print
    # Output an extra blank line at end of job configuration
    if ( ORIGINAL_REC == "" )
      printf "\n"
    fflush()
  }
}

$2 ~ /^CC$|^CCLD$|^CPP$|^CXX$|^CXXLD$|^GEN$|^HOSTCC$|^HOSTLD$|^LD$/ && $3 !~ /^=/ {
  ACTION = $2 ": " $3
}

# cmake processing:
# "<h:m:s> 35%] Linking CXX static library music.a"
# "<h:m:s> [100%] Linking CXX executable kodi.bin"
# "<h:m:s> 94%] Linking CXX static library input_touch.a"
# "<h:m:s> 94%] Linking CXX shared library input_touch.a"
$3 " " $4 ~ /^Linking CXX$|^Linking C$/ {
  if ($5 == "executable")
    ACTION = sprintf("%s %s: %s (%s)", $3, $4, $6, $5)
  #else
  #  ACTION = sprintf("%s %s: %s (%s %s)", $3, $4, $7, $5, $6)
}

# "<h:m:s> 98%] Built target input_touch_generic"
$3 " " $4 ~ /^Built target$/ {
  ACTION = sprintf("%s %s: %s", $3, $4, $5)
}

$2 ~ /-gcc$/ && $3 ~ /.c$/ {
  ACTION = "GCC: " $3
}
$2 ~ /^\033\[.*mGET|^\033\[.*mUNPACK|^\033\[.*mBUILD|^\033\[.*mINSTALL/ {
  if ($2 ~ /^\033\[.*mGET/)
  {
    LINE = $3
    ACTION_REPEAT = 1
    ACTION = "Downloading package..."
  }
  else
  {
    ACTION_REPEAT = 0
    ACTION = ""

    if ($2 ~ /^\033\[.*mINSTALL/) C++

    INDENT = int((match(substr($0, 11), "[^ ]")-3)/4)
    ITEMS[INDENT] = $3
    for (x = 0; x <= INDENT; x++) ITEM=(x == 0 ? "" : ITEM ".") ITEMS[x]
    LINE = ITEM
  }
}
$0 ~ /Parallel mksquashfs:/ {
  ACTION = ""
  LINE = "making squashfs"
}
$0 ~ /Hunk .* FAILED/ {
  FAILED = 1
}
$0 ~ /make: \*\*\* \[.*\] Error/ {
  FAILED = 1
}
$0 ~ /make: \*\*\* \[.*\] Fehler/ {
  FAILED = 1
}
$0 ~ /Project .* waiting to avoid concurrent download of .*/ {
  WAITING = 1
  LINE = $10
  gsub("\\.\\.\\.$", "", LINE)
  ACTION = "Waiting for package..."
}

LINE != "" {
  ETIME = substr($1,1,9)
  MSG = sprintf("%s: %6.2f%% complete [%s] %s", ETIME, ((C/TOTAL)*100), JOBID, (WAITING == 1 ? "W" : substr(TICK,(ROT++%8)+1,1)))
  if (LINE != "")
  {
    LINELEN = COLUMNS - (length(MSG) + 3)
    if (LINELEN > length(LINE))
      MSG = MSG " (" LINE ")"
    else
      if (LINELEN > 3) MSG = MSG " (" substr(LINE,1,LINELEN - 3) "..." ")"
  }
  if (ACTION != "")
  {
    ACTIONLEN = COLUMNS - (length(MSG) + 4)
    if (ACTIONLEN > length(ACTION))
      MSG = MSG "  [" ACTION "]"
    else
      if (ACTIONLEN > 3) MSG = MSG "  [" substr(ACTION,1,ACTIONLEN - 3) "..." "]"
    if (ACTION_REPEAT = 0) ACTION = "" 
  }
  else
    ACTION_REPEAT = 0

  outputline(MSG, blankeol(MSG, 0))

  WAITING = 0
  if (DEBUG == 1) delay(.001)
}

END {
  if (TOTAL <= 0) TOTAL = 1

  MSG = sprintf("%s: %6.2f%% complete [%s] * %s",
    ETIME, (C/TOTAL*100), JOBID, (FAILED ? TXRED "** BUILD FAILURE - SEE LOG! **" : TXGREEN "BUILD SUCCESSFUL!") TXRESET)

  MSG = sprintf("%s: %6.2f%% complete [%s] *", ETIME, (C/TOTAL*100), JOBID)
  MSG = MSG " " (FAILED ? TXRED "** BUILD FAILURE - SEE LOG! **" : TXGREEN "BUILD SUCCESSFUL!") TXRESET

  outputline(MSG, blankeol(MSG, length(TXGREEN) + length(TXRESET)))
}

function outputline(line, blankchars)
{
  printf "%s%s%s%s\r", ESC_PREAMBLE, line, blankchars, ESC_POSTAMBLE > "/dev/stderr"
  printf "|%d,%s;%s|\n", ESC_PREAMBLE_LEN, ESC_POSTAMBLE, line > PROGRESS_FILE
  fflush()

  # If size of output file exceeds maximum size then overwrite it
  PROGRESS_LENGTH += length(ESC_ROWPOS) + length(line) + 1
  if (PROGRESS_LENGTH > PROGRESS_LEN_MAX) 
  {
    close(PROGRESS_FILE)
    PROGRESS_LENGTH = 0
  }
}

# When calculating length of new line for purposes of blanking, dont include non-printing escape characters
function blankeol(msg, escape_chars)
{
  if (ESC_BLANKLINE != "") return ESC_BLANKLINE
  lm = length(msg) - escape_chars
  blank = (LAST_LINE_LEN > lm ? sprintf("%*s",(LAST_LINE_LEN - lm)," ") : "")
  LAST_LINE = msg
  LAST_LINE_LEN = lm
  return blank
}

function delay(period)
{
  system("sleep " period)
}
'

makeunique()
{
  local target="${1}" oldrel="${2}" newrel ftype

  if [ $(echo "${oldrel}" | sed 's/-/ /g' | wc -w) -eq 3 -a "${BUILD_TARGET_UNIQUE,,}" == "no" ]; then
    newrel="${oldrel}-$(date +%Y%m%d%H%M%S)"
    for ftype in system kernel tar img.gz; do
      [ -f "${target}/${oldrel}.${ftype}" ] && mv "${target}/${oldrel}.${ftype}" "${target}/${newrel}.${ftype}"
    done
    echo "${newrel}"
  else
    echo "${oldrel}"
  fi  
}

# Optionally clean the folder on first use if "clean" arg is specified
get_build_tar()
{
  echo "$(gettmpdirp tar ${1})/milhouse.build.${BDATE:2}.tar.gz"
}

fixup_image()
{
  cd ${BUILD_REPO_PATH}

  # Don't update scripts/image file if already updated
  if ! ${TGREP} -q "^MILHOUSE_BUILDCODE=" scripts/image; then
    sed -i 's+^BUILD_DATE=.*+&\nMILHOUSE_BUILDCODE="$(cat $ROOT/milhouse.buildcode)"+' scripts/image
    sed -i "s/^\(  LIBREELEC_VERSION=\$LIBREELEC_VERSION-\$BUILD_DATE-\).*\(-g\$GIT_ABBREV\)/\1#\${MILHOUSE_BUILDCODE:2}\2/" scripts/image
    if [ -n "${OE_DISTRO_IDENTIFIER}" ]; then
      if grep -q " - Version: " scripts/image; then
        sed -i "s+.*\"PRETTY_NAME=.*+echo -e \"PRETTY_NAME=\\\\\"\$DISTRONAME (${OE_DISTRO_IDENTIFIER}) - Version: \$LIBREELEC_VERSION [Build #\${MILHOUSE_BUILDCODE:2}]\\\\\"\" >> \$INSTALL/etc/os-release+" scripts/image
      else
        sed -i "s+.*\"PRETTY_NAME=.*+echo -e \"PRETTY_NAME=\\\\\"\$DISTRONAME (${OE_DISTRO_IDENTIFIER}): \$LIBREELEC_VERSION [Build #\${MILHOUSE_BUILDCODE:2}]\\\\\"\" >> \$INSTALL/etc/os-release+" scripts/image
      fi
    fi
    sed -i "s+^# create /etc/issue+echo -e \"MILHOUSE_BUILD=\\\\\"\${MILHOUSE_BUILDCODE}\\\\\"\" >> \$INSTALL/etc/os-release\n\n&+" scripts/image

    sed -i "s#^TARGET_IMG=\$ROOT/\$TARGET\$#&/.tmp/\$PROFILE#" config/path
    rm -fr target/.tmp
  fi

  echo "${BDATE}" > milhouse.buildcode
  
  return 0
}

# Stash profile specific configuration and patches
create_build_tar()
{
  local BUILD_DIR=$(gettmpdirp milhouse.${BDATE:2} clean)
  local BUILD_TAR=$(get_build_tar clean)
  local ENV_CONFIG_DIR=$(gettmpdir .config)
  local PRJ_CONFIG_DIR=$(gettmpdirp .config clean)
  local ENV_GIT_DIRS="config scripts distributions packages"
  local PRJ_GIT_DIRS="projects/${PROJECT}"
  local AUTOBUILD_CONFIG=${PRJ_CONFIG_DIR}/autobuild.conf
  local GZIP file token

  echo "Generating build archive..."

  [ -f $(gettmpdirp)/ipatches.dat  ] && cp -P $(gettmpdirp)/ipatches.dat "${PRJ_CONFIG_DIR}/$(basename "${BUILD_PKG_CONTROL}")"
  [ -f $(gettmpdirp)/patches.dat   ] && cp -P $(gettmpdirp)/patches.dat "${PRJ_CONFIG_DIR}/$(basename "${BUILD_PKG_PATCHES}")"
  [ -f $(gettmpdirp)/blacklist.dat ] && cp -P $(gettmpdirp)/blacklist.dat "${PRJ_CONFIG_DIR}/$(basename "${BUILD_PKG_BWLIST}")"

  # Copy environment autobuild.conf, then add this profiles settings
  [ -f ${ENV_CONFIG_DIR}/autobuild.conf ] && cp ${ENV_CONFIG_DIR}/autobuild.conf ${AUTOBUILD_CONFIG}
  echo "PROFILE SETTINGS [${PROFILE}]" >> ${AUTOBUILD_CONFIG}
  echo "================" >> ${AUTOBUILD_CONFIG}
  showprofile >> ${AUTOBUILD_CONFIG}

  # Transform filenames when storing - "S" flag prevents symlinks being transformed.
  # See: http://www.gnu.org/software/tar/manual/html_section/tar_52.html#transform
  tar cf - \
    ${BUILD_RESOURCES}/bin ${BUILD_RESOURCES}/build ${BUILD_RESOURCES}/patches \
    ${BUILD_REPOS}/make-*.sh ${BUILD_REPOS}/supermk.sh ${BUILD_REPOS}/binary.addons.txt ${BUILD_REPOS}/tools/* \
    ${BIN}/functions ${BIN}/profiles.dat ${BIN}/parseprofile.py ${BIN}/autobuild.sh ${BIN}/oepull.sh \
    ${BIN}/build.sh ${BIN}/buildaddon.sh ${BIN}/lsPatches.sh ${BIN}/getPatches.sh \
    ${BIN}/clean.sh ${BIN}/zzPurge.sh ${BIN}/srcpurge.sh \
    ${BIN}/checkpatches.sh ${BIN}/checkpr.sh ${BIN}/verifyprofiles.sh \
    ${BIN}/pushover.sh ${BIN}/kdiff.sh ${BIN}/monbuild.sh ${BIN}/totalbuild.sh \
    ${BIN}/settings.sh ${BIN}/setdtshd.sh ${BIN}/setaudio.sh ${BIN}/setvideo.sh ${BIN}/setboost.sh ${BIN}/setpower.sh \
    ${BIN}/README.1ST ${BIN}/profiles.README \
    ${BIN}/BUILD.README \
    --transform "s/BUILD.README/README/" \
    --transform "s#${BIN:1}##" \
    2>/dev/null | tar -xf - -C ${BUILD_DIR} 2>/dev/null

  if [ -d ~/.${BUILD_TYPE_LNAME} ]; then
    mkdir ${BUILD_DIR}/HOMEDIR
    cp -rP ${HOME}/.${BUILD_TYPE_LNAME} ${BUILD_DIR}/HOMEDIR
  fi

  cd ${BUILD_REPO_PATH}

  # Store all environment and project config, patches and changes in the config folder
  BUILD_DIR_CONFIG=${BUILD_DIR}/config
  mkdir -p ${BUILD_DIR_CONFIG}

  cat <<EOF > ${BUILD_DIR_CONFIG}/reset.sh
#!/bin/bash
#
# Args:
#   --verbose for detailed output
#   --check   for dry run
#
BIN=\$(readlink -f \$(dirname \$0))

[ -d .git ] || { echo "ERROR: Current directory is not a git repository."; exit 1; }

REPO_NAME="\$(git remote show origin -n | ${TGREP} "Fetch URL:" | sed -E 's#^.*/(.*)\$#\1#' | sed 's#.git\$##')"

[ "\${REPO_NAME}" != "${BUILD_TYPE_REPO_NAME}" ] && { echo "ERROR: Current repository is not an ${BUILD_TYPE_REPO_NAME} fork/clone."; exit 1; }

echo
echo "${TXRED}**** WARNING: You are about to reset this repository back to build #${BDATE:2} ****${TXRESET}"
echo
read -p "Are you really sure? Type yes to continue: " yesno
[ "\${yesno,,}" != "yes" ] && { echo "Reset aborted!"; exit 1; }

git clean -fd
git checkout $(getcurrentbranch .)
git reset --hard $(getcurrentrev . HEAD)
cat \${BIN}/${BUILD_TYPE_LNAME}.patch | git apply -p1 --whitespace=nowarn \$@
cat \${BIN}/project.patch  | git apply -p1 --whitespace=nowarn \$@

echo
echo "** To build this profile **"
echo
echo "Add the following entries to profile [${PROFILE}] in profiles.dat:"
echo
for token in BUILD_ENV_REPOS BUILD_ENV_ADDON_REPOS BUILD_ENV_BRANCHES BUILD_ENV_ADDON_BRANCHES; do
  echo "\$(${TGREP} -m1 "^\${token}=" \${BIN}/autobuild.conf)"
done
echo
echo "Then execute the following:"
echo
echo "PROFILE=${PROFILE} ./autobuild.sh -E"
echo

EOF
  chmod +x ${BUILD_DIR_CONFIG}/reset.sh

  cp -rP ${ENV_CONFIG_DIR}/* ${BUILD_DIR_CONFIG} 2>/dev/null
  cp -rP ${PRJ_CONFIG_DIR}/* ${BUILD_DIR_CONFIG} 2>/dev/null

  # Modified and deleted tracked files from build environment folders
  git diff --no-color ${ENV_GIT_DIRS} > ${BUILD_DIR_CONFIG}/${BUILD_TYPE_LNAME}.patch

  # New untracked files from build environment folders
  while read -r file; do
    [ -n "${file}" -a ! -L "${file}" ] && git diff --no-color --no-index --binary /dev/null "${file}" >> ${BUILD_DIR_CONFIG}/${BUILD_TYPE_LNAME}.patch
  done <<< "$(git status --short --untracked-files=all --porcelain ${ENV_GIT_DIRS} | ${TGREP} -E "^\?\? " | cut -b4- )"

  # Modified and deleted tracked files for current project
  git diff --no-color ${PRJ_GIT_DIRS} > ${BUILD_DIR_CONFIG}/project.patch

  # New untracked files for the current project
  while read -r file; do
    [ -n "${file}" ] && git diff --no-color --no-index --binary /dev/null "${file}" >> ${BUILD_DIR_CONFIG}/project.patch
  done <<< "$(git status --short --untracked-files=all --porcelain ${PRJ_GIT_DIRS} | ${TGREP} -E "^\?\? " | cut -b4- )"

  command -v pigz >/dev/null && GZIP="pigz --best" || GZIP="gzip --best"
  # tar and compress the folder of build files
  tar cf - -C $(dirname ${BUILD_DIR}) $(basename ${BUILD_DIR}) | ${GZIP} > ${BUILD_TAR}

  rm -fr ${BUILD_DIR}
}

SELF=$(basename $0)

ARGS=$@
GITUPDATE=N
WITHLOG=Y
NOBUILD=N
DEBUG=${DEBUG:-no}
NOTIFY=Y
MKRELEASE=Y

GITBRANCH=$(cd ${BUILD_REPO_PATH}; git branch | ${TGREP} -E "^\*"|awk '{print $2}')
BRANCH=${GITBRANCH}
ROLLDATE=Y
CLEARDATE=N
USEBUILDDATE=
JOBTOTAL=1
JOBINDEX=1
JOBIDWIDTH=0
GOTTTY=Y
COMMSDIR=
RELEASE_TYPE=release

while true; do
  case "$1" in
    -n | --nogit ) GITUPDATE=N;;
    -g | --git ) GITUPDATE=Y;;
    -q | --quiet ) WITHLOG=N;;
    -b | --branch ) BRANCH="$2"; shift;;
    -w ) CLEARDATE=Y;;
    -D ) CLEARDATE=N; ROLLDATE=N;;
    --builddate) USEBUILDDATE="${2}"; shift;;
    --log) BUILD_LOG=${2}; shift;;
    --jobtotal) JOBTOTAL=${2}; shift;;
    --job) JOBINDEX=${2}; shift;;
    --jobidw) JOBIDWIDTH=${2}; shift;;
    --mkimage) RELEASE_TYPE=image;;
    --noimage) RELEASE_TYPE=release;;
    -r ) PROJECT=RPi; ARCH=arm;;
    -i ) PROJECT=Generic; ARCH=x86_64;;
    -X ) NOBUILD=Y;;
    -Y ) DEBUG=yes;;
    -N ) NOTIFY=N;;
    -T ) MKRELEASE=N;;
    -S ) COMMSDIR="$2"; shift;;
    * ) break ;;
  esac
  shift
done

[ ${JOBTOTAL} -gt 1 ] && PARALLEL_BUILD=Y || PARALLEL_BUILD=N

if [ -n "${USEBUILDDATE}" ]; then
  BDATE="${USEBUILDDATE}"
else
  CDATE="$(date +%y%m%d)"
  [ -f ${BIN}/.build ] && BDATE="$(awk '{print $1}' ${BIN}/.build)"

  if [ "${CLEARDATE}" == "Y" -o -z "${BDATE}" ]; then
    BDATE="${CDATE}"
  elif [ "${ROLLDATE}" == "Y" ]; then
    lastbd="${BDATE:0:6}"
    lastbdch="${BDATE:6:1}"
    if [ "${CDATE}" != "${lastbd}" ]; then
      BDATE="${CDATE}"
    else
      #BDATE="${lastbd}$(python -c "print(chr(ord(\"${lastbdch:-a}\")+1))")"
      BDATE="${lastbd}$(python -c "c=ord(\"${lastbdch:-a}\")+1; print(chr(c) if chr(c) <= 'z' else chr(c - 32 - 26))")"
    fi
  fi
fi

#http://www.bagill.com/ascii-sig.php (font Xtty)
BUILDFAIL="${TXRED}###  #  # ### #    ###     ####  ##  ### #    #
#  # #  #  #  #    #  #    #     ##   #  #    #
#  # #  #  #  #    #   #   #    #  #  #  #    #
###  #  #  #  #    #   #   ###  #  #  #  #    #
#  # #  #  #  #    #   #   #    ####  #  #     
#  # #  #  #  #    #  #    #    #  #  #  #    #
###   ##  ### #### ###     #    #  # ### #### #${TXRESET}"

BUILDOK="${TXGREEN} ### #  #   ###   ### ####  ###  ### #
#    #  #  #  #  #  # #    #    #    #
#    #  # #     #     #    #    #    #
 ##  #  # #     #     ###   ##   ##  #
   # #  # #     #     #       #    #  
   # #  #  #     #    #       #    # #
###   ##    ###   ### #### ###  ###  #${TXRESET}"

if [ -z "${LOGGED}" -a "${WITHLOG}" == "Y" ]; then
  BASENAME="$(ls -1t $(getbuildimagename)-*.log 2>/dev/null | head -1)"
  [ -n "${BASENAME}" -a -f "${BASENAME}" ] && TOTAL=$(${TGREP} " *...;..mINSTALL" ${BASENAME} | wc -l) || TOTAL=0
  [ ${TOTAL} -eq 0 ] && TOTAL=190

  COLUMNS=150
  if command -v tput >/dev/null; then
    # If interactive, trust column width...
    [[ $(ps -o stat= -p $$) == *+* ]] && COLUMNS="$(tput cols)"
    if [ "${PARALLEL_BUILD}" == "Y" ]; then
      if [ ${JOBINDEX} -gt 1 ]; then
        ESC_PREAMBLE="$(printf "%*s" $((JOBINDEX - 1)) " ")"
        ESC_PREAMBLE="${ESC_PREAMBLE// /\\n}"
        ESC_POSTAMBLE="$(tput cuu $((JOBINDEX - 1)))"
      fi
    fi
    ESC_BLANKLINE="$(tput el)"
  fi
  JOBID="$(printf "%-*s: %s" ${JOBIDWIDTH} "${PROFILE}" "$(basename ${BUILD_LOG})")"

  export LOGGED=Y
  sync

  ${BIN}/${SELF} ${ARGS} 2>&1 | \
    tee --append ${BUILD_LOG} | \
    awk -v TOTAL=${TOTAL} -v JOBID="${JOBID}" -v COLUMNS="${COLUMNS}" \
        -v ESC_PREAMBLE="${ESC_PREAMBLE}" -v ESC_POSTAMBLE="${ESC_POSTAMBLE}" -v ESC_BLANKLINE="${ESC_BLANKLINE}" \
        -v TXGREEN="${TXGREEN}" -v TXRED="${TXRED}" -v TXRESET="${TXRESET}" \
        -v PROFDIR=$(gettmpdirp) \
        "${BUILD_PROGRESS}"

  BUILDERR=Y

  ESECS="$(tail -10 ${BUILD_LOG} | ${TGREP} "## BUILD DURATION:" | sed 's/.*: //' | awk '{print $1}')"
  ETIME="$(hmstimer "0" "%02dh%02dm%02ds" "${ESECS}")"

  [ -n "${PROFILE}" ] && echo "${BDATE} ${ETIME}" > $(gettmpdirp)/.build

  NEWREL="$(${TGREP} -E "Creating .* filesystem on" ${BUILD_LOG} | tail -1 | sed 's/.*Creating/Creating/' | awk '{print $5}' | sed "s/,//")"

  BUILD_TAR=$(get_build_tar)

  if [ -n "${NEWREL}" ]; then
    TARGET="$(getbuildtarget)"
    TARGET_WORK="$(getoeoption TARGET_IMG)"

    NEWREL="$(basename ${NEWREL} .system)"
    ORIGINAL_REL="${NEWREL}"

    if [ "${MKRELEASE}" == "N" ]; then
      BUILDERR=N
      rm -f ${BUILD_LOG}
    elif [ -f ${NEWTAR} ]; then
      BUILDERR=N

      mkdir -p ${TARGET}
      mv ${TARGET_WORK}/${NEWREL}.* "${TARGET}"

      NEWREL=$(makeunique "${TARGET}" "${NEWREL}")

      mv ${BUILD_LOG} "${TARGET}/${NEWREL}.log"

      # Add our build tar to the release tar
      tar -rf "${TARGET}/${NEWREL}.tar" -C $(dirname ${BUILD_TAR}) \
          --transform "s@.*@${ORIGINAL_REL}/&@" \
          $(basename ${BUILD_TAR})

      echo "${BDATE} ${ETIME}" > ${BIN}/.build
    fi
    rm -rf ${TARGET_WORK}
  fi

  rm -fr ${BUILD_TAR}

  if [ "${BUILDERR}" == "N" ]; then
    [ ${NOTIFY} == Y ] && notifyme SOUND_OK1 "Successful $(getbuildstr) build, #${BDATE:2}. Elapsed time: ${ETIME}"
    [ "${PARALLEL_BUILD}" == "N" ] && echo -e "\nNew System image created: ${NEWREL}.tar"
    [ "${PARALLEL_BUILD}" == "Y" ] && echo "New System image created for ${PROFILE}: ${NEWREL}.tar" >$(gettmpdirp)/build.status
    [ -n "${PROFILE}" ] && rm -f $(gettmpdirp)/build.fail
    exit 0
  else
    if [ "${PARALLEL_BUILD}" == "N" ]; then
      echo
      echo "${BUILDFAIL}"
      echo "ERROR: No new sytem image found, check log!"
    else
      echo "${BUILDFAIL}" >$(gettmpdirp)/build.status
      echo "${TXRED}Build for profile ${PROFILE} failed!${TXRESET}" >>$(gettmpdirp)/build.status
      echo "ERROR: No new sytem image found for ${PROFILE}, check log (${BUILD_LOG})!" >>$(gettmpdirp)/build.status
    fi
    [ ${NOTIFY} == Y ] && notifyme SOUND_ERR "Build failure: $(getbuildstr)"
    exit 1
  fi
fi

${BIN}/zzPurge.sh ${PROJECT} >/dev/null

# Ensure image is created with build code and distribution identifier
fixup_image

# Create the archive of all scripts, configuration and patches
create_build_tar

cd ${BUILD_REPO_PATH}

suffix="$(getoeoption "BUILD_SUFFIX")"
[ -n "${suffix}" ] && version="${BUILD_REPO_VERSION}-${suffix}" || version="${BUILD_REPO_VERSION}"

echo "Git  branch is: ${GITBRANCH}"
echo "Kodi branch is: ${BRANCH}"
echo "OE_KODI_VER is: ${OE_KODI_VER}"
[ -n "${PROFILE}" ] && echo "Profile       : ${PROFILE}"
echo "Debug enabled : ${DEBUG^}"
if [ -n "${DEVICE}" ]; then
  echo "Dev/Arch/Vers : ${DEVICE}/${ARCH}/${version}"
else
  echo "Proj/Arch/Vers: ${PROJECT}/${ARCH}/${version}"
fi
echo "Build Log     : ${BUILD_LOG}$([ "${PARALLEL_BUILD}" == "Y" ] && echo " (parallel build)")"
echo "Build Path    : $(getoeoption "BUILD")"
echo "Build code is : ${BDATE}"
echo

if [ "${GITUPDATE}" == "Y" ]; then
  if [ "${GITBRANCH}" != "${BRANCH}" ]; then
    git checkout "${BRANCH}"
    if [ $? -ne 0 ]; then
      echo "Failed switching git branch to ${BRANCH} - aborting"
      exit
    fi
  fi

  git fetch upstream --verbose
  git merge upstream/${BRANCH}

  echo
  echo "Differences:"
  echo "============"
  #git diff upstream/${BRANCH} --name-only
  git status -s | ${TGREP} -E "^ [DM]"

  [ ${NOBUILD} == Y ] && exit

  C=10; while [ ${C} -gt 0 ]; do printf "\r%2d" ${C}; C=$((C-1)); sleep 1; done ; printf "\r  \n"
fi
[ ${NOBUILD} == Y ] && exit

#Sanity check for RPi - should always be at least one Linux patch
[ -n "${DEVICE}" ] && patchesdir="projects/${PROJECT}/devices/${DEVICE}/patches/linux" || patchesdir="projects/${PROJECT}/patches/linux"
[ ${PROJECT:0:3} == RPi -a $(find "${patchesdir}" -name '*.patch' 2>/dev/null | wc -l) -eq 0 ] && \
  echo "${TXRED}WARNING: No ${PROJECT} linux patches found!${TXRESET}"

[ -n "${KBUILD_BUILD_USER}" ] && export KBUILD_BUILD_USER
[ -n "${KBUILD_BUILD_HOST}" ] && export KBUILD_BUILD_HOST

# Synchronise concurrent job startup
if [ "${PARALLEL_BUILD}" == "Y" -a -n "${COMMSDIR}" ]; then
  touch "${COMMSDIR}/build.ready.${JOBINDEX}"
  while [ -f "${COMMSDIR}/build.wait" ]; do sleep 0.25; done
fi

echo "## BUILD STARTED: $(date)" && T_START=$(date +%s)

BUILDCMD="DEBUG=${DEBUG} PROJECT=${PROJECT} DEVICE=${DEVICE} ARCH=${ARCH} CROSS_COMPILE= make -j$(nproc)"
[ "${MKRELEASE}" == "Y" ] && BUILDCMD="${BUILDCMD} ${RELEASE_TYPE}" || BUILDCMD="${BUILDCMD} system"
echo "${BUILDCMD}" && eval ${BUILDCMD}

echo "## BUILD FINISHED: $(date)" && T_END=$(date +%s)
echo "## BUILD DURATION: $((${T_END} - ${T_START})) seconds"
