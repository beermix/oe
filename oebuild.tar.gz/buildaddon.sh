#!/bin/bash

BIN=$(readlink -f $(dirname $0))
[ -f "${BIN}/functions" ] && source ${BIN}/functions

_lock_build_repo

ADDONDIR=packages/addons
UNOFFICIAL=${ADDONDIR}/unofficial-addons

getaddonpath()
{
  local pkg_name="$1"
  local addonpath
  
  [ -z "${addonpath}" ] && addonpath="$(find ${ADDONDIR} -name "${pkg_name}" -type d)"
  [ -z "${addonpath}" ] && addonpath="$(find packages/mediacenter/kodi-binary-addons -name "${pkg_name}" -type d)"
  [ -z "${addonpath}" ] || echo "${addonpath}"
}

function clonerepo()
{
  (cd "${ADDONDIR}"; git clone ${BUILD_TYPE_GITHUB_ROOT}/unofficial-addons.git $(basename ${UNOFFICIAL}))
  return 0
}

function resetrepo()
{
  [ "${DOUAPULL}" == "Y" ] && (cd ${UNOFFICIAL}; git reset --hard HEAD -q; git pull)
  return 0
}

function apply_package_patches()
{
  local p d
  local errfile=/tmp/apply_package_patches.err
  
  if [ ${#DELETES[@]} -ne 0 ]; then
    (
      cd ${BUILD_REPO_PATH}
      for d in ${DELETES[@]}; do
        rm -f ${d}
      done
    )
  fi

  rm -f ${errfile}

  if [ ${#PATCHES[@]} -ne 0 ]; then
    (
      local result=0
      touch ${errfile}
      cd $(getoeprojectpath)/${PROJECT}/patches
      for p in ${PATCHES[@]}; do
        if [ -f ${p} ]; then
#          grep "^--- a/addons/.*\.patch$" ${p} >/dev/null || continue
          if grep -q "^--- a/addons/.*\.patch$" ${p} ||
             grep -q "^--- a/addons/.*/package.mk" ${p}; then
            echo "APPLYING PATCH: ${p}"
            cat ${p} | patch -p1 -d "${BUILD_REPO_PATH}/${UNOFFICIAL}" || { result=1; break; }
          else
            echo "APPLYING PATCH: ${p}"
            cat ${p} | patch -p1 -d "${BUILD_REPO_PATH}" || { result=1; break; }
          fi
        else
          echo "WARNING: Patch not found [${p}]"
        fi
      done
      [ ${result} -eq 0 ] && rm -f ${errfile}
    )
  fi

  [ -f ${errfile} ] && return 1 || return 0
}

# Determine if tarball needs to be refreshed
function needsync()
{
  local pkg_name="$1"
  local pkg_class="$(dirname "$(getaddonpath "${pkg_name}")")"
  local srcpath="$(getoepkgtarpath ${pkg_class} ${pkg_name})"
  local git_path=${BUILD_REPOS}/${pkg_name}.git
  local old_sha new_sha fetch cur_sha currbranch

  [ -d "${git_path}" ] || return 0

  if  [ -z "${srcpath}" ]; then
    echo "WARNING: Cannot determine tarball url/path for package [${pkg_name}]" >&2
  elif [ ! -f ${srcpath} ]; then
    return 0
  elif [ $(stat -c%Y "${srcpath}") -gt $(stat -c%Y "${git_path}/.git") ]; then
    return 0
  fi

  curbranch="$(getcurrentbranch "${git_path}")"
  old_sha="$(getcurrentrev "${git_path}" HEAD)"
  fetch="$(cd "${git_path}" && git fetch origin)"
  new_sha="$(getcurrentrev "${git_path}" "@{upstream}")"

  [ "${old_sha}" != "${new_sha}" ] && return 0

  # Final sanity check - if tarball is for a different branch/revision, replace it
  srcpath="${srcpath}.repo"
  [ -f "${srcpath}" ] && cur_sha="$(head -1 "${srcpath}")"
  [ "${cur_sha}" != "${curbranch} ${new_sha}" ] && return 0

  return 1
}

# Add -milhouse to PKG_REV
function setrevision()
{
  local pkg_name="$1" pkg_revision="${2}" pkg_version="$3"
  local pkg_class="$(getaddonpath "${pkg_name}")"
  local pkpath="${BUILD_REPO_PATH}/${pkg_class/\/package.mk}/package.mk"

  [ -n "${pkg_version}" ] && pkg_version="-${pkg_version}"
#  [ -n "${pkg_version}" ] && sed -i "s/^PKG_VERSION=.*/PKG_VERSION=\"${pkg_version}\"/" $pkpath
  if [ -f "${pkpath}" ]; then
    sed -i "s/^\(PKG_REV=\"[0-9]*\).*/\\1${pkg_revision}-milhouse${pkg_version}\"/" $pkpath
  fi
}

function getversion()
{
  local pkg_name="$1"
  local git_path=${BUILD_REPOS}/${pkg_name}.git

  if [ -d "${git_path}" ]; then
    [ "${pkg_name}" == "tvheadend" ] && echo "$(cd ${git_path}; git describe --dirty --match "v*")"
    [ "${pkg_name}" == "tvheadend42" ] && echo "$(cd ${git_path}; git describe --dirty --match "v*")"
  fi
  return 0
}

# OBSOLETE
fixrepoversion()
{
  local pkg_name="$1"
  local pkg_version="$2"
  local pkg_class="$(dirname "$(getaddonpath "${pkg_name}")")"
  local pkpath=${BUILD_REPO_PATH}/${pkg_class}/${pkg_name}/package.mk

  if [ -f "${pkpath}" ]; then
    sed -i "s/PKG_ADDON_REPOVERSION=\".*\"/PKG_ADDON_REPOVERSION=\"${pkg_version}\"/" ${pkpath}
  fi
}

dropverfromdescription()
{
  local pkg_name="$1"
  local pkg_class="$(dirname "$(getaddonpath "${pkg_name}")")"
  local pkpath=${BUILD_REPO_PATH}/${pkg_class}/${pkg_name}/package.mk

  [ -f "${pkpath}" ] && sed -i "s/ (\$PKG_VERSION_NUMBER)://" ${pkpath}
  return 0
}


storenewzip()
{
  local pkg_name="$1"
  local pkg_class="$(getaddonpath "${pkg_name}")"
  local pkpath="${BUILD_REPO_PATH}/${pkg_class/\/package.mk}/package.mk"
  local addon_section="$(getoepkgoption "${pkpath}" PKG_SECTION)"
  local addon_name="$(getoepkgoption "${pkpath}" PKG_NAME)"
  #PKG_ADDON_REPOVERSION is obsolete - now use ADDON_VERSION
  #local repo_version=$(getoepkgoption "${pkpath}" PKG_ADDON_REPOVERSION)
  local repo_version=$(getoeoption ADDON_VERSION)
  local pkg_version=$(getoepkgoption "${pkpath}" PKG_REV)
  local newzip fqn

  if [ -n "${repo_version}" -a -n "${addon_section}" ]; then
    fqn="${addon_section//\//.}.${addon_name}"
    newzip="${BUILD_REPO_PATH}/target/addons/${repo_version}/${DEVICE:-${PROJECT}}/${ARCH}/${fqn}/${fqn}-${repo_version}.${pkg_version}.zip"
  else
    # kodi-binary-addons not fully qualified - make them so
    fqn="${addon_name}"
#    oldzip="$(ls -t ${BUILD_REPO_PATH}/target/addons/${ADDON_VERSION}/${DEVICE:-${PROJECT}}/${ARCH}/${fqn}/${fqn}-*.zip 2>/dev/null| head -1)"
    oldzip="$(find ${BUILD_REPO_PATH}/target/addons/${ADDON_VERSION}/${DEVICE:-${PROJECT}}/${ARCH}/${fqn} -mmin -60 -name "${fqn}-*.zip" 2>/dev/null | sort | head -1)"
    if [ -n "${oldzip}" -a "${oldzip/${pkg_version:2}/}" != "${oldzip}" ]; then
      if [ "${oldzip/${pkg_version:2}/}" != "${oldzip}" ]; then
        newzip="${oldzip:0:-4}-${pkg_version:2}.zip"
        rm -f ${newzip}
        mv "${oldzip}" "${newzip}"
      fi
    else
      newzip="${oldzip}"
    fi
  fi

  if [ -f "${newzip}" ]; then
    echo "${TXGREEN}NEW ZIP${TXRESET}: ${newzip}"
    echo "${newzip}" >/tmp/lastaddon.dat
    return 0
  else
    echo "${TXRED}Cannot find new zip!${TXRESET}"
    return 1
  fi
}

resetpackage()
{
  local pkg_name="$1"
  local pkg_class="$(getaddonpath "${pkg_name}")"

  if [ -n "${pkg_class}" ]; then
    (
      cd ${pkg_class}
#      git checkout -- package.mk 2>/dev/null
      if [ -f ./backup.tar.gz ]; then
        find . -not -name backup.tar.gz -delete
        tar xzf backup.tar.gz >/dev/null
      else
        tar cvzf backup.tar.gz . 1>/dev/null 2>/dev/null
      fi
    )
  fi
}

days_since_epoch()
{
  local pdate="${1}"
  [ -z "${pdate}" ] && pdate="$(date "+%Y-%m-%d 00:00:00")"
  echo "$(($(date --utc --date="${pdate}" +%s) / 86400))"
}

newbuildrequired()
{
  local packagename="${1}" timesince="${2:-0}"
  local lastzip nowd modt modd delta root parent

  [ ${timesince} -eq 0 ] && return 0

  root="${BUILD_REPO_PATH}/target/addons/${ADDON_VERSION}/${DEVICE:-${PROJECT}}/${ARCH}"
  parent="$(find ${root} -maxdepth 1 -name "*${packagename}*")"
  [ -z "${parent}" ] && return 0

  lastzip="$(ls -1c ${parent}/*${packagename}*.zip 2>/dev/null | head -1)"
  [ -z "${lastzip}" ] && return 0

  nowd=$(days_since_epoch)
  modt=$(stat -c%z ${lastzip})
  modd=$(days_since_epoch "${modt:0:10} 00:00:00")
  delta=$((nowd - modd))

  if [ ${delta} -gt ${timesince} ]; then
    return 0
  else
    echo "IGNORING ADD-ON: Last updated ${delta} days ago"
    # create empty lastaddon.dat - ended ok, but no addon created
    touch /tmp/lastaddon.dat
    return 1
  fi
}

function usage()
{
  cat <<EOF
Usage: $(basename $0) -a addon [-r revision] [-P filename] [-p] [-S #] [-h]
Options:
    -a  Name of addon to build
    -r  Revision code (a, b, c etc.)
    -p  Do not pull unofficial-addons repo - use existing files
    -P  Apply patch (absolute path) - repeat for each extra patch
    -S  Time (in days) since last build
    -h  This message
EOF
}

ADDON_NAME=
DOUAPULL=Y
REVISION=
PATCHES=()
DELETES=()
TIMESINCE=0

while getopts ":a:pr:P:D:S:" opt; do
  case ${opt} in
    a) ADDON_NAME="${OPTARG}";;
    p) DOUAPULL=N;;
    r) REVISION="${OPTARG}";;
    P) PATCHES+=("${OPTARG}");;
    D) DELETES+=("${OPTARG}");;
    S) TIMESINCE="${OPTARG}";;
    h|*) usage; exit 1;;
  esac
done

rm -f /tmp/lastaddon.dat

[ -n "${ADDON_NAME}" ] || die 1 "Need addon name, use -a argument"

ADDON_VERSION=$(getoeoption "ADDON_VERSION")

newbuildrequired "${ADDON_NAME}" "${TIMESINCE}" || exit 0

echo "Building addon: ${ADDON_NAME} for ${PROFILE}..."

cd ${BUILD_REPO_PATH}

resetpackage "${ADDON_NAME}"

if [ "${BUILD_TYPE,,}" == "openelec" ]; then
  [ -d ${UNOFFICIAL} ] && resetrepo || clonerepo
fi

apply_package_patches || die 1 "Unable to apply patches"

${BIN}/clean.sh "${ADDON_NAME}"

if [ -f ${BUILD_REPOS}/make-${ADDON_NAME}.sh ]; then
  needsync "${ADDON_NAME}" && ${BUILD_REPOS}/make-${ADDON_NAME}.sh
  NEWVERSION="$(getversion "${ADDON_NAME}")"
fi

dropverfromdescription "${ADDON_NAME}"

setrevision "${ADDON_NAME}" "${REVISION}" "${NEWVERSION}"

#fixrepoversion "${ADDON_NAME}" "${ADDON_VERSION}"

scripts/create_addon ${ADDON_NAME}

storenewzip "${ADDON_NAME}"

[ -n "${NEWVERSION}" ] && echo -e "\nNew Version: ${NEWVERSION}"
