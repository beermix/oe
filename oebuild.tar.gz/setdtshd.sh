#!/bin/bash

source ./settings.sh

applysettings "audiooutput.supportdtshdcpudecoding" "$@"
