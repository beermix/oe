#!/bin/bash

PROFILE=defaults
BIN=$(readlink -f $(dirname $0))
[ -f ${BIN}/functions ] && source ${BIN}/functions

#function exit()
#{
#  return 0
#}

while read -r profile; do
  echo -en "Profile: ${profile}                                \r"
  RESULT="$(loadprofile ${profile} noinit 2>&1)"
  [ -z "${RESULT}" ] && continue
  echo "${RESULT}" | grep -q "marked as a base profile" && continue
  echo -e "\n${RESULT}"
done <<< "$(${BIN}/parseprofile.py ${BIN}/profiles.dat | awk '/^\[.*\]/ { print substr($1,2,length($1)-2) }' | sort -u)"

